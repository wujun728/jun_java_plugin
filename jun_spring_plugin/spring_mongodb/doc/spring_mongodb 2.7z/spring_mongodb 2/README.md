### [springmvc-mongodb](https://github.com/wangxinforme/springmvc-mongodb)
<code>它是一个典型的MVC三层框架示例工程，快速简单的上手。</code>

+ 介绍：
	+ 集成框架有：SpringMVC、MongoDB、Bootstrap3、Sitemesh3、log4j；</br></br>
	
+ 启动示例工程：
	+ 部署启动工程；
	+ 浏览器访问工程查看示例效果；</br></br>


欢迎[交流讨论](https://github.com/wangxinforme/springmvc-hibernate/issues)

<b>[胡桃夹子GitHub](https://github.com/wangxinforme "Vincent Git@OSC主页")</b>

