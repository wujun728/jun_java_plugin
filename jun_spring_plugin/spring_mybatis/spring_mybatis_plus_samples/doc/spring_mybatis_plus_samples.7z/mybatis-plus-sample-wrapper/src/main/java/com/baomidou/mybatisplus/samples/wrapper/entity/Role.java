package com.baomidou.mybatisplus.samples.wrapper.entity;

import lombok.Data;

/**
 * @author miemie
 * @since 2018-08-10
 */
@Data
public class Role {
    private Long id;
    private String roleName;
    private String roleDescribe;
}
