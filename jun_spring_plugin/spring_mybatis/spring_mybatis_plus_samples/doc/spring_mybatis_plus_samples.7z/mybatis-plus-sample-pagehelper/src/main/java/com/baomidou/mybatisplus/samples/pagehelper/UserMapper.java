package com.baomidou.mybatisplus.samples.pagehelper;

import org.apache.ibatis.annotations.Mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @author miemie
 * @since 2020-05-29
 */
@Mapper
public interface UserMapper extends BaseMapper<User> {

}
