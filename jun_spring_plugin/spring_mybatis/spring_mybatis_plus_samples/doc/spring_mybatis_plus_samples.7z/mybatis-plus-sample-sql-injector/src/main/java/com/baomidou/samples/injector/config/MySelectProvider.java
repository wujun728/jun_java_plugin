package com.baomidou.samples.injector.config;

/**
 * @author miemie
 * @since 2020-03-23
 */
public class MySelectProvider {

    public String getSql(String sql) {
        return sql;
    }
}
