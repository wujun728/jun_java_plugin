package com.baomidou.mybatisplus.no.spring.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.no.spring.entity.Person;

/**
 * @author miemie
 * @since 2020-03-11
 */
public interface PersonMapper extends BaseMapper<Person> {

}
