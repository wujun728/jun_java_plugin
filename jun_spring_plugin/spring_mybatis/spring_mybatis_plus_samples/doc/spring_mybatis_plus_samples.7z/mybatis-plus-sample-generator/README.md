# 演示mp代码生成

* mp默认不覆盖源文件，如果要重新生成并覆盖，需要配置GlobalConfig.setFileOverride(true)
* 参考[官网说明](https://mybatis.plus/guide/generator.html#%E4%BB%A3%E7%A0%81%E7%94%9F%E6%88%90%E5%99%A8)

自定义模板，参考src/test， 单元测试mysql数据库，可以跑一下