@javax.xml.bind.annotation.XmlSchema(namespace = "http://server.cxf.camel.com/")
package com.camel.cxf.server;
