package com.qiniu.linking.model;

public class DeviceListing {

    public Device[] items;
    public String marker;
}
