package com.qiniu.linking.model;

public class Channel {

    private int channelid;
    private String comment;
}
