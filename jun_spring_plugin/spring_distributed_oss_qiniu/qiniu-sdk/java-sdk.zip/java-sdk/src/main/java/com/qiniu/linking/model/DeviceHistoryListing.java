package com.qiniu.linking.model;

public class DeviceHistoryListing {

    DeviceHistoryItem[] items;
    String marker;
}
