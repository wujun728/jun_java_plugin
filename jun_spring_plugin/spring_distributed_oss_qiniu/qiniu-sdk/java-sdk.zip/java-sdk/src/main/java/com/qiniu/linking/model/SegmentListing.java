package com.qiniu.linking.model;

public class SegmentListing {

    Segment[] items;
    String marker;
}
