#spring_json_view
    进入工程目录执行 mvn jetty:run
    访问  http://localhost:8090/home/sayHello/XXX
