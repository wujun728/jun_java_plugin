package com.zhm.spring.jsonview.model;

/**
 * Created by zhm on 2015/7/13.
 */
public class View {
    public interface UserInfoWithOutPassword{}
    public interface UserInfoWithPassword extends UserInfoWithOutPassword{}
}
