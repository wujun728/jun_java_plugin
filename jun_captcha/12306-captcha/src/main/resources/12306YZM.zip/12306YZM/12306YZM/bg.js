(function () {
    chrome.extension.onMessage.addListener(function (request, sender, sendResponse) {
        if (request.cmd === "GetSig") {
            var result = document.getElementById("pluginId").GetSig(request.yzm);
            console.log(result);

            sendResponse(result);
        }
    });

})();