﻿/****Copyright by http://www.cnblogs.com/guozili / guozili@163.com / 2005 ***/

//$(..).click()在此环境中无效
var clickevent = document.createEvent('MouseEvents');
clickevent.initEvent('click', false, true);

//$(..).keyup()在此环境中无效
var keyupevent = document.createEvent('KeyboardEvent');
keyupevent.initEvent('keyup', false, true);

function refreshStation(stations, interval) {
    var stationobj = {};
    var stationnames = stations.split("@");
    for (var i in stationnames) {
        var stationname = stationnames[i];
        if (stationname == "")
            continue;

        try {
            var stationfields = stationname.split("|");
            stationobj[stationfields[1]] = stationfields[2];
        } catch (e) {

        }
    }

    var stationGroups = {
        "北京": ["北京北", "北京东", "北京南", "北京", "北京西"],
        "长沙": ["长沙", "长沙南"],
        "衡阳": ["衡阳", "衡阳东"],
        "广州": ["广州南", "广州东", "广州西", "广州", "虎门"]
    };

    var queryTimes = 1;

    var resetStation = function (station) {

        for (var i in stationGroups) {
            var stations = stationGroups[i];
            if (stations.indexOf($(station + "Text").val()) >= 0) {
                var stationText = stations[Math.round(Math.random() * (stations.length - 1))];
                $(station + "Text").val(stationText);
                $(station).val(stationobj[stationText]);
                break;
            }
        }
    }

    setInterval(function () {
        if ($("#query_ticket").text() == "停止查询") {
            resetStation("#fromStation");
            resetStation("#toStation");
            queryTimes++;
        }
    }, interval || 1000);
}

function YZM() {
    var canvas = document.createElement("canvas");
    var img1 = document.getElementById("img_rand_code_other");
    canvas.width = img1.naturalWidth;
    canvas.height = img1.naturalHeight;
    var ctx = canvas.getContext("2d");
    ctx.drawImage(img1, 0, 0);
    var dataURL = canvas.toDataURL("image/png");
    var buf = dataURL.substring(22);

    chrome.extension.sendMessage({ cmd: "GetSig", yzm: buf }, function (res) {
        console.log(res);
        $.ajax({
            url: yzmurl,
            dataType: "jsonp",
            data: { 'img_buf': buf, 'check': res },
            jsonp: "jsonpcallback",
            jsonpCallback: "success_jsonpCallback",
            success: function (data) {

                $("#randCode_other").val(data);
            },
            error: function (e) {
            }
        });
    });
}

function YZ() {
    //调用验证码OCR服务
    YZM();
    //触发自动提交，验证码框输入忙4个字符时
    setTimeout(function () {
        if ($('#randCode_other').val().length == 4) {
            $('#randCode_other').focus();
            document.getElementById("randCode_other").dispatchEvent(keyupevent);
        }
    }, 500)
}

function Inject() {

    var removeyzm = false;
    //不同域，jsonp callback不起作用，请参考 http://blog.csdn.net/free_wind22/article/details/8107531
    //使用下面的方法注入callback
    var script = document.createElement('script');
    script.type = 'text/javascript';
    script.innerHTML = "window.autoSearchTime = " + refreshInterval + ";"
        + "$('<input id=station_names type=hidden value=' + window.station_names + '/>').appendTo('body');"
        + "$('#img_rand_code_other').after($('<div style=color:red id=ocrresult>开始识别验证码....</div>')); "
        + "$('#content_autosubmitcheckticketinfo .colorA').after($('<input type=button id=removeyzm value=还原手动输入&禁用自动识别 />')); $('#removeyzm').click(function(){ $('#ocrresult, #removeyzm').remove();});"
        + "function success_jsonpCallback(yzm) {$('#randCode_other').val(yzm); $('#ocrresult').html('OCR:'+yzm);}";
    document.head.appendChild(script);

    //动态切站，避免CDN缓存
    refreshStation($("#station_names").val(), refreshInterval);

    var isFirstYZ = true; ;
    //每隔一段时间，模拟点击刷新验证码
    setInterval(function () {
        //当出票时弹窗时
        if ($("#autosubmitcheckticketinfo").css("display") != "none") {
            if ($('#ocrresult').length)
            {
                $('#randCode_other').focus();
                
                if (isFirstYZ) {
                    setTimeout(function () { YZ(); }, 200);
                    isFirstYZ = false;
                } else {
                    $(".i-re").click();
                }
            }
        }
        else {
            isFirstYZ = true;

            //网络慢时刷不出票时弹窗提示无票
            if ($("#gb_closeDefaultWarningWindowDialog_id").length) {
                document.getElementById("gb_closeDefaultWarningWindowDialog_id").dispatchEvent(clickevent);
            }
        }
    }, 4000);

    //刷新验证码按钮点击
    $(".i-re").live("click", function () {
        setTimeout(function () {
            //$("#img_rand_code_other").load(function () {
                YZ();
            //});
        }, 800);
    });
}

var injected = false;
var refreshInterval = 1000;

//var yzmurl = "http://localhost:1111/yzm.aspx";
var yzmurl = "http://guozili.28.web1268.net/yzm.aspx";

(function PageLoad() {
    $('.quick-s ul').hide();
    $('.quick-s ul').after($('<ul style=color:red><li>刷新时间</li><li><input id=refreshInterval style=width:30px  type=text  value=' + refreshInterval + '  />毫秒</li><ul>'));

    //第一次点击按钮时完成注入
    $("#query_ticket").click(function(){
        if (!injected)
        {
            refreshInterval = parseInt($('#refreshInterval').val()) || refreshInterval;
            Inject();
            injected = true;
        }
    });

    //保持验证码服务端激活状态
    $('.footer').append("<iframe id='activeframe' src='" + yzmurl + "' height='40'>");
    var i = 1;
    setInterval(function () {
        var rd = "?r=" + Math.random();
        if ((i++) % 2 == 0) {
            //保持验证码服务端激活状态
            $('#activeframe').attr("src", yzmurl + rd)
        }
        else {
            //保持刷票时一直都在登录状态，不会自动退出
            $('#activeframe').attr("src", "https://kyfw.12306.cn/otn/queryOrder/initNoComplete" + rd)
        }
    }, 8 * 60 * 1000);
})()





