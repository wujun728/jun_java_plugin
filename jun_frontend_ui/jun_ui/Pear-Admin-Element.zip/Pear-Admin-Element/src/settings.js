module.exports = {

  title: 'PearAdmin',

  
  fixedHeader: true,


  sideLogo: true,


  muiltTab: true
}
