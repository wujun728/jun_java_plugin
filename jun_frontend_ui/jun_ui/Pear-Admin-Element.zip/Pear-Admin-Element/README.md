# Pear Admin Element

#### 介绍
Pear Admin Element 基于 vue-admin-template 前端项目

官方网站 : http://www.pearadmin.com


#### 软件架构
软件架构说明

项目截图

![输入图片说明](https://images.gitee.com/uploads/images/2020/0607/005912_6f881c57_4835367.png "(ZJQA9TSE9E{]~5C568(JQ9.png")