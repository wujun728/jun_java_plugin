
# J2Cache 的 MyBatis 模块

该模块是为了让 mybatis 支持 J2Cache 二级缓存。

配置方法： 

`<cache type="net.oschina.j2cache.mybatis.J2CacheAdapter"/>`

Maven:

```
<dependency>
    <groupId>net.oschina.j2cache</groupId>
    <artifactId>j2cache-mybatis</artifactId>
    <version>2.3.17-release</version>
</dependency>
```