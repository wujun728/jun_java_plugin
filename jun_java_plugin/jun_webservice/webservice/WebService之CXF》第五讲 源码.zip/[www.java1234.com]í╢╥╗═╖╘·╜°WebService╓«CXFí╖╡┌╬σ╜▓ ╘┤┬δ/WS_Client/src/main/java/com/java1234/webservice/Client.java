package com.java1234.webservice;

import java.util.List;

public class Client {

	public static void main(String[] args) {
		HelloWorldService service=new HelloWorldService();
		HelloWorld helloWorld=service.getHelloWorldPort();
		//System.out.println(helloWorld.say("java1234_С��"));
		
		/*User user=new User();
		user.setUserName("jack");
		user.setPassword("123456");
		List<Role> roleList=helloWorld.getRoleByUser(user);
		for(Role role:roleList){
			System.out.println(role.getId()+","+role.getRoleName());
		}*/
		
		MyRoleArray arry=helloWorld.getRoles();
		List<MyRole> roleList=arry.item;
		for(int i=0;i<roleList.size();i++){
			MyRole my=roleList.get(i);
			System.out.print(my.key+":");
			for(Role r:my.value){
				System.out.print(r.getId()+","+r.getRoleName());
			}
			System.out.println("============");
		}
	}
}
