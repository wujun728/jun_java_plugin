package cn.hdu.web.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.hdu.dao.service.CodeInvalidateException;
import cn.hdu.dao.service.UserService;
import cn.hdu.dao.service.impl.UserServiceImpl;

public class ActiviteAservlet extends HttpServlet {
	private UserService s = new UserServiceImpl();

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String code = request.getParameter("code");
		if (code!=null) {
			try {
				s.active(code);
			} catch (CodeInvalidateException e) {
				request.setAttribute("message", e.getMessage());
				request.getRequestDispatcher("/message.jsp").forward(request, response);
				return;
			}
			request.setAttribute("message", "����ɹ�������");
			request.getRequestDispatcher("/message.jsp").forward(request, response);
		}  {
			request.setAttribute("message", "�����벻����");
			request.getRequestDispatcher("/message.jsp").forward(request, response);
		}
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
