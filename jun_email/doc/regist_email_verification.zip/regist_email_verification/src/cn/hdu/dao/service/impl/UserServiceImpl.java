package cn.hdu.dao.service.impl;

import java.util.UUID;

import cn.hdu.dao.UserDao;
import cn.hdu.dao.impl.UserDaoImpl;
import cn.hdu.dao.service.CodeInvalidateException;
import cn.hdu.dao.service.UserService;
import cn.hdu.domain.User;

public class UserServiceImpl implements UserService {
	private UserDao dao = new UserDaoImpl();
	public User login(String username, String password) {
		User user = dao.findUser(username, password);
		//�û�����
		if (user != null) {
			//��һ���ж��Ƿ񼤻�
			if (user.isActived()) {
				return user;
			} else {
				return null;
			}
		}
		return null;
	}

	public void regist(User user) {
		user.setId(UUID.randomUUID().toString());
		dao.addUser(user);
	}

	public void active(String code) throws CodeInvalidateException {
		User user = dao.findUserByCode(code);
		if (user == null) {
			throw new CodeInvalidateException("�����벻��ȷ!!!");
		} else {
			user.setActived(true);
			dao.updateUser(user);
		}
		
	}

}
