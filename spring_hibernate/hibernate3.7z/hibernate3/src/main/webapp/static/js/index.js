;
(function($, window, document, undefined) {

  var j_search = {};

  // j_search.search=function

  $(function() {

  });

})(jQuery, window, document);