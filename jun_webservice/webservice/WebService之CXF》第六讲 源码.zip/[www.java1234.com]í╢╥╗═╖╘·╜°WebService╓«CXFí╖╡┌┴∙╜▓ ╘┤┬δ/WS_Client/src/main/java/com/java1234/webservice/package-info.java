@javax.xml.bind.annotation.XmlSchema(namespace = "http://webservice.java1234.com/")
package com.java1234.webservice;
