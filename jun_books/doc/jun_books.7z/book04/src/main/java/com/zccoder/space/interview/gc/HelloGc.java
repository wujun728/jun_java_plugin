package com.zccoder.space.interview.gc;

/**
 * GC示例
 *
 * @author zc
 * @date 2020/05/04
 */
public class HelloGc {

    public static void main(String[] args) throws Exception {
        System.out.println("HelloGc");

        // byte[] byteArray = new byte[50 * 1024 * 1024];

        Thread.sleep(Integer.MAX_VALUE);
    }
}
