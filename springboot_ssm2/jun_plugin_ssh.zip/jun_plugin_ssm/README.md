#ssm
项目框架：
Spring MVC , Spring , Mybatis , Shiro , FreeMarker等；


