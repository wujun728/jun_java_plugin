/*
 * Decompiled with CFR 0.152.
 */
package net.maku.online.vo.form;

import java.util.List;
import java.util.Map;
import net.maku.online.vo.form.WidgetFormVO;

public class OnlineFormVO {
    private /* synthetic */ WidgetFormVO form;
    private static /* synthetic */ int[] Pd;
    private /* synthetic */ List<Map<String, Object>> table;
    private /* synthetic */ WidgetFormVO query;

    public WidgetFormVO getForm() {
        OnlineFormVO bqub;
        return bqub.form;
    }

    protected boolean canEqual(Object uNub) {
        return uNub instanceof OnlineFormVO;
    }

    static {
        OnlineFormVO.AJ();
    }

    private static boolean CJ(int n) {
        return n == 0;
    }

    public void setTable(List<Map<String, Object>> CPub) {
        fPub.table = CPub;
    }

    public WidgetFormVO getQuery() {
        OnlineFormVO fqub;
        return fqub.query;
    }

    private static boolean EJ(Object object) {
        return object != null;
    }

    public void setForm(WidgetFormVO mPub) {
        NPub.form = mPub;
    }

    public List<Map<String, Object>> getTable() {
        OnlineFormVO ZPub;
        return ZPub.table;
    }

    public void setQuery(WidgetFormVO TPub) {
        uPub.query = TPub;
    }

    public boolean equals(Object qoub) {
        block25: {
            block26: {
                List<Map<String, Object>> Joub;
                List<Map<String, Object>> koub;
                block24: {
                    OnlineFormVO Poub;
                    OnlineFormVO houb;
                    block22: {
                        block23: {
                            WidgetFormVO Loub;
                            WidgetFormVO moub;
                            block21: {
                                block19: {
                                    block20: {
                                        WidgetFormVO Noub;
                                        WidgetFormVO ooub;
                                        block18: {
                                            if (OnlineFormVO.bJ(qoub, houb)) {
                                                return Pd[0];
                                            }
                                            if (OnlineFormVO.CJ(qoub instanceof OnlineFormVO)) {
                                                return Pd[1];
                                            }
                                            Poub = (OnlineFormVO)qoub;
                                            if (OnlineFormVO.CJ(Poub.canEqual(houb) ? 1 : 0)) {
                                                return Pd[1];
                                            }
                                            ooub = houb.getQuery();
                                            Noub = Poub.getQuery();
                                            if (!OnlineFormVO.dJ(ooub)) break block18;
                                            if (!OnlineFormVO.EJ(Noub)) break block19;
                                            "".length();
                                            if (null != null) {
                                                return ((0x92 ^ 0xA8 ^ (0x91 ^ 0xB7)) & (53 + 71 - 104 + 161 ^ 65 + 142 - 165 + 127 ^ -" ".length())) != 0;
                                            }
                                            break block20;
                                        }
                                        if (!OnlineFormVO.CJ(((Object)ooub).equals(Noub) ? 1 : 0)) break block19;
                                    }
                                    return Pd[1];
                                }
                                moub = houb.getForm();
                                Loub = Poub.getForm();
                                if (!OnlineFormVO.dJ(moub)) break block21;
                                if (!OnlineFormVO.EJ(Loub)) break block22;
                                "".length();
                                if (((0x59 ^ 0x24 ^ (0x61 ^ 0x1A)) & (0x2E ^ 0x5A ^ (0xD ^ 0x7F) ^ -" ".length())) < ((0xC6 ^ 0x99 ^ (0x39 ^ 0x4B)) & (3 + 117 - 28 + 39 ^ 100 + 126 - 169 + 117 ^ -" ".length()))) {
                                    return ((0xCD ^ 0x88 ^ 39 + 34 - 45 + 99) & (0x38 ^ 7 ^ (0x20 ^ 0x25) ^ -" ".length())) != 0;
                                }
                                break block23;
                            }
                            if (!OnlineFormVO.CJ(((Object)moub).equals(Loub) ? 1 : 0)) break block22;
                        }
                        return Pd[1];
                    }
                    koub = houb.getTable();
                    Joub = Poub.getTable();
                    if (!OnlineFormVO.dJ(koub)) break block24;
                    if (!OnlineFormVO.EJ(Joub)) break block25;
                    "".length();
                    if (-" ".length() >= 0) {
                        return ((0x72 ^ 0x5B) & ~(0x5A ^ 0x73)) != 0;
                    }
                    break block26;
                }
                if (!OnlineFormVO.CJ(((Object)koub).equals(Joub) ? 1 : 0)) break block25;
            }
            return Pd[1];
        }
        return Pd[0];
    }

    public String toString() {
        OnlineFormVO Zmub;
        return "OnlineFormVO(query=" + Zmub.getQuery() + ", form=" + Zmub.getForm() + ", table=" + Zmub.getTable() + ")";
    }

    public int hashCode() {
        int n;
        int n2;
        int n3;
        OnlineFormVO NNub;
        int mNub = Pd[2];
        int LNub = Pd[0];
        WidgetFormVO kNub = NNub.getQuery();
        int n4 = LNub * Pd[2];
        if (OnlineFormVO.dJ(kNub)) {
            n3 = Pd[3];
            "".length();
            if (" ".length() == 0) {
                return (0x73 ^ 0x2C) & ~(0xCB ^ 0x94);
            }
        } else {
            n3 = ((Object)kNub).hashCode();
        }
        LNub = n4 + n3;
        WidgetFormVO JNub = NNub.getForm();
        int n5 = LNub * Pd[2];
        if (OnlineFormVO.dJ(JNub)) {
            n2 = Pd[3];
            "".length();
            if (((36 + 179 - 169 + 158 ^ 55 + 118 - 129 + 85) & (0x83 ^ 0x95 ^ (0x31 ^ 0x6A) ^ -" ".length())) >= " ".length()) {
                return (171 + 68 - 111 + 61 ^ 29 + 119 - 94 + 109) & (65 + 42 - 73 + 154 ^ 139 + 29 - 67 + 61 ^ -" ".length());
            }
        } else {
            n2 = ((Object)JNub).hashCode();
        }
        LNub = n5 + n2;
        List<Map<String, Object>> hNub = NNub.getTable();
        int n6 = LNub * Pd[2];
        if (OnlineFormVO.dJ(hNub)) {
            n = Pd[3];
            "".length();
            if ((0x25 ^ 0x21) != (0x29 ^ 0x2D)) {
                return (0x91 ^ 0xBA) & ~(0x28 ^ 3);
            }
        } else {
            n = ((Object)hNub).hashCode();
        }
        LNub = n6 + n;
        return LNub;
    }

    private static void AJ() {
        Pd = new int[4];
        OnlineFormVO.Pd[0] = " ".length();
        OnlineFormVO.Pd[1] = "   ".length() & ~"   ".length();
        OnlineFormVO.Pd[2] = 0x1D ^ 0x26;
        OnlineFormVO.Pd[3] = 0x60 ^ 0x43 ^ (0x9E ^ 0x96);
    }

    private static boolean bJ(Object object, Object object2) {
        return object == object2;
    }

    private static boolean dJ(Object object) {
        return object == null;
    }

    public OnlineFormVO() {
        OnlineFormVO hqub;
    }
}

