/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.fasterxml.jackson.annotation.JsonFormat
 *  io.swagger.v3.oas.annotations.media.Schema
 */
package net.maku.online.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.Date;
import java.util.List;
import net.maku.online.vo.OnlineTableColumnVO;

@Schema(description="Online\u8868\u5355\u5f00\u53d1")
public class OnlineTableVO {
    private static /* synthetic */ int[] Nd;
    @Schema(description="\u521b\u5efa\u65f6\u95f4")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private /* synthetic */ Date createTime;
    @Schema(description="id")
    private /* synthetic */ String id;
    @Schema(description="\u662f\u5426\u6811  0\uff1a\u5426   1\uff1a\u662f")
    private /* synthetic */ Integer tree;
    @Schema(description="\u8868\u7c7b\u578b  0\uff1a\u5355\u8868")
    private /* synthetic */ Integer tableType;
    @Schema(description="\u8868\u5355\u5e03\u5c40  1\uff1a\u4e00\u5217   2\uff1a\u4e24\u5217   3\uff1a\u4e09\u5217    4\uff1a\u56db\u5217")
    private /* synthetic */ Integer formLayout;
    @Schema(description="\u6811\u7236id")
    private /* synthetic */ String treePid;
    @Schema(description="\u6811\u5c55\u793a\u5217")
    private /* synthetic */ String treeLabel;
    @Schema(description="\u7248\u672c\u53f7")
    private /* synthetic */ Integer version;
    @Schema(description="\u8868\u540d")
    private /* synthetic */ String name;
    @Schema(description="\u8868\u5b57\u6bb5")
    private /* synthetic */ List<OnlineTableColumnVO> columnList;
    @Schema(description="\u8868\u63cf\u8ff0")
    private /* synthetic */ String comments;

    public List<OnlineTableColumnVO> getColumnList() {
        OnlineTableVO fZub;
        return fZub.columnList;
    }

    public void setName(String myub) {
        Nyub.name = myub;
    }

    public void setTree(Integer oXub) {
        RXub.tree = oXub;
    }

    public Integer getTableType() {
        OnlineTableVO hZub;
        return hZub.tableType;
    }

    public Integer getFormLayout() {
        OnlineTableVO VZub;
        return VZub.formLayout;
    }

    public void setComments(String Eyub) {
        dyub.comments = Eyub;
    }

    private static boolean Zh(Object object) {
        return object != null;
    }

    private static void Vh() {
        Nd = new int[4];
        OnlineTableVO.Nd[0] = " ".length();
        OnlineTableVO.Nd[1] = (0xAC ^ 0x8A) & ~(0x89 ^ 0xAF);
        OnlineTableVO.Nd[2] = 0x36 ^ 0x31 ^ (0x32 ^ 0xE);
        OnlineTableVO.Nd[3] = 0x15 ^ 0x2B ^ (0x83 ^ 0x96);
    }

    private static boolean yh(Object object) {
        return object == null;
    }

    public void setId(String Tyub) {
        uyub.id = Tyub;
    }

    public boolean equals(Object TTub) {
        block89: {
            block90: {
                Date VTub;
                Date wTub;
                block88: {
                    OnlineTableVO suub;
                    OnlineTableVO uuub;
                    block86: {
                        block87: {
                            List<OnlineTableColumnVO> XTub;
                            List<OnlineTableColumnVO> yTub;
                            block85: {
                                block83: {
                                    block84: {
                                        String ZTub;
                                        String Auub;
                                        block82: {
                                            block80: {
                                                block81: {
                                                    String buub;
                                                    String Cuub;
                                                    block79: {
                                                        block77: {
                                                            block78: {
                                                                String duub;
                                                                String Euub;
                                                                block76: {
                                                                    block74: {
                                                                        block75: {
                                                                            String fuub;
                                                                            String Guub;
                                                                            block73: {
                                                                                block71: {
                                                                                    block72: {
                                                                                        String huub;
                                                                                        String Juub;
                                                                                        block70: {
                                                                                            block68: {
                                                                                                block69: {
                                                                                                    Integer kuub;
                                                                                                    Integer Luub;
                                                                                                    block67: {
                                                                                                        block65: {
                                                                                                            block66: {
                                                                                                                Integer muub;
                                                                                                                Integer Nuub;
                                                                                                                block64: {
                                                                                                                    block62: {
                                                                                                                        block63: {
                                                                                                                            Integer ouub;
                                                                                                                            Integer Puub;
                                                                                                                            block61: {
                                                                                                                                block59: {
                                                                                                                                    block60: {
                                                                                                                                        Integer quub;
                                                                                                                                        Integer Ruub;
                                                                                                                                        block58: {
                                                                                                                                            if (OnlineTableVO.wh(TTub, uuub)) {
                                                                                                                                                return Nd[0];
                                                                                                                                            }
                                                                                                                                            if (OnlineTableVO.Xh(TTub instanceof OnlineTableVO)) {
                                                                                                                                                return Nd[1];
                                                                                                                                            }
                                                                                                                                            suub = (OnlineTableVO)TTub;
                                                                                                                                            if (OnlineTableVO.Xh(suub.canEqual(uuub) ? 1 : 0)) {
                                                                                                                                                return Nd[1];
                                                                                                                                            }
                                                                                                                                            Ruub = uuub.getFormLayout();
                                                                                                                                            quub = suub.getFormLayout();
                                                                                                                                            if (!OnlineTableVO.yh(Ruub)) break block58;
                                                                                                                                            if (!OnlineTableVO.Zh(quub)) break block59;
                                                                                                                                            "".length();
                                                                                                                                            if (" ".length() > "   ".length()) {
                                                                                                                                                return ("   ".length() & ("   ".length() ^ -" ".length())) != 0;
                                                                                                                                            }
                                                                                                                                            break block60;
                                                                                                                                        }
                                                                                                                                        if (!OnlineTableVO.Xh(((Object)Ruub).equals(quub) ? 1 : 0)) break block59;
                                                                                                                                    }
                                                                                                                                    return Nd[1];
                                                                                                                                }
                                                                                                                                Puub = uuub.getTree();
                                                                                                                                ouub = suub.getTree();
                                                                                                                                if (!OnlineTableVO.yh(Puub)) break block61;
                                                                                                                                if (!OnlineTableVO.Zh(ouub)) break block62;
                                                                                                                                "".length();
                                                                                                                                if (null != null) {
                                                                                                                                    return ((0xF ^ 0x20) & ~(0x54 ^ 0x7B)) != 0;
                                                                                                                                }
                                                                                                                                break block63;
                                                                                                                            }
                                                                                                                            if (!OnlineTableVO.Xh(((Object)Puub).equals(ouub) ? 1 : 0)) break block62;
                                                                                                                        }
                                                                                                                        return Nd[1];
                                                                                                                    }
                                                                                                                    Nuub = uuub.getTableType();
                                                                                                                    muub = suub.getTableType();
                                                                                                                    if (!OnlineTableVO.yh(Nuub)) break block64;
                                                                                                                    if (!OnlineTableVO.Zh(muub)) break block65;
                                                                                                                    "".length();
                                                                                                                    if (null != null) {
                                                                                                                        return ((0x26 ^ 0x3B) & ~(0 ^ 0x1D)) != 0;
                                                                                                                    }
                                                                                                                    break block66;
                                                                                                                }
                                                                                                                if (!OnlineTableVO.Xh(((Object)Nuub).equals(muub) ? 1 : 0)) break block65;
                                                                                                            }
                                                                                                            return Nd[1];
                                                                                                        }
                                                                                                        Luub = uuub.getVersion();
                                                                                                        kuub = suub.getVersion();
                                                                                                        if (!OnlineTableVO.yh(Luub)) break block67;
                                                                                                        if (!OnlineTableVO.Zh(kuub)) break block68;
                                                                                                        "".length();
                                                                                                        if (null != null) {
                                                                                                            return ((0xFC ^ 0xBE) & ~(0xF2 ^ 0xB0)) != 0;
                                                                                                        }
                                                                                                        break block69;
                                                                                                    }
                                                                                                    if (!OnlineTableVO.Xh(((Object)Luub).equals(kuub) ? 1 : 0)) break block68;
                                                                                                }
                                                                                                return Nd[1];
                                                                                            }
                                                                                            Juub = uuub.getId();
                                                                                            huub = suub.getId();
                                                                                            if (!OnlineTableVO.yh(Juub)) break block70;
                                                                                            if (!OnlineTableVO.Zh(huub)) break block71;
                                                                                            "".length();
                                                                                            if ("  ".length() != "  ".length()) {
                                                                                                return ((0x7E ^ 0x4F ^ (0x25 ^ 0x3F)) & (49 + 79 - 79 + 134 ^ 4 + 60 - 37 + 129 ^ -" ".length())) != 0;
                                                                                            }
                                                                                            break block72;
                                                                                        }
                                                                                        if (!OnlineTableVO.Xh(Juub.equals(huub) ? 1 : 0)) break block71;
                                                                                    }
                                                                                    return Nd[1];
                                                                                }
                                                                                Guub = uuub.getName();
                                                                                fuub = suub.getName();
                                                                                if (!OnlineTableVO.yh(Guub)) break block73;
                                                                                if (!OnlineTableVO.Zh(fuub)) break block74;
                                                                                "".length();
                                                                                if ("   ".length() <= " ".length()) {
                                                                                    return ((143 + 123 - 206 + 126 ^ 143 + 92 - 181 + 114) & (0xDC ^ 0x97 ^ (0x9D ^ 0xC4) ^ -" ".length())) != 0;
                                                                                }
                                                                                break block75;
                                                                            }
                                                                            if (!OnlineTableVO.Xh(Guub.equals(fuub) ? 1 : 0)) break block74;
                                                                        }
                                                                        return Nd[1];
                                                                    }
                                                                    Euub = uuub.getComments();
                                                                    duub = suub.getComments();
                                                                    if (!OnlineTableVO.yh(Euub)) break block76;
                                                                    if (!OnlineTableVO.Zh(duub)) break block77;
                                                                    "".length();
                                                                    if (null != null) {
                                                                        return ((0x18 ^ 0x53) & ~(0x1C ^ 0x57)) != 0;
                                                                    }
                                                                    break block78;
                                                                }
                                                                if (!OnlineTableVO.Xh(Euub.equals(duub) ? 1 : 0)) break block77;
                                                            }
                                                            return Nd[1];
                                                        }
                                                        Cuub = uuub.getTreePid();
                                                        buub = suub.getTreePid();
                                                        if (!OnlineTableVO.yh(Cuub)) break block79;
                                                        if (!OnlineTableVO.Zh(buub)) break block80;
                                                        "".length();
                                                        if ("  ".length() > "  ".length()) {
                                                            return ((73 + 19 - 5 + 42 ^ 42 + 164 - 77 + 49) & (85 + 143 - 143 + 105 ^ 93 + 14 - -21 + 13 ^ -" ".length())) != 0;
                                                        }
                                                        break block81;
                                                    }
                                                    if (!OnlineTableVO.Xh(Cuub.equals(buub) ? 1 : 0)) break block80;
                                                }
                                                return Nd[1];
                                            }
                                            Auub = uuub.getTreeLabel();
                                            ZTub = suub.getTreeLabel();
                                            if (!OnlineTableVO.yh(Auub)) break block82;
                                            if (!OnlineTableVO.Zh(ZTub)) break block83;
                                            "".length();
                                            if (-"  ".length() >= 0) {
                                                return ((0x78 ^ 4 ^ (0x66 ^ 0x3E)) & (0x71 ^ 0x1E ^ (0xEC ^ 0xA7) ^ -" ".length())) != 0;
                                            }
                                            break block84;
                                        }
                                        if (!OnlineTableVO.Xh(Auub.equals(ZTub) ? 1 : 0)) break block83;
                                    }
                                    return Nd[1];
                                }
                                yTub = uuub.getColumnList();
                                XTub = suub.getColumnList();
                                if (!OnlineTableVO.yh(yTub)) break block85;
                                if (!OnlineTableVO.Zh(XTub)) break block86;
                                "".length();
                                if (" ".length() < 0) {
                                    return ((0x8A ^ 0xB3) & ~(0x25 ^ 0x1C)) != 0;
                                }
                                break block87;
                            }
                            if (!OnlineTableVO.Xh(((Object)yTub).equals(XTub) ? 1 : 0)) break block86;
                        }
                        return Nd[1];
                    }
                    wTub = uuub.getCreateTime();
                    VTub = suub.getCreateTime();
                    if (!OnlineTableVO.yh(wTub)) break block88;
                    if (!OnlineTableVO.Zh(VTub)) break block89;
                    "".length();
                    if (-" ".length() >= " ".length()) {
                        return ((0xF3 ^ 0x98 ^ (0x26 ^ 0xE)) & (0x7D ^ 0x1A ^ (8 ^ 0x2C) ^ -" ".length())) != 0;
                    }
                    break block90;
                }
                if (!OnlineTableVO.Xh(((Object)wTub).equals(VTub) ? 1 : 0)) break block89;
            }
            return Nd[1];
        }
        return Nd[0];
    }

    public String getName() {
        OnlineTableVO bAVb;
        return bAVb.name;
    }

    public String getTreeLabel() {
        OnlineTableVO LZub;
        return LZub.treeLabel;
    }

    static {
        OnlineTableVO.Vh();
    }

    private static boolean wh(Object object, Object object2) {
        return object == object2;
    }

    public void setFormLayout(Integer XXub) {
        yXub.formLayout = XXub;
    }

    public String getTreePid() {
        OnlineTableVO oZub;
        return oZub.treePid;
    }

    public String getId() {
        OnlineTableVO EAVb;
        return EAVb.id;
    }

    public String toString() {
        OnlineTableVO Vqub;
        return "OnlineTableVO(id=" + Vqub.getId() + ", name=" + Vqub.getName() + ", comments=" + Vqub.getComments() + ", formLayout=" + Vqub.getFormLayout() + ", tree=" + Vqub.getTree() + ", treePid=" + Vqub.getTreePid() + ", treeLabel=" + Vqub.getTreeLabel() + ", tableType=" + Vqub.getTableType() + ", columnList=" + Vqub.getColumnList() + ", version=" + Vqub.getVersion() + ", createTime=" + Vqub.getCreateTime() + ")";
    }

    public Date getCreateTime() {
        OnlineTableVO Zyub;
        return Zyub.createTime;
    }

    public Integer getTree() {
        OnlineTableVO RZub;
        return RZub.tree;
    }

    public void setColumnList(List<OnlineTableColumnVO> Lwub) {
        mwub.columnList = Lwub;
    }

    public String getComments() {
        OnlineTableVO yZub;
        return yZub.comments;
    }

    public Integer getVersion() {
        OnlineTableVO bZub;
        return bZub.version;
    }

    public void setTreePid(String JXub) {
        hXub.treePid = JXub;
    }

    public void setTableType(Integer uwub) {
        Twub.tableType = uwub;
    }

    protected boolean canEqual(Object qsub) {
        return qsub instanceof OnlineTableVO;
    }

    private static boolean Xh(int n) {
        return n == 0;
    }

    public OnlineTableVO() {
        OnlineTableVO hAVb;
    }

    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    public void setCreateTime(Date yVub) {
        XVub.createTime = yVub;
    }

    public int hashCode() {
        int n;
        int n2;
        int n3;
        int n4;
        int n5;
        int n6;
        int n7;
        int n8;
        int n9;
        int n10;
        int n11;
        OnlineTableVO Asub;
        int ZRub = Nd[2];
        int yRub = Nd[0];
        Integer XRub = Asub.getFormLayout();
        int n12 = yRub * Nd[2];
        if (OnlineTableVO.yh(XRub)) {
            n11 = Nd[3];
            "".length();
            if ("   ".length() < 0) {
                return (0x40 ^ 0xC) & ~(0x73 ^ 0x3F);
            }
        } else {
            n11 = ((Object)XRub).hashCode();
        }
        yRub = n12 + n11;
        Integer wRub = Asub.getTree();
        int n13 = yRub * Nd[2];
        if (OnlineTableVO.yh(wRub)) {
            n10 = Nd[3];
            "".length();
            if (null != null) {
                return (25 + 143 - -10 + 52 ^ 41 + 164 - 180 + 143) & (147 + 150 - 258 + 215 ^ 39 + 35 - -32 + 70 ^ -" ".length());
            }
        } else {
            n10 = ((Object)wRub).hashCode();
        }
        yRub = n13 + n10;
        Integer VRub = Asub.getTableType();
        int n14 = yRub * Nd[2];
        if (OnlineTableVO.yh(VRub)) {
            n9 = Nd[3];
            "".length();
            if (((106 + 101 - 95 + 101 ^ 42 + 0 - 37 + 192) & (0x77 ^ 0x39 ^ (0xFD ^ 0xA3) ^ -" ".length())) >= " ".length()) {
                return (170 + 68 - 115 + 49 ^ 114 + 51 - 31 + 2) & (88 + 81 - 153 + 145 ^ 92 + 63 - 53 + 31 ^ -" ".length());
            }
        } else {
            n9 = ((Object)VRub).hashCode();
        }
        yRub = n14 + n9;
        Integer uRub = Asub.getVersion();
        int n15 = yRub * Nd[2];
        if (OnlineTableVO.yh(uRub)) {
            n8 = Nd[3];
            "".length();
            if ("  ".length() < 0) {
                return (0x6F ^ 0x78) & ~(0x1E ^ 9);
            }
        } else {
            n8 = ((Object)uRub).hashCode();
        }
        yRub = n15 + n8;
        String TRub = Asub.getId();
        int n16 = yRub * Nd[2];
        if (OnlineTableVO.yh(TRub)) {
            n7 = Nd[3];
            "".length();
            if (" ".length() <= 0) {
                return (86 + 135 - 126 + 104 ^ 116 + 105 - 176 + 88) & (0x3D ^ 0x36 ^ (0x8B ^ 0xC2) ^ -" ".length());
            }
        } else {
            n7 = TRub.hashCode();
        }
        yRub = n16 + n7;
        String sRub = Asub.getName();
        int n17 = yRub * Nd[2];
        if (OnlineTableVO.yh(sRub)) {
            n6 = Nd[3];
            "".length();
            if ((167 + 99 - 234 + 140 ^ 14 + 107 - 40 + 87) < -" ".length()) {
                return (0x73 ^ 0x47 ^ (0x1C ^ 0x74)) & (124 + 33 - 87 + 133 ^ 104 + 11 - 29 + 65 ^ -" ".length());
            }
        } else {
            n6 = sRub.hashCode();
        }
        yRub = n17 + n6;
        String RRub = Asub.getComments();
        int n18 = yRub * Nd[2];
        if (OnlineTableVO.yh(RRub)) {
            n5 = Nd[3];
            "".length();
            if (-(4 ^ 8 ^ (0x1F ^ 0x17)) >= 0) {
                return (49 + 20 - -61 + 51 ^ 152 + 94 - 109 + 25) & (8 ^ 0x52 ^ (0x74 ^ 0x39) ^ -" ".length());
            }
        } else {
            n5 = RRub.hashCode();
        }
        yRub = n18 + n5;
        String qRub = Asub.getTreePid();
        int n19 = yRub * Nd[2];
        if (OnlineTableVO.yh(qRub)) {
            n4 = Nd[3];
            "".length();
            if (((0x5A ^ 0x43 ^ (9 ^ 0x46)) & (0x97 ^ 0x85 ^ (0x24 ^ 0x60) ^ -" ".length())) != 0) {
                return (0xF ^ 0x3F ^ (0x5E ^ 0x6B)) & (0x18 ^ 0x58 ^ (0xCE ^ 0x8B) ^ -" ".length());
            }
        } else {
            n4 = qRub.hashCode();
        }
        yRub = n19 + n4;
        String PRub = Asub.getTreeLabel();
        int n20 = yRub * Nd[2];
        if (OnlineTableVO.yh(PRub)) {
            n3 = Nd[3];
            "".length();
            if (((0xBC ^ 0x9C ^ (0x1B ^ 0x67)) & (0x62 ^ 0x43 ^ (0xCB ^ 0xB6) ^ -" ".length())) == " ".length()) {
                return (0x53 ^ 0x2D ^ (0x6A ^ 0x12)) & (89 + 114 - 182 + 177 ^ 133 + 142 - 127 + 44 ^ -" ".length());
            }
        } else {
            n3 = PRub.hashCode();
        }
        yRub = n20 + n3;
        List<OnlineTableColumnVO> oRub = Asub.getColumnList();
        int n21 = yRub * Nd[2];
        if (OnlineTableVO.yh(oRub)) {
            n2 = Nd[3];
            "".length();
            if ((0xA6 ^ 0xA3) == 0) {
                return (0xB9 ^ 0xA0) & ~(0x8F ^ 0x96);
            }
        } else {
            n2 = ((Object)oRub).hashCode();
        }
        yRub = n21 + n2;
        Date NRub = Asub.getCreateTime();
        int n22 = yRub * Nd[2];
        if (OnlineTableVO.yh(NRub)) {
            n = Nd[3];
            "".length();
            if (((6 ^ 0x12 ^ (0xE9 ^ 0xB8)) & (209 + 58 - 109 + 93 ^ 147 + 127 - 196 + 112 ^ -" ".length())) > (0xDA ^ 0x86 ^ (4 ^ 0x5C))) {
                return (15 + 37 - -18 + 61 ^ 129 + 82 - 210 + 184) & (34 + 103 - 100 + 102 ^ 20 + 87 - -30 + 40 ^ -" ".length());
            }
        } else {
            n = ((Object)NRub).hashCode();
        }
        yRub = n22 + n;
        return yRub;
    }

    public void setTreeLabel(String bXub) {
        AXub.treeLabel = bXub;
    }

    public void setVersion(Integer fwub) {
        Gwub.version = fwub;
    }
}

