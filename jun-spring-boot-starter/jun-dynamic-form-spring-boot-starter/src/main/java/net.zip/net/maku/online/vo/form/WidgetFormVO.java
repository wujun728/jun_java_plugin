/*
 * Decompiled with CFR 0.152.
 */
package net.maku.online.vo.form;

import java.util.List;
import java.util.Map;
import net.maku.online.vo.form.WidgetFormConfigVO;

public class WidgetFormVO {
    private /* synthetic */ List<Map<String, Object>> list;
    private /* synthetic */ WidgetFormConfigVO config;
    private static /* synthetic */ int[] LC;

    public boolean equals(Object RCyb) {
        block17: {
            block18: {
                WidgetFormConfigVO mCyb;
                WidgetFormConfigVO NCyb;
                block16: {
                    WidgetFormVO qCyb;
                    WidgetFormVO sCyb;
                    block14: {
                        block15: {
                            List<Map<String, Object>> oCyb;
                            List<Map<String, Object>> PCyb;
                            block13: {
                                if (WidgetFormVO.VE(RCyb, sCyb)) {
                                    return LC[0];
                                }
                                if (WidgetFormVO.wE(RCyb instanceof WidgetFormVO)) {
                                    return LC[1];
                                }
                                qCyb = (WidgetFormVO)RCyb;
                                if (WidgetFormVO.wE(qCyb.canEqual(sCyb) ? 1 : 0)) {
                                    return LC[1];
                                }
                                PCyb = sCyb.getList();
                                oCyb = qCyb.getList();
                                if (!WidgetFormVO.XE(PCyb)) break block13;
                                if (!WidgetFormVO.yE(oCyb)) break block14;
                                "".length();
                                if ("   ".length() != "   ".length()) {
                                    return ((0x2A ^ 0x62 ^ (0xAF ^ 0xA7)) & (0x48 ^ 2 ^ (0x2E ^ 0x24) ^ -" ".length())) != 0;
                                }
                                break block15;
                            }
                            if (!WidgetFormVO.wE(((Object)PCyb).equals(oCyb) ? 1 : 0)) break block14;
                        }
                        return LC[1];
                    }
                    NCyb = sCyb.getConfig();
                    mCyb = qCyb.getConfig();
                    if (!WidgetFormVO.XE(NCyb)) break block16;
                    if (!WidgetFormVO.yE(mCyb)) break block17;
                    "".length();
                    if (-"  ".length() >= 0) {
                        return ((0x7B ^ 0x59 ^ (0x13 ^ 0x1A)) & (0xCC ^ 0xA1 ^ (8 ^ 0x4E) ^ -" ".length())) != 0;
                    }
                    break block18;
                }
                if (!WidgetFormVO.wE(((Object)NCyb).equals(mCyb) ? 1 : 0)) break block17;
            }
            return LC[1];
        }
        return LC[0];
    }

    private static boolean VE(Object object, Object object2) {
        return object == object2;
    }

    private static boolean yE(Object object) {
        return object != null;
    }

    public void setList(List<Map<String, Object>> Ldyb) {
        kdyb.list = Ldyb;
    }

    protected boolean canEqual(Object Zbyb) {
        return Zbyb instanceof WidgetFormVO;
    }

    public void setConfig(WidgetFormConfigVO ddyb) {
        Cdyb.config = ddyb;
    }

    static {
        WidgetFormVO.uE();
    }

    public WidgetFormVO() {
        WidgetFormVO Xdyb;
    }

    public WidgetFormConfigVO getConfig() {
        WidgetFormVO qdyb;
        return qdyb.config;
    }

    private static boolean XE(Object object) {
        return object == null;
    }

    private static void uE() {
        LC = new int[4];
        WidgetFormVO.LC[0] = " ".length();
        WidgetFormVO.LC[1] = (0x77 ^ 0x55) & ~(0x53 ^ 0x71);
        WidgetFormVO.LC[2] = 0x3F ^ 0x1C ^ (0x93 ^ 0x8B);
        WidgetFormVO.LC[3] = 0x42 ^ 0x69;
    }

    private static boolean wE(int n) {
        return n == 0;
    }

    public List<Map<String, Object>> getList() {
        WidgetFormVO udyb;
        return udyb.list;
    }

    public String toString() {
        WidgetFormVO Gbyb;
        return "WidgetFormVO(list=" + Gbyb.getList() + ", config=" + Gbyb.getConfig() + ")";
    }

    public int hashCode() {
        int n;
        int n2;
        WidgetFormVO obyb;
        int sbyb = LC[2];
        int Rbyb = LC[0];
        List<Map<String, Object>> qbyb = obyb.getList();
        int n3 = Rbyb * LC[2];
        if (WidgetFormVO.XE(qbyb)) {
            n2 = LC[3];
            "".length();
            if (" ".length() <= -" ".length()) {
                return (0x5B ^ 0x6A ^ (0x84 ^ 0xA9)) & (0x5C ^ 0x26 ^ (0x3D ^ 0x5B) ^ -" ".length());
            }
        } else {
            n2 = ((Object)qbyb).hashCode();
        }
        Rbyb = n3 + n2;
        WidgetFormConfigVO Pbyb = obyb.getConfig();
        int n4 = Rbyb * LC[2];
        if (WidgetFormVO.XE(Pbyb)) {
            n = LC[3];
            "".length();
            if ((0x2D ^ 0x29) == " ".length()) {
                return (0x4F ^ 0x58) & ~(0x2F ^ 0x38);
            }
        } else {
            n = ((Object)Pbyb).hashCode();
        }
        Rbyb = n4 + n;
        return Rbyb;
    }
}

