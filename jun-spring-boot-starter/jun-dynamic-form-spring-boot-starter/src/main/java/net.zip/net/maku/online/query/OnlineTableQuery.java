/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.swagger.v3.oas.annotations.media.Schema
 *  net.maku.framework.common.query.Query
 */
package net.maku.online.query;

import io.swagger.v3.oas.annotations.media.Schema;
import net.maku.framework.common.query.Query;

@Schema(description="Online\u8868\u5355\u5f00\u53d1\u67e5\u8be2")
public class OnlineTableQuery
extends Query {
    @Schema(description="\u8868\u63cf\u8ff0")
    private /* synthetic */ String comments;
    private static /* synthetic */ int[] hd;
    @Schema(description="\u8868\u540d")
    private /* synthetic */ String name;

    protected boolean canEqual(Object mRVb) {
        return mRVb instanceof OnlineTableQuery;
    }

    public void setComments(String ssVb) {
        RsVb.comments = ssVb;
    }

    private static boolean Lh(int n) {
        return n == 0;
    }

    public boolean equals(Object VRVb) {
        block17: {
            block18: {
                String XRVb;
                String yRVb;
                block16: {
                    OnlineTableQuery bsVb;
                    OnlineTableQuery dsVb;
                    block14: {
                        block15: {
                            String ZRVb;
                            String AsVb;
                            block13: {
                                if (OnlineTableQuery.kh(VRVb, (Object)dsVb)) {
                                    return hd[0];
                                }
                                if (OnlineTableQuery.Lh(VRVb instanceof OnlineTableQuery)) {
                                    return hd[1];
                                }
                                bsVb = (OnlineTableQuery)((Object)VRVb);
                                if (OnlineTableQuery.Lh(bsVb.canEqual((Object)dsVb) ? 1 : 0)) {
                                    return hd[1];
                                }
                                AsVb = dsVb.getName();
                                ZRVb = bsVb.getName();
                                if (!OnlineTableQuery.mh(AsVb)) break block13;
                                if (!OnlineTableQuery.Nh(ZRVb)) break block14;
                                "".length();
                                if (-" ".length() >= "   ".length()) {
                                    return ((0xA ^ 0x58) & ~(0x34 ^ 0x66)) != 0;
                                }
                                break block15;
                            }
                            if (!OnlineTableQuery.Lh(AsVb.equals(ZRVb) ? 1 : 0)) break block14;
                        }
                        return hd[1];
                    }
                    yRVb = dsVb.getComments();
                    XRVb = bsVb.getComments();
                    if (!OnlineTableQuery.mh(yRVb)) break block16;
                    if (!OnlineTableQuery.Nh(XRVb)) break block17;
                    "".length();
                    if (null != null) {
                        return ((4 ^ 0x43 ^ (0xBD ^ 0xA5)) & (0x42 ^ 0x73 ^ (0x50 ^ 0x3E) ^ -" ".length())) != 0;
                    }
                    break block18;
                }
                if (!OnlineTableQuery.Lh(yRVb.equals(XRVb) ? 1 : 0)) break block17;
            }
            return hd[1];
        }
        return hd[0];
    }

    public String toString() {
        OnlineTableQuery NsVb;
        return "OnlineTableQuery(name=" + NsVb.getName() + ", comments=" + NsVb.getComments() + ")";
    }

    public OnlineTableQuery() {
        OnlineTableQuery mTVb;
    }

    public int hashCode() {
        int n;
        int n2;
        OnlineTableQuery ZqVb;
        int dRVb = hd[2];
        int CRVb = hd[0];
        String bRVb = ZqVb.getName();
        int n3 = CRVb * hd[2];
        if (OnlineTableQuery.mh(bRVb)) {
            n2 = hd[3];
            "".length();
            if (-" ".length() >= 0) {
                return (0x6A ^ 0x3C) & ~(0x6F ^ 0x39);
            }
        } else {
            n2 = bRVb.hashCode();
        }
        CRVb = n3 + n2;
        String ARVb = ZqVb.getComments();
        int n4 = CRVb * hd[2];
        if (OnlineTableQuery.mh(ARVb)) {
            n = hd[3];
            "".length();
            if ("   ".length() < -" ".length()) {
                return (0x8D ^ 0xC4) & ~(0x4E ^ 7);
            }
        } else {
            n = ARVb.hashCode();
        }
        CRVb = n4 + n;
        return CRVb;
    }

    public String getComments() {
        OnlineTableQuery fTVb;
        return fTVb.comments;
    }

    static {
        OnlineTableQuery.Jh();
    }

    public void setName(String XsVb) {
        ATVb.name = XsVb;
    }

    private static void Jh() {
        hd = new int[4];
        OnlineTableQuery.hd[0] = " ".length();
        OnlineTableQuery.hd[1] = (0x4B ^ 0x16) & ~(0x72 ^ 0x2F);
        OnlineTableQuery.hd[2] = 0x72 ^ 0x6C ^ (0x29 ^ 0xC);
        OnlineTableQuery.hd[3] = 0x49 ^ 0x62;
    }

    private static boolean Nh(Object object) {
        return object != null;
    }

    public String getName() {
        OnlineTableQuery JTVb;
        return JTVb.name;
    }

    private static boolean mh(Object object) {
        return object == null;
    }

    private static boolean kh(Object object, Object object2) {
        return object == object2;
    }
}

