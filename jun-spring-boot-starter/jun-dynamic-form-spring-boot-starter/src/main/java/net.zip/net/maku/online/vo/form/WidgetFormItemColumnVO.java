/*
 * Decompiled with CFR 0.152.
 */
package net.maku.online.vo.form;

import java.util.List;
import net.maku.online.vo.form.WidgetFormItemVO;

public class WidgetFormItemColumnVO {
    private /* synthetic */ List<WidgetFormItemVO> list;
    private /* synthetic */ Integer number;
    private static /* synthetic */ int[] hf;

    private static boolean LN(Object object) {
        return object != null;
    }

    public Integer getNumber() {
        WidgetFormItemColumnVO fVRb;
        return fVRb.number;
    }

    public int hashCode() {
        int n;
        int n2;
        WidgetFormItemColumnVO ETRb;
        int dTRb = hf[2];
        int CTRb = hf[0];
        Integer bTRb = ETRb.getNumber();
        int n3 = CTRb * hf[2];
        if (WidgetFormItemColumnVO.kN(bTRb)) {
            n2 = hf[3];
            "".length();
            if (((0x25 ^ 0x6B) & ~(0x24 ^ 0x6A)) != 0) {
                return (0x78 ^ 0x4A) & ~(0x55 ^ 0x67);
            }
        } else {
            n2 = ((Object)bTRb).hashCode();
        }
        CTRb = n3 + n2;
        List<WidgetFormItemVO> ATRb = ETRb.getList();
        int n4 = CTRb * hf[2];
        if (WidgetFormItemColumnVO.kN(ATRb)) {
            n = hf[3];
            "".length();
            if (null != null) {
                return ((0xA ^ 0x20) & ~(0x5F ^ 0x75) ^ (0x52 ^ 0x5A)) & (0xBF ^ 0x94 ^ (0x18 ^ 0x3B) ^ -" ".length());
            }
        } else {
            n = ((Object)ATRb).hashCode();
        }
        CTRb = n4 + n;
        return CTRb;
    }

    public String toString() {
        WidgetFormItemColumnVO ssRb;
        return "WidgetFormItemColumnVO(number=" + ssRb.getNumber() + ", list=" + ssRb.getList() + ")";
    }

    private static boolean hN(Object object, Object object2) {
        return object == object2;
    }

    public List<WidgetFormItemVO> getList() {
        WidgetFormItemColumnVO CVRb;
        return CVRb.list;
    }

    public boolean equals(Object CuRb) {
        block17: {
            block18: {
                List<WidgetFormItemVO> XTRb;
                List<WidgetFormItemVO> yTRb;
                block16: {
                    WidgetFormItemColumnVO buRb;
                    WidgetFormItemColumnVO duRb;
                    block14: {
                        block15: {
                            Integer ZTRb;
                            Integer AuRb;
                            block13: {
                                if (WidgetFormItemColumnVO.hN(CuRb, duRb)) {
                                    return hf[0];
                                }
                                if (WidgetFormItemColumnVO.JN(CuRb instanceof WidgetFormItemColumnVO)) {
                                    return hf[1];
                                }
                                buRb = (WidgetFormItemColumnVO)CuRb;
                                if (WidgetFormItemColumnVO.JN(buRb.canEqual(duRb) ? 1 : 0)) {
                                    return hf[1];
                                }
                                AuRb = duRb.getNumber();
                                ZTRb = buRb.getNumber();
                                if (!WidgetFormItemColumnVO.kN(AuRb)) break block13;
                                if (!WidgetFormItemColumnVO.LN(ZTRb)) break block14;
                                "".length();
                                if ("  ".length() != "  ".length()) {
                                    return ((0xDA ^ 0xC4) & ~(0x8B ^ 0x95)) != 0;
                                }
                                break block15;
                            }
                            if (!WidgetFormItemColumnVO.JN(((Object)AuRb).equals(ZTRb) ? 1 : 0)) break block14;
                        }
                        return hf[1];
                    }
                    yTRb = duRb.getList();
                    XTRb = buRb.getList();
                    if (!WidgetFormItemColumnVO.kN(yTRb)) break block16;
                    if (!WidgetFormItemColumnVO.LN(XTRb)) break block17;
                    "".length();
                    if (-(0xB5 ^ 0xAF ^ (0x1A ^ 5)) >= 0) {
                        return ((137 + 87 - 90 + 50 ^ 26 + 4 - -15 + 92) & (0x25 ^ 0x12 ^ (0x3E ^ 0x38) ^ -" ".length())) != 0;
                    }
                    break block18;
                }
                if (!WidgetFormItemColumnVO.JN(((Object)yTRb).equals(XTRb) ? 1 : 0)) break block17;
            }
            return hf[1];
        }
        return hf[0];
    }

    private static void GN() {
        hf = new int[4];
        WidgetFormItemColumnVO.hf[0] = " ".length();
        WidgetFormItemColumnVO.hf[1] = (0x57 ^ 0x7A) & ~(0xAF ^ 0x82);
        WidgetFormItemColumnVO.hf[2] = 0x4B ^ 0x55 ^ (0x63 ^ 0x46);
        WidgetFormItemColumnVO.hf[3] = 0x1F ^ 0x34;
    }

    private static boolean JN(int n) {
        return n == 0;
    }

    private static boolean kN(Object object) {
        return object == null;
    }

    public void setList(List<WidgetFormItemVO> PuRb) {
        quRb.list = PuRb;
    }

    public WidgetFormItemColumnVO() {
        WidgetFormItemColumnVO hVRb;
    }

    static {
        WidgetFormItemColumnVO.GN();
    }

    public void setNumber(Integer wuRb) {
        XuRb.number = wuRb;
    }

    protected boolean canEqual(Object mTRb) {
        return mTRb instanceof WidgetFormItemColumnVO;
    }
}

