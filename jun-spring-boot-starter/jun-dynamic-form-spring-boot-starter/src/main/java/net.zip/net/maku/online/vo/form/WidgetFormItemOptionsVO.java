/*
 * Decompiled with CFR 0.152.
 */
package net.maku.online.vo.form;

public class WidgetFormItemOptionsVO {
    private /* synthetic */ String defaultValue;
    private /* synthetic */ boolean allowHalf;
    private /* synthetic */ boolean clearable;
    private /* synthetic */ String options;
    private /* synthetic */ boolean multiple;
    private /* synthetic */ String placeholder;
    private /* synthetic */ boolean isRange;
    private /* synthetic */ Integer step;
    private /* synthetic */ boolean readonly;
    private /* synthetic */ boolean showPassword;
    private /* synthetic */ boolean filterable;
    private /* synthetic */ String controlsPosition;
    private /* synthetic */ Integer maxlength;
    private /* synthetic */ String startPlaceholder;
    private /* synthetic */ String endPlaceholder;
    private /* synthetic */ boolean showWordLimit;
    private /* synthetic */ String type;
    private /* synthetic */ Integer gutter;
    private /* synthetic */ Integer min;
    private /* synthetic */ String justify;
    private /* synthetic */ String rules;
    private /* synthetic */ String width;
    private /* synthetic */ Integer precision;
    private /* synthetic */ Integer rows;
    private /* synthetic */ Integer max;
    private /* synthetic */ boolean button;
    private static /* synthetic */ int[] ZC;
    private /* synthetic */ String format;
    private /* synthetic */ String align;
    private /* synthetic */ boolean disabled;
    private /* synthetic */ boolean labelHide;

    public boolean isShowPassword() {
        WidgetFormItemOptionsVO fmwb;
        return fmwb.showPassword;
    }

    public String getFormat() {
        WidgetFormItemOptionsVO yNwb;
        return yNwb.format;
    }

    public void setShowPassword(boolean udwb) {
        Xdwb.showPassword = udwb;
    }

    public void setWidth(String ALwb) {
        Zkwb.width = ALwb;
    }

    private static boolean Gh(int n) {
        return n != 0;
    }

    public Integer getGutter() {
        WidgetFormItemOptionsVO uLwb;
        return uLwb.gutter;
    }

    public Integer getMax() {
        WidgetFormItemOptionsVO Lowb;
        return Lowb.max;
    }

    public void setMaxlength(Integer Rkwb) {
        skwb.maxlength = Rkwb;
    }

    public void setPrecision(Integer GJwb) {
        kJwb.precision = GJwb;
    }

    private static boolean RG(Object object) {
        return object != null;
    }

    public void setJustify(String kCwb) {
        NCwb.justify = kCwb;
    }

    public String getType() {
        WidgetFormItemOptionsVO Vmwb;
        return Vmwb.type;
    }

    public boolean isMultiple() {
        WidgetFormItemOptionsVO LNwb;
        return LNwb.multiple;
    }

    public String toString() {
        WidgetFormItemOptionsVO EuVb;
        return "WidgetFormItemOptionsVO(defaultValue=" + EuVb.getDefaultValue() + ", width=" + EuVb.getWidth() + ", maxlength=" + EuVb.getMaxlength() + ", rows=" + EuVb.getRows() + ", min=" + EuVb.getMin() + ", max=" + EuVb.getMax() + ", step=" + EuVb.getStep() + ", precision=" + EuVb.getPrecision() + ", controlsPosition=" + EuVb.getControlsPosition() + ", format=" + EuVb.getFormat() + ", button=" + EuVb.isButton() + ", allowHalf=" + EuVb.isAllowHalf() + ", filterable=" + EuVb.isFilterable() + ", multiple=" + EuVb.isMultiple() + ", isRange=" + EuVb.isRange() + ", placeholder=" + EuVb.getPlaceholder() + ", startPlaceholder=" + EuVb.getStartPlaceholder() + ", endPlaceholder=" + EuVb.getEndPlaceholder() + ", type=" + EuVb.getType() + ", labelHide=" + EuVb.isLabelHide() + ", disabled=" + EuVb.isDisabled() + ", readonly=" + EuVb.isReadonly() + ", clearable=" + EuVb.isClearable() + ", showPassword=" + EuVb.isShowPassword() + ", showWordLimit=" + EuVb.isShowWordLimit() + ", options=" + EuVb.getOptions() + ", rules=" + EuVb.getRules() + ", gutter=" + EuVb.getGutter() + ", justify=" + EuVb.getJustify() + ", align=" + EuVb.getAlign() + ")";
    }

    public Integer getMin() {
        WidgetFormItemOptionsVO Nowb;
        return Nowb.min;
    }

    public boolean isShowWordLimit() {
        WidgetFormItemOptionsVO Cmwb;
        return Cmwb.showWordLimit;
    }

    public boolean isReadonly() {
        WidgetFormItemOptionsVO Nmwb;
        return Nmwb.readonly;
    }

    private static boolean NG(Object object, Object object2) {
        return object == object2;
    }

    protected boolean canEqual(Object ywVb) {
        return ywVb instanceof WidgetFormItemOptionsVO;
    }

    public void setAlign(String CCwb) {
        dCwb.align = CCwb;
    }

    public void setMax(Integer XJwb) {
        yJwb.max = XJwb;
    }

    public Integer getMaxlength() {
        WidgetFormItemOptionsVO Towb;
        return Towb.maxlength;
    }

    public void setReadonly(boolean JEwb) {
        mEwb.readonly = JEwb;
    }

    public WidgetFormItemOptionsVO() {
        WidgetFormItemOptionsVO CPwb;
    }

    public String getJustify() {
        WidgetFormItemOptionsVO qLwb;
        return qLwb.justify;
    }

    public void setMultiple(boolean RGwb) {
        qGwb.multiple = RGwb;
    }

    public String getPlaceholder() {
        WidgetFormItemOptionsVO fNwb;
        return fNwb.placeholder;
    }

    public Integer getRows() {
        WidgetFormItemOptionsVO Rowb;
        return Rowb.rows;
    }

    public Integer getStep() {
        WidgetFormItemOptionsVO howb;
        return howb.step;
    }

    public void setAllowHalf(boolean dhwb) {
        Ghwb.allowHalf = dhwb;
    }

    public void setMin(Integer Ckwb) {
        fkwb.min = Ckwb;
    }

    public boolean isLabelHide() {
        WidgetFormItemOptionsVO Tmwb;
        return Tmwb.labelHide;
    }

    private static boolean qG(Object object) {
        return object == null;
    }

    public String getAlign() {
        WidgetFormItemOptionsVO NLwb;
        return NLwb.align;
    }

    public void setStep(Integer oJwb) {
        RJwb.step = oJwb;
    }

    public String getWidth() {
        WidgetFormItemOptionsVO Xowb;
        return Xowb.width;
    }

    public void setEndPlaceholder(String mfwb) {
        Nfwb.endPlaceholder = mfwb;
    }

    private static void kG() {
        ZC = new int[6];
        WidgetFormItemOptionsVO.ZC[0] = " ".length();
        WidgetFormItemOptionsVO.ZC[1] = (198 + 85 - 197 + 151 ^ 99 + 152 - 120 + 56) & (51 + 197 - 190 + 168 ^ 11 + 152 - 106 + 123 ^ -" ".length());
        WidgetFormItemOptionsVO.ZC[2] = 0x2E ^ 0x5E ^ (0x23 ^ 0x68);
        WidgetFormItemOptionsVO.ZC[3] = 46 + 191 - 81 + 60 ^ 13 + 80 - -35 + 23;
        WidgetFormItemOptionsVO.ZC[4] = 225 + 58 - 129 + 87 ^ 7 + 54 - -68 + 15;
        WidgetFormItemOptionsVO.ZC[5] = 0x2A ^ 0x1A ^ (0xD8 ^ 0xC3);
    }

    public boolean isRange() {
        WidgetFormItemOptionsVO hNwb;
        return hNwb.isRange;
    }

    public void setGutter(Integer RCwb) {
        uCwb.gutter = RCwb;
    }

    public boolean isDisabled() {
        WidgetFormItemOptionsVO qmwb;
        return qmwb.disabled;
    }

    public String getStartPlaceholder() {
        WidgetFormItemOptionsVO CNwb;
        return CNwb.startPlaceholder;
    }

    public void setControlsPosition(String Zhwb) {
        CJwb.controlsPosition = Zhwb;
    }

    public void setDisabled(boolean qEwb) {
        REwb.disabled = qEwb;
    }

    public boolean isClearable() {
        WidgetFormItemOptionsVO Jmwb;
        return Jmwb.clearable;
    }

    public int hashCode() {
        int n;
        int n2;
        int n3;
        int n4;
        int n5;
        int n6;
        int n7;
        int n8;
        int n9;
        int n10;
        int n11;
        int n12;
        int n13;
        int n14;
        int n15;
        int n16;
        int n17;
        int n18;
        int n19;
        int n20;
        int n21;
        int n22;
        int n23;
        int n24;
        int n25;
        int n26;
        int n27;
        int n28;
        int n29;
        int n30;
        WidgetFormItemOptionsVO AwVb;
        int ZVVb = ZC[2];
        int yVVb = ZC[0];
        int n31 = yVVb * ZC[2];
        if (WidgetFormItemOptionsVO.Gh(AwVb.isButton() ? 1 : 0)) {
            n30 = ZC[3];
            "".length();
            if (null != null) {
                return (0x46 ^ 0x5E) & ~(0x7E ^ 0x66);
            }
        } else {
            n30 = ZC[4];
        }
        yVVb = n31 + n30;
        int n32 = yVVb * ZC[2];
        if (WidgetFormItemOptionsVO.Gh(AwVb.isAllowHalf() ? 1 : 0)) {
            n29 = ZC[3];
            "".length();
            if ("   ".length() != "   ".length()) {
                return (4 ^ 0x41) & ~(0xFA ^ 0xBF);
            }
        } else {
            n29 = ZC[4];
        }
        yVVb = n32 + n29;
        int n33 = yVVb * ZC[2];
        if (WidgetFormItemOptionsVO.Gh(AwVb.isFilterable() ? 1 : 0)) {
            n28 = ZC[3];
            "".length();
            if (null != null) {
                return (0xAF ^ 0x95 ^ (0x61 ^ 0x79)) & (0x6B ^ 0x19 ^ (0x35 ^ 0x65) ^ -" ".length());
            }
        } else {
            n28 = ZC[4];
        }
        yVVb = n33 + n28;
        int n34 = yVVb * ZC[2];
        if (WidgetFormItemOptionsVO.Gh(AwVb.isMultiple() ? 1 : 0)) {
            n27 = ZC[3];
            "".length();
            if ((0xE3 ^ 0x8E ^ (1 ^ 0x68)) < " ".length()) {
                return (0x3A ^ 0x13 ^ (0xEF ^ 0x94)) & (0x35 ^ 0x20 ^ (0x4C ^ 0xB) ^ -" ".length());
            }
        } else {
            n27 = ZC[4];
        }
        yVVb = n34 + n27;
        int n35 = yVVb * ZC[2];
        if (WidgetFormItemOptionsVO.Gh(AwVb.isRange() ? 1 : 0)) {
            n26 = ZC[3];
            "".length();
            if ("  ".length() <= ((0x9A ^ 0xC4) & ~(0x43 ^ 0x1D))) {
                return (0x5B ^ 0xD) & ~(0xFC ^ 0xAA);
            }
        } else {
            n26 = ZC[4];
        }
        yVVb = n35 + n26;
        int n36 = yVVb * ZC[2];
        if (WidgetFormItemOptionsVO.Gh(AwVb.isLabelHide() ? 1 : 0)) {
            n25 = ZC[3];
            "".length();
            if (null != null) {
                return (0x63 ^ 0x57) & ~(0x26 ^ 0x12);
            }
        } else {
            n25 = ZC[4];
        }
        yVVb = n36 + n25;
        int n37 = yVVb * ZC[2];
        if (WidgetFormItemOptionsVO.Gh(AwVb.isDisabled() ? 1 : 0)) {
            n24 = ZC[3];
            "".length();
            if (-" ".length() != -" ".length()) {
                return (0xD5 ^ 0x9F ^ (0x27 ^ 0x3D)) & (0x95 ^ 0x8F ^ (0x50 ^ 0x1A) ^ -" ".length());
            }
        } else {
            n24 = ZC[4];
        }
        yVVb = n37 + n24;
        int n38 = yVVb * ZC[2];
        if (WidgetFormItemOptionsVO.Gh(AwVb.isReadonly() ? 1 : 0)) {
            n23 = ZC[3];
            "".length();
            if ("  ".length() <= 0) {
                return (0xCC ^ 0x9A) & ~(0x50 ^ 6);
            }
        } else {
            n23 = ZC[4];
        }
        yVVb = n38 + n23;
        int n39 = yVVb * ZC[2];
        if (WidgetFormItemOptionsVO.Gh(AwVb.isClearable() ? 1 : 0)) {
            n22 = ZC[3];
            "".length();
            if ((0x73 ^ 0x55 ^ (0xE2 ^ 0xC0)) <= 0) {
                return (34 + 56 - 27 + 70 ^ 70 + 1 - -89 + 29) & (123 + 91 - 108 + 52 ^ 148 + 6 - 9 + 21 ^ -" ".length());
            }
        } else {
            n22 = ZC[4];
        }
        yVVb = n39 + n22;
        int n40 = yVVb * ZC[2];
        if (WidgetFormItemOptionsVO.Gh(AwVb.isShowPassword() ? 1 : 0)) {
            n21 = ZC[3];
            "".length();
            if (" ".length() <= 0) {
                return (0x86 ^ 0x9F) & ~(0x74 ^ 0x6D);
            }
        } else {
            n21 = ZC[4];
        }
        yVVb = n40 + n21;
        int n41 = yVVb * ZC[2];
        if (WidgetFormItemOptionsVO.Gh(AwVb.isShowWordLimit() ? 1 : 0)) {
            n20 = ZC[3];
            "".length();
            if (((0xAE ^ 0x9B) & ~(0x62 ^ 0x57)) != 0) {
                return (0x66 ^ 0x24) & ~(0x70 ^ 0x32);
            }
        } else {
            n20 = ZC[4];
        }
        yVVb = n41 + n20;
        Integer XVVb = AwVb.getMaxlength();
        int n42 = yVVb * ZC[2];
        if (WidgetFormItemOptionsVO.qG(XVVb)) {
            n19 = ZC[5];
            "".length();
            if (((0x72 ^ 0x51 ^ (0x3D ^ 0x31)) & (0x4B ^ 0x33 ^ (0xC6 ^ 0x91) ^ -" ".length())) == (0xF ^ 0x1A ^ (0x4A ^ 0x5B))) {
                return (61 + 106 - 83 + 64 ^ 28 + 15 - -89 + 21) & (0x90 ^ 0xC2 ^ (0x51 ^ 0xE) ^ -" ".length());
            }
        } else {
            n19 = ((Object)XVVb).hashCode();
        }
        yVVb = n42 + n19;
        Integer wVVb = AwVb.getRows();
        int n43 = yVVb * ZC[2];
        if (WidgetFormItemOptionsVO.qG(wVVb)) {
            n18 = ZC[5];
            "".length();
            if (" ".length() > " ".length()) {
                return (139 + 28 - -32 + 1 ^ 114 + 34 - 145 + 126) & (0x33 ^ 0x21 ^ (0xF0 ^ 0xAB) ^ -" ".length());
            }
        } else {
            n18 = ((Object)wVVb).hashCode();
        }
        yVVb = n43 + n18;
        Integer VVVb = AwVb.getMin();
        int n44 = yVVb * ZC[2];
        if (WidgetFormItemOptionsVO.qG(VVVb)) {
            n17 = ZC[5];
            "".length();
            if ("  ".length() == 0) {
                return ("  ".length() ^ (0x39 ^ 0x18)) & (88 + 98 - 46 + 44 ^ 136 + 22 - 73 + 70 ^ -" ".length());
            }
        } else {
            n17 = ((Object)VVVb).hashCode();
        }
        yVVb = n44 + n17;
        Integer uVVb = AwVb.getMax();
        int n45 = yVVb * ZC[2];
        if (WidgetFormItemOptionsVO.qG(uVVb)) {
            n16 = ZC[5];
            "".length();
            if ("  ".length() <= " ".length()) {
                return (0x84 ^ 0xAC ^ (0x51 ^ 0x33)) & (0xF ^ 5 ^ (0xEE ^ 0xAE) ^ -" ".length());
            }
        } else {
            n16 = ((Object)uVVb).hashCode();
        }
        yVVb = n45 + n16;
        Integer TVVb = AwVb.getStep();
        int n46 = yVVb * ZC[2];
        if (WidgetFormItemOptionsVO.qG(TVVb)) {
            n15 = ZC[5];
            "".length();
            if (-" ".length() >= 0) {
                return (0x1B ^ 0x78) & ~(0x38 ^ 0x5B);
            }
        } else {
            n15 = ((Object)TVVb).hashCode();
        }
        yVVb = n46 + n15;
        Integer sVVb = AwVb.getPrecision();
        int n47 = yVVb * ZC[2];
        if (WidgetFormItemOptionsVO.qG(sVVb)) {
            n14 = ZC[5];
            "".length();
            if (-"  ".length() > 0) {
                return (0x7C ^ 0x6C) & ~(0xB ^ 0x1B);
            }
        } else {
            n14 = ((Object)sVVb).hashCode();
        }
        yVVb = n47 + n14;
        Integer RVVb = AwVb.getGutter();
        int n48 = yVVb * ZC[2];
        if (WidgetFormItemOptionsVO.qG(RVVb)) {
            n13 = ZC[5];
            "".length();
            if (-(0x2C ^ 0x28) >= 0) {
                return (0xC3 ^ 0xC7) & ~(0xC7 ^ 0xC3);
            }
        } else {
            n13 = ((Object)RVVb).hashCode();
        }
        yVVb = n48 + n13;
        String qVVb = AwVb.getDefaultValue();
        int n49 = yVVb * ZC[2];
        if (WidgetFormItemOptionsVO.qG(qVVb)) {
            n12 = ZC[5];
            "".length();
            if (" ".length() > " ".length()) {
                return (0x9A ^ 0xB6) & ~(0x25 ^ 9);
            }
        } else {
            n12 = qVVb.hashCode();
        }
        yVVb = n49 + n12;
        String PVVb = AwVb.getWidth();
        int n50 = yVVb * ZC[2];
        if (WidgetFormItemOptionsVO.qG(PVVb)) {
            n11 = ZC[5];
            "".length();
            if (((3 ^ 0x69 ^ (0x6C ^ 0x39)) & (0x9C ^ 0x92 ^ (0x64 ^ 0x55) ^ -" ".length())) != 0) {
                return (0xB1 ^ 0x89 ^ (0x70 ^ 0x5A)) & (0x34 ^ 0x3A ^ (0x4B ^ 0x57) ^ -" ".length());
            }
        } else {
            n11 = PVVb.hashCode();
        }
        yVVb = n50 + n11;
        String oVVb = AwVb.getControlsPosition();
        int n51 = yVVb * ZC[2];
        if (WidgetFormItemOptionsVO.qG(oVVb)) {
            n10 = ZC[5];
            "".length();
            if ((91 + 37 - 13 + 27 ^ 93 + 37 - 43 + 52) <= 0) {
                return (0x1C ^ 0x51 ^ (0x82 ^ 0x89)) & (0x71 ^ 0x2B ^ (0x6E ^ 0x72) ^ -" ".length());
            }
        } else {
            n10 = oVVb.hashCode();
        }
        yVVb = n51 + n10;
        String NVVb = AwVb.getFormat();
        int n52 = yVVb * ZC[2];
        if (WidgetFormItemOptionsVO.qG(NVVb)) {
            n9 = ZC[5];
            "".length();
            if ((0x53 ^ 0x57) == " ".length()) {
                return "  ".length() & ~"  ".length();
            }
        } else {
            n9 = NVVb.hashCode();
        }
        yVVb = n52 + n9;
        String mVVb = AwVb.getPlaceholder();
        int n53 = yVVb * ZC[2];
        if (WidgetFormItemOptionsVO.qG(mVVb)) {
            n8 = ZC[5];
            "".length();
            if ("  ".length() < 0) {
                return (0x4F ^ 0x18) & ~(0x1A ^ 0x4D);
            }
        } else {
            n8 = mVVb.hashCode();
        }
        yVVb = n53 + n8;
        String LVVb = AwVb.getStartPlaceholder();
        int n54 = yVVb * ZC[2];
        if (WidgetFormItemOptionsVO.qG(LVVb)) {
            n7 = ZC[5];
            "".length();
            if (((0x1F ^ 0x22 ^ (0x9F ^ 0x8D)) & (0x8D ^ 0x94 ^ (0x98 ^ 0xAE) ^ -" ".length())) != 0) {
                return (0x29 ^ 0x43 ^ (0xDA ^ 0x83)) & (21 + 79 - -43 + 30 ^ 102 + 67 - 117 + 106 ^ -" ".length());
            }
        } else {
            n7 = LVVb.hashCode();
        }
        yVVb = n54 + n7;
        String kVVb = AwVb.getEndPlaceholder();
        int n55 = yVVb * ZC[2];
        if (WidgetFormItemOptionsVO.qG(kVVb)) {
            n6 = ZC[5];
            "".length();
            if ("  ".length() < 0) {
                return (0x56 ^ 0x60) & ~(0x50 ^ 0x66);
            }
        } else {
            n6 = kVVb.hashCode();
        }
        yVVb = n55 + n6;
        String JVVb = AwVb.getType();
        int n56 = yVVb * ZC[2];
        if (WidgetFormItemOptionsVO.qG(JVVb)) {
            n5 = ZC[5];
            "".length();
            if ((32 + 130 - 107 + 81 ^ 96 + 45 - 45 + 44) <= 0) {
                return (0x67 ^ 0x73 ^ (0xEE ^ 0xC1)) & ("   ".length() ^ (0x21 ^ 0x19) ^ -" ".length());
            }
        } else {
            n5 = JVVb.hashCode();
        }
        yVVb = n56 + n5;
        String hVVb = AwVb.getOptions();
        int n57 = yVVb * ZC[2];
        if (WidgetFormItemOptionsVO.qG(hVVb)) {
            n4 = ZC[5];
            "".length();
            if ((0x62 ^ 0x66) <= " ".length()) {
                return (0x16 ^ 0x32) & ~(0xE1 ^ 0xC5);
            }
        } else {
            n4 = hVVb.hashCode();
        }
        yVVb = n57 + n4;
        String GVVb = AwVb.getRules();
        int n58 = yVVb * ZC[2];
        if (WidgetFormItemOptionsVO.qG(GVVb)) {
            n3 = ZC[5];
            "".length();
            if (((0xEF ^ 0xC4 ^ (0xC6 ^ 0xA4)) & (11 + 213 - 197 + 225 ^ 115 + 139 - 145 + 72 ^ -" ".length())) >= "  ".length()) {
                return (0x5F ^ 0x7F ^ (0x74 ^ 7)) & (107 + 184 - 54 + 11 ^ 156 + 138 - 255 + 132 ^ -" ".length());
            }
        } else {
            n3 = GVVb.hashCode();
        }
        yVVb = n58 + n3;
        String fVVb = AwVb.getJustify();
        int n59 = yVVb * ZC[2];
        if (WidgetFormItemOptionsVO.qG(fVVb)) {
            n2 = ZC[5];
            "".length();
            if ((0x7C ^ 0x79) == 0) {
                return (0x42 ^ 0x51) & ~(0x81 ^ 0x92);
            }
        } else {
            n2 = fVVb.hashCode();
        }
        yVVb = n59 + n2;
        String EVVb = AwVb.getAlign();
        int n60 = yVVb * ZC[2];
        if (WidgetFormItemOptionsVO.qG(EVVb)) {
            n = ZC[5];
            "".length();
            if ("  ".length() < 0) {
                return (0x23 ^ 0x2F ^ (0x7E ^ 0x5D)) & (129 + 30 - 53 + 68 ^ 37 + 53 - -3 + 36 ^ -" ".length());
            }
        } else {
            n = EVVb.hashCode();
        }
        yVVb = n60 + n;
        return yVVb;
    }

    public String getRules() {
        WidgetFormItemOptionsVO XLwb;
        return XLwb.rules;
    }

    private static boolean oG(int n) {
        return n == 0;
    }

    public void setPlaceholder(String CGwb) {
        bGwb.placeholder = CGwb;
    }

    public String getControlsPosition() {
        WidgetFormItemOptionsVO bowb;
        return bowb.controlsPosition;
    }

    private static boolean PG(int n, int n2) {
        return n != n2;
    }

    public Integer getPrecision() {
        WidgetFormItemOptionsVO Eowb;
        return Eowb.precision;
    }

    public void setStartPlaceholder(String Vfwb) {
        ufwb.startPlaceholder = Vfwb;
    }

    public void setFilterable(boolean wGwb) {
        ZGwb.filterable = wGwb;
    }

    public boolean isFilterable() {
        WidgetFormItemOptionsVO oNwb;
        return oNwb.filterable;
    }

    public boolean isAllowHalf() {
        WidgetFormItemOptionsVO RNwb;
        return RNwb.allowHalf;
    }

    public void setButton(boolean Nhwb) {
        mhwb.button = Nhwb;
    }

    public void setType(String Gfwb) {
        ffwb.type = Gfwb;
    }

    public void setShowWordLimit(boolean Ndwb) {
        qdwb.showWordLimit = Ndwb;
    }

    public void setRules(String Adwb) {
        bdwb.rules = Adwb;
    }

    public String getDefaultValue() {
        WidgetFormItemOptionsVO Zowb;
        return Zowb.defaultValue;
    }

    public void setDefaultValue(String hLwb) {
        GLwb.defaultValue = hLwb;
    }

    public void setRows(Integer mkwb) {
        Lkwb.rows = mkwb;
    }

    static {
        WidgetFormItemOptionsVO.kG();
    }

    public boolean isButton() {
        WidgetFormItemOptionsVO VNwb;
        return VNwb.button;
    }

    public void setLabelHide(boolean XEwb) {
        Afwb.labelHide = XEwb;
    }

    public void setRange(boolean hGwb) {
        JGwb.isRange = hGwb;
    }

    public String getOptions() {
        WidgetFormItemOptionsVO ZLwb;
        return ZLwb.options;
    }

    public String getEndPlaceholder() {
        WidgetFormItemOptionsVO ymwb;
        return ymwb.endPlaceholder;
    }

    public void setClearable(boolean bEwb) {
        EEwb.clearable = bEwb;
    }

    public boolean equals(Object JAwb) {
        block164: {
            block165: {
                String uyVb;
                String VyVb;
                block163: {
                    WidgetFormItemOptionsVO hAwb;
                    WidgetFormItemOptionsVO TyVb;
                    block161: {
                        block162: {
                            String wyVb;
                            String XyVb;
                            block160: {
                                block158: {
                                    block159: {
                                        String yyVb;
                                        String ZyVb;
                                        block157: {
                                            block155: {
                                                block156: {
                                                    String AZVb;
                                                    String bZVb;
                                                    block154: {
                                                        block152: {
                                                            block153: {
                                                                String CZVb;
                                                                String dZVb;
                                                                block151: {
                                                                    block149: {
                                                                        block150: {
                                                                            String EZVb;
                                                                            String fZVb;
                                                                            block148: {
                                                                                block146: {
                                                                                    block147: {
                                                                                        String GZVb;
                                                                                        String hZVb;
                                                                                        block145: {
                                                                                            block143: {
                                                                                                block144: {
                                                                                                    String JZVb;
                                                                                                    String kZVb;
                                                                                                    block142: {
                                                                                                        block140: {
                                                                                                            block141: {
                                                                                                                String LZVb;
                                                                                                                String mZVb;
                                                                                                                block139: {
                                                                                                                    block137: {
                                                                                                                        block138: {
                                                                                                                            String NZVb;
                                                                                                                            String oZVb;
                                                                                                                            block136: {
                                                                                                                                block134: {
                                                                                                                                    block135: {
                                                                                                                                        String PZVb;
                                                                                                                                        String qZVb;
                                                                                                                                        block133: {
                                                                                                                                            block131: {
                                                                                                                                                block132: {
                                                                                                                                                    String RZVb;
                                                                                                                                                    String sZVb;
                                                                                                                                                    block130: {
                                                                                                                                                        block128: {
                                                                                                                                                            block129: {
                                                                                                                                                                Integer TZVb;
                                                                                                                                                                Integer uZVb;
                                                                                                                                                                block127: {
                                                                                                                                                                    block125: {
                                                                                                                                                                        block126: {
                                                                                                                                                                            Integer VZVb;
                                                                                                                                                                            Integer wZVb;
                                                                                                                                                                            block124: {
                                                                                                                                                                                block122: {
                                                                                                                                                                                    block123: {
                                                                                                                                                                                        Integer XZVb;
                                                                                                                                                                                        Integer yZVb;
                                                                                                                                                                                        block121: {
                                                                                                                                                                                            block119: {
                                                                                                                                                                                                block120: {
                                                                                                                                                                                                    Integer ZZVb;
                                                                                                                                                                                                    Integer AAwb;
                                                                                                                                                                                                    block118: {
                                                                                                                                                                                                        block116: {
                                                                                                                                                                                                            block117: {
                                                                                                                                                                                                                Integer bAwb;
                                                                                                                                                                                                                Integer CAwb;
                                                                                                                                                                                                                block115: {
                                                                                                                                                                                                                    block113: {
                                                                                                                                                                                                                        block114: {
                                                                                                                                                                                                                            Integer dAwb;
                                                                                                                                                                                                                            Integer EAwb;
                                                                                                                                                                                                                            block112: {
                                                                                                                                                                                                                                block110: {
                                                                                                                                                                                                                                    block111: {
                                                                                                                                                                                                                                        Integer fAwb;
                                                                                                                                                                                                                                        Integer GAwb;
                                                                                                                                                                                                                                        block109: {
                                                                                                                                                                                                                                            if (WidgetFormItemOptionsVO.NG(JAwb, TyVb)) {
                                                                                                                                                                                                                                                return ZC[0];
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                            if (WidgetFormItemOptionsVO.oG(JAwb instanceof WidgetFormItemOptionsVO)) {
                                                                                                                                                                                                                                                return ZC[1];
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                            hAwb = (WidgetFormItemOptionsVO)JAwb;
                                                                                                                                                                                                                                            if (WidgetFormItemOptionsVO.oG(hAwb.canEqual(TyVb) ? 1 : 0)) {
                                                                                                                                                                                                                                                return ZC[1];
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                            if (WidgetFormItemOptionsVO.PG(TyVb.isButton() ? 1 : 0, hAwb.isButton() ? 1 : 0)) {
                                                                                                                                                                                                                                                return ZC[1];
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                            if (WidgetFormItemOptionsVO.PG(TyVb.isAllowHalf() ? 1 : 0, hAwb.isAllowHalf() ? 1 : 0)) {
                                                                                                                                                                                                                                                return ZC[1];
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                            if (WidgetFormItemOptionsVO.PG(TyVb.isFilterable() ? 1 : 0, hAwb.isFilterable() ? 1 : 0)) {
                                                                                                                                                                                                                                                return ZC[1];
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                            if (WidgetFormItemOptionsVO.PG(TyVb.isMultiple() ? 1 : 0, hAwb.isMultiple() ? 1 : 0)) {
                                                                                                                                                                                                                                                return ZC[1];
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                            if (WidgetFormItemOptionsVO.PG(TyVb.isRange() ? 1 : 0, hAwb.isRange() ? 1 : 0)) {
                                                                                                                                                                                                                                                return ZC[1];
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                            if (WidgetFormItemOptionsVO.PG(TyVb.isLabelHide() ? 1 : 0, hAwb.isLabelHide() ? 1 : 0)) {
                                                                                                                                                                                                                                                return ZC[1];
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                            if (WidgetFormItemOptionsVO.PG(TyVb.isDisabled() ? 1 : 0, hAwb.isDisabled() ? 1 : 0)) {
                                                                                                                                                                                                                                                return ZC[1];
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                            if (WidgetFormItemOptionsVO.PG(TyVb.isReadonly() ? 1 : 0, hAwb.isReadonly() ? 1 : 0)) {
                                                                                                                                                                                                                                                return ZC[1];
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                            if (WidgetFormItemOptionsVO.PG(TyVb.isClearable() ? 1 : 0, hAwb.isClearable() ? 1 : 0)) {
                                                                                                                                                                                                                                                return ZC[1];
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                            if (WidgetFormItemOptionsVO.PG(TyVb.isShowPassword() ? 1 : 0, hAwb.isShowPassword() ? 1 : 0)) {
                                                                                                                                                                                                                                                return ZC[1];
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                            if (WidgetFormItemOptionsVO.PG(TyVb.isShowWordLimit() ? 1 : 0, hAwb.isShowWordLimit() ? 1 : 0)) {
                                                                                                                                                                                                                                                return ZC[1];
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                            GAwb = TyVb.getMaxlength();
                                                                                                                                                                                                                                            fAwb = hAwb.getMaxlength();
                                                                                                                                                                                                                                            if (!WidgetFormItemOptionsVO.qG(GAwb)) break block109;
                                                                                                                                                                                                                                            if (!WidgetFormItemOptionsVO.RG(fAwb)) break block110;
                                                                                                                                                                                                                                            "".length();
                                                                                                                                                                                                                                            if ((0x44 ^ 0x40) <= "  ".length()) {
                                                                                                                                                                                                                                                return ((0x26 ^ 0x78) & ~(0x68 ^ 0x36)) != 0;
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                            break block111;
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                        if (!WidgetFormItemOptionsVO.oG(((Object)GAwb).equals(fAwb) ? 1 : 0)) break block110;
                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                    return ZC[1];
                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                EAwb = TyVb.getRows();
                                                                                                                                                                                                                                dAwb = hAwb.getRows();
                                                                                                                                                                                                                                if (!WidgetFormItemOptionsVO.qG(EAwb)) break block112;
                                                                                                                                                                                                                                if (!WidgetFormItemOptionsVO.RG(dAwb)) break block113;
                                                                                                                                                                                                                                "".length();
                                                                                                                                                                                                                                if (" ".length() == 0) {
                                                                                                                                                                                                                                    return ((0xA ^ 0x33 ^ (0x22 ^ 2)) & (66 + 116 - 95 + 83 ^ 58 + 38 - 5 + 88 ^ -" ".length())) != 0;
                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                break block114;
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                            if (!WidgetFormItemOptionsVO.oG(((Object)EAwb).equals(dAwb) ? 1 : 0)) break block113;
                                                                                                                                                                                                                        }
                                                                                                                                                                                                                        return ZC[1];
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                    CAwb = TyVb.getMin();
                                                                                                                                                                                                                    bAwb = hAwb.getMin();
                                                                                                                                                                                                                    if (!WidgetFormItemOptionsVO.qG(CAwb)) break block115;
                                                                                                                                                                                                                    if (!WidgetFormItemOptionsVO.RG(bAwb)) break block116;
                                                                                                                                                                                                                    "".length();
                                                                                                                                                                                                                    if (" ".length() < ((0x49 ^ 0x2B) & ~(0x67 ^ 5))) {
                                                                                                                                                                                                                        return ((0x5E ^ 0x47) & ~(6 ^ 0x1F)) != 0;
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                    break block117;
                                                                                                                                                                                                                }
                                                                                                                                                                                                                if (!WidgetFormItemOptionsVO.oG(((Object)CAwb).equals(bAwb) ? 1 : 0)) break block116;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            return ZC[1];
                                                                                                                                                                                                        }
                                                                                                                                                                                                        AAwb = TyVb.getMax();
                                                                                                                                                                                                        ZZVb = hAwb.getMax();
                                                                                                                                                                                                        if (!WidgetFormItemOptionsVO.qG(AAwb)) break block118;
                                                                                                                                                                                                        if (!WidgetFormItemOptionsVO.RG(ZZVb)) break block119;
                                                                                                                                                                                                        "".length();
                                                                                                                                                                                                        if (((70 + 52 - 108 + 218 ^ 123 + 123 - 81 + 1) & (185 + 34 - 26 + 29 ^ 102 + 93 - 176 + 125 ^ -" ".length())) > "   ".length()) {
                                                                                                                                                                                                            return ((0x72 ^ 0x7D ^ (0xD1 ^ 0xC5)) & (0x6E ^ 0xE ^ (0x2D ^ 0x56) ^ -" ".length())) != 0;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        break block120;
                                                                                                                                                                                                    }
                                                                                                                                                                                                    if (!WidgetFormItemOptionsVO.oG(((Object)AAwb).equals(ZZVb) ? 1 : 0)) break block119;
                                                                                                                                                                                                }
                                                                                                                                                                                                return ZC[1];
                                                                                                                                                                                            }
                                                                                                                                                                                            yZVb = TyVb.getStep();
                                                                                                                                                                                            XZVb = hAwb.getStep();
                                                                                                                                                                                            if (!WidgetFormItemOptionsVO.qG(yZVb)) break block121;
                                                                                                                                                                                            if (!WidgetFormItemOptionsVO.RG(XZVb)) break block122;
                                                                                                                                                                                            "".length();
                                                                                                                                                                                            if (-" ".length() == "   ".length()) {
                                                                                                                                                                                                return ((0x34 ^ 0x67) & ~(0x76 ^ 0x25)) != 0;
                                                                                                                                                                                            }
                                                                                                                                                                                            break block123;
                                                                                                                                                                                        }
                                                                                                                                                                                        if (!WidgetFormItemOptionsVO.oG(((Object)yZVb).equals(XZVb) ? 1 : 0)) break block122;
                                                                                                                                                                                    }
                                                                                                                                                                                    return ZC[1];
                                                                                                                                                                                }
                                                                                                                                                                                wZVb = TyVb.getPrecision();
                                                                                                                                                                                VZVb = hAwb.getPrecision();
                                                                                                                                                                                if (!WidgetFormItemOptionsVO.qG(wZVb)) break block124;
                                                                                                                                                                                if (!WidgetFormItemOptionsVO.RG(VZVb)) break block125;
                                                                                                                                                                                "".length();
                                                                                                                                                                                if (" ".length() < 0) {
                                                                                                                                                                                    return ((0x83 ^ 0xA0 ^ (0xCD ^ 0xAE)) & (0x26 ^ 0x7B ^ (0x3B ^ 0x26) ^ -" ".length())) != 0;
                                                                                                                                                                                }
                                                                                                                                                                                break block126;
                                                                                                                                                                            }
                                                                                                                                                                            if (!WidgetFormItemOptionsVO.oG(((Object)wZVb).equals(VZVb) ? 1 : 0)) break block125;
                                                                                                                                                                        }
                                                                                                                                                                        return ZC[1];
                                                                                                                                                                    }
                                                                                                                                                                    uZVb = TyVb.getGutter();
                                                                                                                                                                    TZVb = hAwb.getGutter();
                                                                                                                                                                    if (!WidgetFormItemOptionsVO.qG(uZVb)) break block127;
                                                                                                                                                                    if (!WidgetFormItemOptionsVO.RG(TZVb)) break block128;
                                                                                                                                                                    "".length();
                                                                                                                                                                    if (" ".length() == -" ".length()) {
                                                                                                                                                                        return ((65 + 68 - 80 + 76 ^ 134 + 67 - 22 + 14) & (0x37 ^ 7 ^ (0x43 ^ 0x33) ^ -" ".length())) != 0;
                                                                                                                                                                    }
                                                                                                                                                                    break block129;
                                                                                                                                                                }
                                                                                                                                                                if (!WidgetFormItemOptionsVO.oG(((Object)uZVb).equals(TZVb) ? 1 : 0)) break block128;
                                                                                                                                                            }
                                                                                                                                                            return ZC[1];
                                                                                                                                                        }
                                                                                                                                                        sZVb = TyVb.getDefaultValue();
                                                                                                                                                        RZVb = hAwb.getDefaultValue();
                                                                                                                                                        if (!WidgetFormItemOptionsVO.qG(sZVb)) break block130;
                                                                                                                                                        if (!WidgetFormItemOptionsVO.RG(RZVb)) break block131;
                                                                                                                                                        "".length();
                                                                                                                                                        if (" ".length() <= 0) {
                                                                                                                                                            return (((0xC ^ 0x56) & ~(0xDB ^ 0x81) ^ (0x8B ^ 0xA2)) & (0x9C ^ 0xB7 ^ "  ".length() ^ -" ".length())) != 0;
                                                                                                                                                        }
                                                                                                                                                        break block132;
                                                                                                                                                    }
                                                                                                                                                    if (!WidgetFormItemOptionsVO.oG(sZVb.equals(RZVb) ? 1 : 0)) break block131;
                                                                                                                                                }
                                                                                                                                                return ZC[1];
                                                                                                                                            }
                                                                                                                                            qZVb = TyVb.getWidth();
                                                                                                                                            PZVb = hAwb.getWidth();
                                                                                                                                            if (!WidgetFormItemOptionsVO.qG(qZVb)) break block133;
                                                                                                                                            if (!WidgetFormItemOptionsVO.RG(PZVb)) break block134;
                                                                                                                                            "".length();
                                                                                                                                            if ((0x18 ^ 0x6B ^ (0x52 ^ 0x25)) == -" ".length()) {
                                                                                                                                                return ((71 + 44 - 22 + 57 ^ 43 + 84 - 0 + 55) & (31 + 146 - 37 + 32 ^ 134 + 66 - 198 + 138 ^ -" ".length())) != 0;
                                                                                                                                            }
                                                                                                                                            break block135;
                                                                                                                                        }
                                                                                                                                        if (!WidgetFormItemOptionsVO.oG(qZVb.equals(PZVb) ? 1 : 0)) break block134;
                                                                                                                                    }
                                                                                                                                    return ZC[1];
                                                                                                                                }
                                                                                                                                oZVb = TyVb.getControlsPosition();
                                                                                                                                NZVb = hAwb.getControlsPosition();
                                                                                                                                if (!WidgetFormItemOptionsVO.qG(oZVb)) break block136;
                                                                                                                                if (!WidgetFormItemOptionsVO.RG(NZVb)) break block137;
                                                                                                                                "".length();
                                                                                                                                if (((0x11 ^ 0xD) & ~(0xA7 ^ 0xBB)) > ((0xAD ^ 0xA6) & ~(0xB4 ^ 0xBF))) {
                                                                                                                                    return ((0x5B ^ 0x6E) & ~(0x2E ^ 0x1B)) != 0;
                                                                                                                                }
                                                                                                                                break block138;
                                                                                                                            }
                                                                                                                            if (!WidgetFormItemOptionsVO.oG(oZVb.equals(NZVb) ? 1 : 0)) break block137;
                                                                                                                        }
                                                                                                                        return ZC[1];
                                                                                                                    }
                                                                                                                    mZVb = TyVb.getFormat();
                                                                                                                    LZVb = hAwb.getFormat();
                                                                                                                    if (!WidgetFormItemOptionsVO.qG(mZVb)) break block139;
                                                                                                                    if (!WidgetFormItemOptionsVO.RG(LZVb)) break block140;
                                                                                                                    "".length();
                                                                                                                    if (null != null) {
                                                                                                                        return ((0xBA ^ 0xA8) & ~(0x34 ^ 0x26)) != 0;
                                                                                                                    }
                                                                                                                    break block141;
                                                                                                                }
                                                                                                                if (!WidgetFormItemOptionsVO.oG(mZVb.equals(LZVb) ? 1 : 0)) break block140;
                                                                                                            }
                                                                                                            return ZC[1];
                                                                                                        }
                                                                                                        kZVb = TyVb.getPlaceholder();
                                                                                                        JZVb = hAwb.getPlaceholder();
                                                                                                        if (!WidgetFormItemOptionsVO.qG(kZVb)) break block142;
                                                                                                        if (!WidgetFormItemOptionsVO.RG(JZVb)) break block143;
                                                                                                        "".length();
                                                                                                        if (-" ".length() >= ((0x24 ^ 0x5A ^ (0xCB ^ 0xAD)) & (0xF4 ^ 0xC2 ^ (0x44 ^ 0x6A) ^ -" ".length()))) {
                                                                                                            return ((54 + 136 - 0 + 18 ^ 79 + 117 - 84 + 80) & (0x4F ^ 0x3F ^ (0x43 ^ 0x23) ^ -" ".length())) != 0;
                                                                                                        }
                                                                                                        break block144;
                                                                                                    }
                                                                                                    if (!WidgetFormItemOptionsVO.oG(kZVb.equals(JZVb) ? 1 : 0)) break block143;
                                                                                                }
                                                                                                return ZC[1];
                                                                                            }
                                                                                            hZVb = TyVb.getStartPlaceholder();
                                                                                            GZVb = hAwb.getStartPlaceholder();
                                                                                            if (!WidgetFormItemOptionsVO.qG(hZVb)) break block145;
                                                                                            if (!WidgetFormItemOptionsVO.RG(GZVb)) break block146;
                                                                                            "".length();
                                                                                            if (" ".length() == (0x3B ^ 0x3F)) {
                                                                                                return ((0x30 ^ 0x12) & ~(0xE ^ 0x2C)) != 0;
                                                                                            }
                                                                                            break block147;
                                                                                        }
                                                                                        if (!WidgetFormItemOptionsVO.oG(hZVb.equals(GZVb) ? 1 : 0)) break block146;
                                                                                    }
                                                                                    return ZC[1];
                                                                                }
                                                                                fZVb = TyVb.getEndPlaceholder();
                                                                                EZVb = hAwb.getEndPlaceholder();
                                                                                if (!WidgetFormItemOptionsVO.qG(fZVb)) break block148;
                                                                                if (!WidgetFormItemOptionsVO.RG(EZVb)) break block149;
                                                                                "".length();
                                                                                if ((0x8E ^ 0x8A) <= ((0x64 ^ 0x2E) & ~(0x42 ^ 8))) {
                                                                                    return ((0xD0 ^ 0x9B) & ~(0x10 ^ 0x5B)) != 0;
                                                                                }
                                                                                break block150;
                                                                            }
                                                                            if (!WidgetFormItemOptionsVO.oG(fZVb.equals(EZVb) ? 1 : 0)) break block149;
                                                                        }
                                                                        return ZC[1];
                                                                    }
                                                                    dZVb = TyVb.getType();
                                                                    CZVb = hAwb.getType();
                                                                    if (!WidgetFormItemOptionsVO.qG(dZVb)) break block151;
                                                                    if (!WidgetFormItemOptionsVO.RG(CZVb)) break block152;
                                                                    "".length();
                                                                    if ((0x5D ^ 0x58) <= 0) {
                                                                        return ((0x79 ^ 0x6B) & ~(0xBB ^ 0xA9)) != 0;
                                                                    }
                                                                    break block153;
                                                                }
                                                                if (!WidgetFormItemOptionsVO.oG(dZVb.equals(CZVb) ? 1 : 0)) break block152;
                                                            }
                                                            return ZC[1];
                                                        }
                                                        bZVb = TyVb.getOptions();
                                                        AZVb = hAwb.getOptions();
                                                        if (!WidgetFormItemOptionsVO.qG(bZVb)) break block154;
                                                        if (!WidgetFormItemOptionsVO.RG(AZVb)) break block155;
                                                        "".length();
                                                        if (-"   ".length() > 0) {
                                                            return ((0x32 ^ 0x67 ^ (0x12 ^ 0x7F)) & (0x1F ^ 0x53 ^ (0xE2 ^ 0x96) ^ -" ".length())) != 0;
                                                        }
                                                        break block156;
                                                    }
                                                    if (!WidgetFormItemOptionsVO.oG(bZVb.equals(AZVb) ? 1 : 0)) break block155;
                                                }
                                                return ZC[1];
                                            }
                                            ZyVb = TyVb.getRules();
                                            yyVb = hAwb.getRules();
                                            if (!WidgetFormItemOptionsVO.qG(ZyVb)) break block157;
                                            if (!WidgetFormItemOptionsVO.RG(yyVb)) break block158;
                                            "".length();
                                            if (((0x45 ^ 0x63) & ~(0x6C ^ 0x4A)) != 0) {
                                                return ((0x62 ^ 0x30) & ~(0x2D ^ 0x7F)) != 0;
                                            }
                                            break block159;
                                        }
                                        if (!WidgetFormItemOptionsVO.oG(ZyVb.equals(yyVb) ? 1 : 0)) break block158;
                                    }
                                    return ZC[1];
                                }
                                XyVb = TyVb.getJustify();
                                wyVb = hAwb.getJustify();
                                if (!WidgetFormItemOptionsVO.qG(XyVb)) break block160;
                                if (!WidgetFormItemOptionsVO.RG(wyVb)) break block161;
                                "".length();
                                if (-(0x33 ^ 0x36) >= 0) {
                                    return ((0x9E ^ 0xAA) & ~(0x77 ^ 0x43)) != 0;
                                }
                                break block162;
                            }
                            if (!WidgetFormItemOptionsVO.oG(XyVb.equals(wyVb) ? 1 : 0)) break block161;
                        }
                        return ZC[1];
                    }
                    VyVb = TyVb.getAlign();
                    uyVb = hAwb.getAlign();
                    if (!WidgetFormItemOptionsVO.qG(VyVb)) break block163;
                    if (!WidgetFormItemOptionsVO.RG(uyVb)) break block164;
                    "".length();
                    if ("   ".length() <= " ".length()) {
                        return ((0 + 126 - 57 + 61 ^ 12 + 64 - -79 + 31) & (0x33 ^ 0x39 ^ (0x85 ^ 0xB7) ^ -" ".length())) != 0;
                    }
                    break block165;
                }
                if (!WidgetFormItemOptionsVO.oG(VyVb.equals(uyVb) ? 1 : 0)) break block164;
            }
            return ZC[1];
        }
        return ZC[0];
    }

    public void setFormat(String uhwb) {
        Vhwb.format = uhwb;
    }

    public void setOptions(String fdwb) {
        Gdwb.options = fdwb;
    }
}

