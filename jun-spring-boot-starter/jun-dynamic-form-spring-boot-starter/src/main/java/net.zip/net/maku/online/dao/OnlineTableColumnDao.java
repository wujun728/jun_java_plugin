/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.maku.framework.mybatis.dao.BaseDao
 *  org.apache.ibatis.annotations.Mapper
 */
package net.maku.online.dao;

import java.util.List;
import net.maku.framework.mybatis.dao.BaseDao;
import net.maku.online.entity.OnlineTableColumnEntity;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface OnlineTableColumnDao
extends BaseDao<OnlineTableColumnEntity> {
    public List<OnlineTableColumnEntity> getByTableId(String var1);
}

