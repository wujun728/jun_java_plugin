/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.maku.framework.common.utils.PageResult
 */
package net.maku.online.service;

import java.util.List;
import java.util.Map;
import net.maku.framework.common.utils.PageResult;
import net.maku.online.query.OnlineFormQuery;
import net.maku.online.vo.form.OnlineFormVO;

public interface OnlineFormService {
    public OnlineFormVO getJSON(String var1);

    public void save(String var1, Map<String, String> var2);

    public void delete(String var1, List<Long> var2);

    public void update(String var1, Map<String, String> var2);

    public Map<String, Object> get(String var1, Long var2);

    public PageResult<Map<String, Object>> page(String var1, OnlineFormQuery var2);
}

