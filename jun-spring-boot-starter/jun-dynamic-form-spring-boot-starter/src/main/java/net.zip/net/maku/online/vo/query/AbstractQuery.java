/*
 * Decompiled with CFR 0.152.
 */
package net.maku.online.vo.query;

import java.util.Map;
import net.maku.online.entity.OnlineTableColumnEntity;

public abstract class AbstractQuery {
    public /* synthetic */ OnlineTableColumnEntity column;

    public abstract Map<String, Object> getQuery();

    public AbstractQuery() {
        AbstractQuery dNRb;
    }
}

