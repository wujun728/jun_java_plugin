/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.swagger.v3.oas.annotations.Operation
 *  io.swagger.v3.oas.annotations.tags.Tag
 *  jakarta.validation.Valid
 *  net.maku.framework.common.utils.PageResult
 *  net.maku.framework.common.utils.Result
 *  org.springdoc.core.annotations.ParameterObject
 *  org.springframework.security.access.prepost.PreAuthorize
 *  org.springframework.web.bind.annotation.DeleteMapping
 *  org.springframework.web.bind.annotation.GetMapping
 *  org.springframework.web.bind.annotation.PathVariable
 *  org.springframework.web.bind.annotation.PostMapping
 *  org.springframework.web.bind.annotation.PutMapping
 *  org.springframework.web.bind.annotation.RequestBody
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.RestController
 */
package net.maku.online.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import java.util.List;
import net.maku.framework.common.utils.PageResult;
import net.maku.framework.common.utils.Result;
import net.maku.online.query.OnlineTableQuery;
import net.maku.online.service.OnlineTableService;
import net.maku.online.vo.OnlineTableVO;
import org.springdoc.core.annotations.ParameterObject;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping(value={"sys/online/table"})
@Tag(name="Online\u8868\u5355\u5f00\u53d1")
@RestController
public class OnlineTableController {
    private final /* synthetic */ OnlineTableService onlineTableService;

    @PutMapping
    @Operation(summary="\u4fee\u6539")
    @PreAuthorize(value="hasAuthority('online:table:all')")
    public Result<String> update(@RequestBody @Valid OnlineTableVO qEyb) {
        OnlineTableController REyb;
        REyb.onlineTableService.update(qEyb);
        return Result.ok();
    }

    @Operation(summary="\u4fdd\u5b58")
    @PreAuthorize(value="hasAuthority('online:table:all')")
    @PostMapping
    public Result<String> save(@RequestBody OnlineTableVO VEyb) {
        OnlineTableController wEyb;
        wEyb.onlineTableService.save(VEyb);
        return Result.ok();
    }

    @GetMapping(value={"{id}"})
    @Operation(summary="\u4fe1\u606f")
    @PreAuthorize(value="hasAuthority('online:table:all')")
    public Result<OnlineTableVO> get(@PathVariable(value="id") String dfyb) {
        OnlineTableController Efyb;
        OnlineTableVO ffyb = Efyb.onlineTableService.get(dfyb);
        return Result.ok((Object)ffyb);
    }

    @DeleteMapping
    @Operation(summary="\u5220\u9664")
    @PreAuthorize(value="hasAuthority('online:table:all')")
    public Result<String> delete(@RequestBody List<String> JEyb) {
        OnlineTableController kEyb;
        kEyb.onlineTableService.delete(JEyb);
        return Result.ok();
    }

    @Operation(summary="\u5206\u9875")
    @PreAuthorize(value="hasAuthority('online:table:all')")
    @GetMapping(value={"page"})
    public Result<PageResult<OnlineTableVO>> page(@ParameterObject @Valid OnlineTableQuery ofyb) {
        OnlineTableController sfyb;
        PageResult<OnlineTableVO> qfyb = sfyb.onlineTableService.page(ofyb);
        return Result.ok(qfyb);
    }

    public OnlineTableController(OnlineTableService bEyb) {
        OnlineTableController CEyb;
        CEyb.onlineTableService = bEyb;
    }
}

