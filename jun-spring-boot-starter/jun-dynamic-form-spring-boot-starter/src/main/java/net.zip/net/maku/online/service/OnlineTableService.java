/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.maku.framework.common.utils.PageResult
 *  net.maku.framework.mybatis.service.BaseService
 */
package net.maku.online.service;

import java.util.List;
import net.maku.framework.common.utils.PageResult;
import net.maku.framework.mybatis.service.BaseService;
import net.maku.online.entity.OnlineTableEntity;
import net.maku.online.query.OnlineTableQuery;
import net.maku.online.vo.OnlineTableVO;

public interface OnlineTableService
extends BaseService<OnlineTableEntity> {
    public void save(OnlineTableVO var1);

    public void delete(List<String> var1);

    public PageResult<OnlineTableVO> page(OnlineTableQuery var1);

    public OnlineTableVO get(String var1);

    public void update(OnlineTableVO var1);
}

