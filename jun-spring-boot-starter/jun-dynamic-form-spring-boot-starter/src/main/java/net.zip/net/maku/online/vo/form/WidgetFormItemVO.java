/*
 * Decompiled with CFR 0.152.
 */
package net.maku.online.vo.form;

import java.util.List;
import net.maku.online.vo.form.WidgetFormItemColumnVO;
import net.maku.online.vo.form.WidgetFormItemOptionsVO;

public class WidgetFormItemVO {
    private /* synthetic */ String name;
    private static /* synthetic */ int[] wC;
    private /* synthetic */ WidgetFormItemOptionsVO options;
    private /* synthetic */ List<WidgetFormItemColumnVO> columns;
    private /* synthetic */ String label;
    private /* synthetic */ String type;

    private static void Xf() {
        wC = new int[4];
        WidgetFormItemVO.wC[0] = " ".length();
        WidgetFormItemVO.wC[1] = (0x12 ^ 0x24) & ~(0x13 ^ 0x25);
        WidgetFormItemVO.wC[2] = 0xE4 ^ 0x80 ^ (0x22 ^ 0x7D);
        WidgetFormItemVO.wC[3] = 0x16 ^ 0x4C ^ (0xC9 ^ 0xB8);
    }

    public void setOptions(WidgetFormItemOptionsVO sdXb) {
        RdXb.options = sdXb;
    }

    public String getName() {
        WidgetFormItemVO AfXb;
        return AfXb.name;
    }

    public WidgetFormItemOptionsVO getOptions() {
        WidgetFormItemVO wEXb;
        return wEXb.options;
    }

    public List<WidgetFormItemColumnVO> getColumns() {
        WidgetFormItemVO uEXb;
        return uEXb.columns;
    }

    private static boolean dG(Object object) {
        return object == null;
    }

    private static boolean bG(int n) {
        return n == 0;
    }

    static {
        WidgetFormItemVO.Xf();
    }

    public WidgetFormItemVO() {
        WidgetFormItemVO kfXb;
    }

    public int hashCode() {
        int n;
        int n2;
        int n3;
        int n4;
        int n5;
        WidgetFormItemVO EbXb;
        int dbXb = wC[2];
        int CbXb = wC[0];
        String bbXb = EbXb.getType();
        int n6 = CbXb * wC[2];
        if (WidgetFormItemVO.dG(bbXb)) {
            n5 = wC[3];
            "".length();
            if (-"  ".length() > 0) {
                return (76 + 119 - 131 + 79 ^ 65 + 45 - 100 + 118) & (0x91 ^ 0xB8 ^ (0x44 ^ 0x62) ^ -" ".length());
            }
        } else {
            n5 = bbXb.hashCode();
        }
        CbXb = n6 + n5;
        String AbXb = EbXb.getLabel();
        int n7 = CbXb * wC[2];
        if (WidgetFormItemVO.dG(AbXb)) {
            n4 = wC[3];
            "".length();
            if (-(0x37 ^ 0x33) >= 0) {
                return (0x2C ^ 1) & ~(0xB6 ^ 0x9B);
            }
        } else {
            n4 = AbXb.hashCode();
        }
        CbXb = n7 + n4;
        String ZAXb = EbXb.getName();
        int n8 = CbXb * wC[2];
        if (WidgetFormItemVO.dG(ZAXb)) {
            n3 = wC[3];
            "".length();
            if ((0x67 ^ 0x62) <= 0) {
                return (0x5C ^ 0x4A) & ~(0x2F ^ 0x39);
            }
        } else {
            n3 = ZAXb.hashCode();
        }
        CbXb = n8 + n3;
        WidgetFormItemOptionsVO yAXb = EbXb.getOptions();
        int n9 = CbXb * wC[2];
        if (WidgetFormItemVO.dG(yAXb)) {
            n2 = wC[3];
            "".length();
            if ((150 + 25 - 114 + 135 ^ 80 + 21 - 19 + 110) > (142 + 31 - 167 + 173 ^ 67 + 59 - -13 + 44)) {
                return (57 + 45 - -124 + 1 ^ 22 + 136 - 5 + 43) & (85 + 29 - 89 + 132 ^ 153 + 146 - 140 + 27 ^ -" ".length());
            }
        } else {
            n2 = ((Object)yAXb).hashCode();
        }
        CbXb = n9 + n2;
        List<WidgetFormItemColumnVO> XAXb = EbXb.getColumns();
        int n10 = CbXb * wC[2];
        if (WidgetFormItemVO.dG(XAXb)) {
            n = wC[3];
            "".length();
            if ((0x19 ^ 0x1D) <= "   ".length()) {
                return (0x66 ^ 0x5B) & ~(0x89 ^ 0xB4);
            }
        } else {
            n = ((Object)XAXb).hashCode();
        }
        CbXb = n10 + n;
        return CbXb;
    }

    public void setLabel(String EEXb) {
        hEXb.label = EEXb;
    }

    private static boolean EG(Object object) {
        return object != null;
    }

    public String getLabel() {
        WidgetFormItemVO CfXb;
        return CfXb.label;
    }

    public void setColumns(List<WidgetFormItemColumnVO> JdXb) {
        mdXb.columns = JdXb;
    }

    public String toString() {
        WidgetFormItemVO mAXb;
        return "WidgetFormItemVO(type=" + mAXb.getType() + ", label=" + mAXb.getLabel() + ", name=" + mAXb.getName() + ", options=" + mAXb.getOptions() + ", columns=" + mAXb.getColumns() + ")";
    }

    public void setName(String XdXb) {
        ydXb.name = XdXb;
    }

    public void setType(String oEXb) {
        NEXb.type = oEXb;
    }

    public boolean equals(Object sCXb) {
        block41: {
            block42: {
                List<WidgetFormItemColumnVO> GCXb;
                List<WidgetFormItemColumnVO> hCXb;
                block40: {
                    WidgetFormItemVO RCXb;
                    WidgetFormItemVO TCXb;
                    block38: {
                        block39: {
                            WidgetFormItemOptionsVO JCXb;
                            WidgetFormItemOptionsVO kCXb;
                            block37: {
                                block35: {
                                    block36: {
                                        String LCXb;
                                        String mCXb;
                                        block34: {
                                            block32: {
                                                block33: {
                                                    String NCXb;
                                                    String oCXb;
                                                    block31: {
                                                        block29: {
                                                            block30: {
                                                                String PCXb;
                                                                String qCXb;
                                                                block28: {
                                                                    if (WidgetFormItemVO.AG(sCXb, TCXb)) {
                                                                        return wC[0];
                                                                    }
                                                                    if (WidgetFormItemVO.bG(sCXb instanceof WidgetFormItemVO)) {
                                                                        return wC[1];
                                                                    }
                                                                    RCXb = (WidgetFormItemVO)sCXb;
                                                                    if (WidgetFormItemVO.bG(RCXb.canEqual(TCXb) ? 1 : 0)) {
                                                                        return wC[1];
                                                                    }
                                                                    qCXb = TCXb.getType();
                                                                    PCXb = RCXb.getType();
                                                                    if (!WidgetFormItemVO.dG(qCXb)) break block28;
                                                                    if (!WidgetFormItemVO.EG(PCXb)) break block29;
                                                                    "".length();
                                                                    if (null != null) {
                                                                        return ((0xD1 ^ 0x9C ^ (0xF1 ^ 0xA9)) & (0x22 ^ 0x4F ^ (0x40 ^ 0x38) ^ -" ".length())) != 0;
                                                                    }
                                                                    break block30;
                                                                }
                                                                if (!WidgetFormItemVO.bG(qCXb.equals(PCXb) ? 1 : 0)) break block29;
                                                            }
                                                            return wC[1];
                                                        }
                                                        oCXb = TCXb.getLabel();
                                                        NCXb = RCXb.getLabel();
                                                        if (!WidgetFormItemVO.dG(oCXb)) break block31;
                                                        if (!WidgetFormItemVO.EG(NCXb)) break block32;
                                                        "".length();
                                                        if (-(0x78 ^ 0x3E ^ (0x34 ^ 0x76)) >= 0) {
                                                            return ((195 + 135 - 276 + 147 ^ 128 + 136 - 260 + 144) & (124 + 187 - 202 + 86 ^ 130 + 91 - 147 + 84 ^ -" ".length())) != 0;
                                                        }
                                                        break block33;
                                                    }
                                                    if (!WidgetFormItemVO.bG(oCXb.equals(NCXb) ? 1 : 0)) break block32;
                                                }
                                                return wC[1];
                                            }
                                            mCXb = TCXb.getName();
                                            LCXb = RCXb.getName();
                                            if (!WidgetFormItemVO.dG(mCXb)) break block34;
                                            if (!WidgetFormItemVO.EG(LCXb)) break block35;
                                            "".length();
                                            if ("  ".length() != "  ".length()) {
                                                return ((0x2A ^ 0x1D) & ~(0xA6 ^ 0x91)) != 0;
                                            }
                                            break block36;
                                        }
                                        if (!WidgetFormItemVO.bG(mCXb.equals(LCXb) ? 1 : 0)) break block35;
                                    }
                                    return wC[1];
                                }
                                kCXb = TCXb.getOptions();
                                JCXb = RCXb.getOptions();
                                if (!WidgetFormItemVO.dG(kCXb)) break block37;
                                if (!WidgetFormItemVO.EG(JCXb)) break block38;
                                "".length();
                                if (-"  ".length() >= 0) {
                                    return ((0x5C ^ 9 ^ (0x22 ^ 0x2A)) & (57 + 7 - -147 + 8 ^ 131 + 130 - 233 + 106 ^ -" ".length())) != 0;
                                }
                                break block39;
                            }
                            if (!WidgetFormItemVO.bG(((Object)kCXb).equals(JCXb) ? 1 : 0)) break block38;
                        }
                        return wC[1];
                    }
                    hCXb = TCXb.getColumns();
                    GCXb = RCXb.getColumns();
                    if (!WidgetFormItemVO.dG(hCXb)) break block40;
                    if (!WidgetFormItemVO.EG(GCXb)) break block41;
                    "".length();
                    if (((0x2D ^ 0x64 ^ (0x6B ^ 0x36)) & (0x1D ^ 0x56 ^ (0xC9 ^ 0x96) ^ -" ".length())) > 0) {
                        return ((0xC8 ^ 0x99 ^ (0xDC ^ 0xC2)) & (105 + 94 - 133 + 70 ^ 147 + 185 - 323 + 190 ^ -" ".length())) != 0;
                    }
                    break block42;
                }
                if (!WidgetFormItemVO.bG(((Object)hCXb).equals(GCXb) ? 1 : 0)) break block41;
            }
            return wC[1];
        }
        return wC[0];
    }

    private static boolean AG(Object object, Object object2) {
        return object == object2;
    }

    protected boolean canEqual(Object obXb) {
        return obXb instanceof WidgetFormItemVO;
    }

    public String getType() {
        WidgetFormItemVO GfXb;
        return GfXb.type;
    }
}

