/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.swagger.v3.oas.annotations.media.Schema
 */
package net.maku.online.vo;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description="Online\u8868\u5355\u5b57\u6bb5")
public class OnlineTableColumnVO {
    @Schema(description="\u8868\u5355\u9879")
    private /* synthetic */ boolean formItem;
    @Schema(description="\u5b57\u6bb5\u63cf\u8ff0")
    private /* synthetic */ String comments;
    @Schema(description="\u8868\u5355\u5b57\u5178")
    private /* synthetic */ String formDict;
    @Schema(description="\u8868\u5355\u63a7\u4ef6\u9ed8\u8ba4\u503c")
    private /* synthetic */ String formDefault;
    @Schema(description="\u5217\u8868\u6392\u5e8f")
    private /* synthetic */ boolean gridSort;
    @Schema(description="\u5b57\u6bb5\u540d\u79f0")
    private /* synthetic */ String name;
    @Schema(description="\u5c0f\u6570\u70b9")
    private /* synthetic */ Integer pointLength;
    private static /* synthetic */ int[] RC;
    @Schema(description="id")
    private /* synthetic */ Long id;
    @Schema(description="\u5217\u8868\u9879")
    private /* synthetic */ boolean gridItem;
    @Schema(description="\u5b57\u6bb5\u4e3a\u7a7a")
    private /* synthetic */ boolean columnNull;
    @Schema(description="\u5b57\u6bb5\u4e3b\u952e")
    private /* synthetic */ boolean columnPk;
    @Schema(description="\u67e5\u8be2\u65b9\u5f0f")
    private /* synthetic */ String queryType;
    @Schema(description="\u5b57\u6bb5\u957f\u5ea6")
    private /* synthetic */ Integer length;
    @Schema(description="\u8868\u5355\u63a7\u4ef6")
    private /* synthetic */ String formInput;
    @Schema(description="\u67e5\u8be2\u63a7\u4ef6")
    private /* synthetic */ String queryInput;
    @Schema(description="\u67e5\u8be2\u9879")
    private /* synthetic */ boolean queryItem;
    @Schema(description="\u6392\u5e8f")
    private /* synthetic */ Integer sort;
    @Schema(description="\u5b57\u6bb5\u7c7b\u578b")
    private /* synthetic */ String columnType;
    @Schema(description="\u8868\u5355\u5fc5\u586b")
    private /* synthetic */ boolean formRequired;
    @Schema(description="\u9ed8\u8ba4\u503c")
    private /* synthetic */ String defaultValue;

    public boolean isColumnNull() {
        OnlineTableColumnVO bVXb;
        return bVXb.columnNull;
    }

    public void setQueryType(String ToXb) {
        soXb.queryType = ToXb;
    }

    public int hashCode() {
        int n;
        int n2;
        int n3;
        int n4;
        int n5;
        int n6;
        int n7;
        int n8;
        int n9;
        int n10;
        int n11;
        int n12;
        int n13;
        int n14;
        int n15;
        int n16;
        int n17;
        int n18;
        int n19;
        int n20;
        OnlineTableColumnVO sJXb;
        int RJXb = RC[2];
        int qJXb = RC[0];
        int n21 = qJXb * RC[2];
        if (OnlineTableColumnVO.Tf(sJXb.isColumnPk() ? 1 : 0)) {
            n20 = RC[3];
            "".length();
            if ("   ".length() <= -" ".length()) {
                return (154 + 44 - 100 + 65 ^ 152 + 55 - 152 + 138) & (0x79 ^ 0x24 ^ (0x86 ^ 0xB9) ^ -" ".length());
            }
        } else {
            n20 = RC[4];
        }
        qJXb = n21 + n20;
        int n22 = qJXb * RC[2];
        if (OnlineTableColumnVO.Tf(sJXb.isColumnNull() ? 1 : 0)) {
            n19 = RC[3];
            "".length();
            if (((0xF7 ^ 0x99 ^ (0x7B ^ 0x4D)) & (0x38 ^ 0x16 ^ (0x45 ^ 0x33) ^ -" ".length())) > " ".length()) {
                return (107 + 30 - 12 + 19 ^ 125 + 38 - 39 + 7) & (0xDF ^ 0xB3 ^ 56 + 20 - 49 + 100 ^ -" ".length());
            }
        } else {
            n19 = RC[4];
        }
        qJXb = n22 + n19;
        int n23 = qJXb * RC[2];
        if (OnlineTableColumnVO.Tf(sJXb.isFormItem() ? 1 : 0)) {
            n18 = RC[3];
            "".length();
            if ("  ".length() <= 0) {
                return (0x53 ^ 0x14) & ~(0xDF ^ 0x98);
            }
        } else {
            n18 = RC[4];
        }
        qJXb = n23 + n18;
        int n24 = qJXb * RC[2];
        if (OnlineTableColumnVO.Tf(sJXb.isFormRequired() ? 1 : 0)) {
            n17 = RC[3];
            "".length();
            if (((0x69 ^ 0xF ^ (0x12 ^ 0x5A)) & (99 + 70 - 108 + 100 ^ 118 + 129 - 234 + 130 ^ -" ".length())) < 0) {
                return (0x23 ^ 0x3D ^ (0xDF ^ 0xC6)) & (0x1F ^ 0x33 ^ (0xAE ^ 0x85) ^ -" ".length());
            }
        } else {
            n17 = RC[4];
        }
        qJXb = n24 + n17;
        int n25 = qJXb * RC[2];
        if (OnlineTableColumnVO.Tf(sJXb.isGridItem() ? 1 : 0)) {
            n16 = RC[3];
            "".length();
            if ("  ".length() >= (0xC3 ^ 0xA0 ^ (0x13 ^ 0x74))) {
                return (0xCF ^ 0x95 ^ (0x2A ^ 0x36)) & (93 + 81 - -78 + 3 ^ 60 + 158 - 141 + 108 ^ -" ".length());
            }
        } else {
            n16 = RC[4];
        }
        qJXb = n25 + n16;
        int n26 = qJXb * RC[2];
        if (OnlineTableColumnVO.Tf(sJXb.isGridSort() ? 1 : 0)) {
            n15 = RC[3];
            "".length();
            if (" ".length() >= "  ".length()) {
                return (0xA ^ 0x66 ^ (0xA4 ^ 0x8C)) & (0x6A ^ 0x7D ^ (0x2D ^ 0x7E) ^ -" ".length());
            }
        } else {
            n15 = RC[4];
        }
        qJXb = n26 + n15;
        int n27 = qJXb * RC[2];
        if (OnlineTableColumnVO.Tf(sJXb.isQueryItem() ? 1 : 0)) {
            n14 = RC[3];
            "".length();
            if (null != null) {
                return (76 + 93 - 137 + 134 ^ 166 + 108 - 220 + 126) & (0x5B ^ 0x42 ^ (0x38 ^ 0x33) ^ -" ".length());
            }
        } else {
            n14 = RC[4];
        }
        qJXb = n27 + n14;
        Long PJXb = sJXb.getId();
        int n28 = qJXb * RC[2];
        if (OnlineTableColumnVO.of(PJXb)) {
            n13 = RC[5];
            "".length();
            if ((0x2D ^ 0x12 ^ (0x2C ^ 0x17)) <= "   ".length()) {
                return (80 + 95 - 164 + 126 ^ 15 + 59 - 57 + 131) & (218 + 57 - 133 + 80 ^ 2 + 179 - 149 + 163 ^ -" ".length());
            }
        } else {
            n13 = ((Object)PJXb).hashCode();
        }
        qJXb = n28 + n13;
        Integer oJXb = sJXb.getLength();
        int n29 = qJXb * RC[2];
        if (OnlineTableColumnVO.of(oJXb)) {
            n12 = RC[5];
            "".length();
            if ((0x2E ^ 0x2A) == "  ".length()) {
                return (0xB3 ^ 0x85) & ~(0x42 ^ 0x74);
            }
        } else {
            n12 = ((Object)oJXb).hashCode();
        }
        qJXb = n29 + n12;
        Integer NJXb = sJXb.getPointLength();
        int n30 = qJXb * RC[2];
        if (OnlineTableColumnVO.of(NJXb)) {
            n11 = RC[5];
            "".length();
            if ("   ".length() == " ".length()) {
                return (0x35 ^ 0x27) & ~(0x14 ^ 6);
            }
        } else {
            n11 = ((Object)NJXb).hashCode();
        }
        qJXb = n30 + n11;
        Integer mJXb = sJXb.getSort();
        int n31 = qJXb * RC[2];
        if (OnlineTableColumnVO.of(mJXb)) {
            n10 = RC[5];
            "".length();
            if ("  ".length() < 0) {
                return (75 + 63 - 57 + 74 ^ 116 + 40 - 98 + 122) & (0xC7 ^ 0xAA ^ (0xED ^ 0xAF) ^ -" ".length());
            }
        } else {
            n10 = ((Object)mJXb).hashCode();
        }
        qJXb = n31 + n10;
        String LJXb = sJXb.getName();
        int n32 = qJXb * RC[2];
        if (OnlineTableColumnVO.of(LJXb)) {
            n9 = RC[5];
            "".length();
            if ("  ".length() == 0) {
                return (0x83 ^ 0xAD) & ~(5 ^ 0x2B);
            }
        } else {
            n9 = LJXb.hashCode();
        }
        qJXb = n32 + n9;
        String kJXb = sJXb.getComments();
        int n33 = qJXb * RC[2];
        if (OnlineTableColumnVO.of(kJXb)) {
            n8 = RC[5];
            "".length();
            if ("   ".length() <= -" ".length()) {
                return (0 + 113 - -4 + 19 ^ 90 + 47 - 120 + 135) & (0x19 ^ 0x7E ^ (0x3B ^ 0x4C) ^ -" ".length());
            }
        } else {
            n8 = kJXb.hashCode();
        }
        qJXb = n33 + n8;
        String JJXb = sJXb.getDefaultValue();
        int n34 = qJXb * RC[2];
        if (OnlineTableColumnVO.of(JJXb)) {
            n7 = RC[5];
            "".length();
            if (-"   ".length() >= 0) {
                return (0xAB ^ 0xB8 ^ (0x2B ^ 0x79)) & (38 + 17 - -178 + 21 ^ 178 + 12 - 24 + 25 ^ -" ".length());
            }
        } else {
            n7 = JJXb.hashCode();
        }
        qJXb = n34 + n7;
        String hJXb = sJXb.getColumnType();
        int n35 = qJXb * RC[2];
        if (OnlineTableColumnVO.of(hJXb)) {
            n6 = RC[5];
            "".length();
            if (-"  ".length() >= 0) {
                return (0xE5 ^ 0xA6 ^ (0x7A ^ 0x1C)) & (0x62 ^ 0x73 ^ (0xF5 ^ 0xC1) ^ -" ".length());
            }
        } else {
            n6 = hJXb.hashCode();
        }
        qJXb = n35 + n6;
        String GJXb = sJXb.getFormInput();
        int n36 = qJXb * RC[2];
        if (OnlineTableColumnVO.of(GJXb)) {
            n5 = RC[5];
            "".length();
            if (" ".length() <= 0) {
                return (143 + 77 - 164 + 104 ^ 43 + 73 - 26 + 97) & (0xD8 ^ 0xBC ^ 40 + 49 - -37 + 1 ^ -" ".length());
            }
        } else {
            n5 = GJXb.hashCode();
        }
        qJXb = n36 + n5;
        String fJXb = sJXb.getFormDefault();
        int n37 = qJXb * RC[2];
        if (OnlineTableColumnVO.of(fJXb)) {
            n4 = RC[5];
            "".length();
            if (-(61 + 0 - 59 + 130 ^ 18 + 82 - 11 + 39) > 0) {
                return (0x11 ^ 0x67 ^ (0x47 ^ 0x19)) & (37 + 82 - -42 + 71 ^ 5 + 15 - -171 + 1 ^ -" ".length());
            }
        } else {
            n4 = fJXb.hashCode();
        }
        qJXb = n37 + n4;
        String EJXb = sJXb.getFormDict();
        int n38 = qJXb * RC[2];
        if (OnlineTableColumnVO.of(EJXb)) {
            n3 = RC[5];
            "".length();
            if (-" ".length() > "   ".length()) {
                return (0x5D ^ 0x79) & ~(0xA8 ^ 0x8C);
            }
        } else {
            n3 = EJXb.hashCode();
        }
        qJXb = n38 + n3;
        String dJXb = sJXb.getQueryType();
        int n39 = qJXb * RC[2];
        if (OnlineTableColumnVO.of(dJXb)) {
            n2 = RC[5];
            "".length();
            if (" ".length() == 0) {
                return (63 + 77 - 117 + 112 ^ 115 + 47 - 111 + 102) & (0x87 ^ 0xA1 ^ (0x45 ^ 0x7D) ^ -" ".length());
            }
        } else {
            n2 = dJXb.hashCode();
        }
        qJXb = n39 + n2;
        String CJXb = sJXb.getQueryInput();
        int n40 = qJXb * RC[2];
        if (OnlineTableColumnVO.of(CJXb)) {
            n = RC[5];
            "".length();
            if (null != null) {
                return (0xA4 ^ 0x87) & ~(0x4E ^ 0x6D);
            }
        } else {
            n = CJXb.hashCode();
        }
        qJXb = n40 + n;
        return qJXb;
    }

    public String getFormDict() {
        OnlineTableColumnVO muXb;
        return muXb.formDict;
    }

    public void setGridSort(boolean fPXb) {
        JPXb.gridSort = fPXb;
    }

    static {
        OnlineTableColumnVO.Jf();
    }

    public boolean isGridItem() {
        OnlineTableColumnVO huXb;
        return huXb.gridItem;
    }

    public void setLength(Integer PsXb) {
        qsXb.length = PsXb;
    }

    public void setFormInput(String JqXb) {
        mqXb.formInput = JqXb;
    }

    private static boolean Tf(int n) {
        return n != 0;
    }

    public String getColumnType() {
        OnlineTableColumnVO GVXb;
        return GVXb.columnType;
    }

    public boolean isGridSort() {
        OnlineTableColumnVO EuXb;
        return EuXb.gridSort;
    }

    private static boolean Lf(Object object, Object object2) {
        return object == object2;
    }

    private static void Jf() {
        RC = new int[6];
        OnlineTableColumnVO.RC[0] = " ".length();
        OnlineTableColumnVO.RC[1] = (0x82 ^ 0x96 ^ "  ".length()) & (0x3E ^ 0x76 ^ (0xFD ^ 0xA3) ^ -" ".length());
        OnlineTableColumnVO.RC[2] = 0x61 ^ 0x5A;
        OnlineTableColumnVO.RC[3] = 186 + 164 - 349 + 205 ^ 44 + 117 - 69 + 37;
        OnlineTableColumnVO.RC[4] = 0x4B ^ 0x2A;
        OnlineTableColumnVO.RC[5] = 0x87 ^ 0xB7 ^ (0x85 ^ 0x9E);
    }

    public void setPointLength(Integer hsXb) {
        LsXb.pointLength = hsXb;
    }

    public String getDefaultValue() {
        OnlineTableColumnVO LVXb;
        return LVXb.defaultValue;
    }

    public void setSort(Integer EoXb) {
        foXb.sort = EoXb;
    }

    public boolean isQueryItem() {
        OnlineTableColumnVO CuXb;
        return CuXb.queryItem;
    }

    private static boolean Pf(Object object) {
        return object != null;
    }

    public void setFormItem(boolean ZqXb) {
        ARXb.formItem = ZqXb;
    }

    private static boolean mf(int n) {
        return n == 0;
    }

    public void setColumnNull(boolean GRXb) {
        fRXb.columnNull = GRXb;
    }

    public OnlineTableColumnVO() {
        OnlineTableColumnVO dwXb;
    }

    public boolean isFormItem() {
        OnlineTableColumnVO yuXb;
        return yuXb.formItem;
    }

    public boolean isFormRequired() {
        OnlineTableColumnVO VuXb;
        return VuXb.formRequired;
    }

    public String getName() {
        OnlineTableColumnVO wVXb;
        return wVXb.name;
    }

    public Long getId() {
        OnlineTableColumnVO AwXb;
        return AwXb.id;
    }

    public String getComments() {
        OnlineTableColumnVO uVXb;
        return uVXb.comments;
    }

    public String toString() {
        OnlineTableColumnVO ChXb;
        return "OnlineTableColumnVO(id=" + ChXb.getId() + ", name=" + ChXb.getName() + ", comments=" + ChXb.getComments() + ", length=" + ChXb.getLength() + ", pointLength=" + ChXb.getPointLength() + ", defaultValue=" + ChXb.getDefaultValue() + ", columnType=" + ChXb.getColumnType() + ", columnPk=" + ChXb.isColumnPk() + ", columnNull=" + ChXb.isColumnNull() + ", formItem=" + ChXb.isFormItem() + ", formRequired=" + ChXb.isFormRequired() + ", formInput=" + ChXb.getFormInput() + ", formDefault=" + ChXb.getFormDefault() + ", formDict=" + ChXb.getFormDict() + ", gridItem=" + ChXb.isGridItem() + ", gridSort=" + ChXb.isGridSort() + ", queryItem=" + ChXb.isQueryItem() + ", queryType=" + ChXb.getQueryType() + ", queryInput=" + ChXb.getQueryInput() + ", sort=" + ChXb.getSort() + ")";
    }

    public void setGridItem(boolean PPXb) {
        oPXb.gridItem = PPXb;
    }

    public String getFormInput() {
        OnlineTableColumnVO RuXb;
        return RuXb.formInput;
    }

    public Integer getPointLength() {
        OnlineTableColumnVO oVXb;
        return oVXb.pointLength;
    }

    public boolean equals(Object RLXb) {
        block112: {
            block113: {
                String TLXb;
                String uLXb;
                block111: {
                    OnlineTableColumnVO umXb;
                    OnlineTableColumnVO wmXb;
                    block109: {
                        block110: {
                            String VLXb;
                            String wLXb;
                            block108: {
                                block106: {
                                    block107: {
                                        String XLXb;
                                        String yLXb;
                                        block105: {
                                            block103: {
                                                block104: {
                                                    String ZLXb;
                                                    String AmXb;
                                                    block102: {
                                                        block100: {
                                                            block101: {
                                                                String bmXb;
                                                                String CmXb;
                                                                block99: {
                                                                    block97: {
                                                                        block98: {
                                                                            String dmXb;
                                                                            String EmXb;
                                                                            block96: {
                                                                                block94: {
                                                                                    block95: {
                                                                                        String fmXb;
                                                                                        String GmXb;
                                                                                        block93: {
                                                                                            block91: {
                                                                                                block92: {
                                                                                                    String hmXb;
                                                                                                    String JmXb;
                                                                                                    block90: {
                                                                                                        block88: {
                                                                                                            block89: {
                                                                                                                String kmXb;
                                                                                                                String LmXb;
                                                                                                                block87: {
                                                                                                                    block85: {
                                                                                                                        block86: {
                                                                                                                            Integer mmXb;
                                                                                                                            Integer NmXb;
                                                                                                                            block84: {
                                                                                                                                block82: {
                                                                                                                                    block83: {
                                                                                                                                        Integer omXb;
                                                                                                                                        Integer PmXb;
                                                                                                                                        block81: {
                                                                                                                                            block79: {
                                                                                                                                                block80: {
                                                                                                                                                    Integer qmXb;
                                                                                                                                                    Integer RmXb;
                                                                                                                                                    block78: {
                                                                                                                                                        block76: {
                                                                                                                                                            block77: {
                                                                                                                                                                Long smXb;
                                                                                                                                                                Long TmXb;
                                                                                                                                                                block75: {
                                                                                                                                                                    if (OnlineTableColumnVO.Lf(RLXb, wmXb)) {
                                                                                                                                                                        return RC[0];
                                                                                                                                                                    }
                                                                                                                                                                    if (OnlineTableColumnVO.mf(RLXb instanceof OnlineTableColumnVO)) {
                                                                                                                                                                        return RC[1];
                                                                                                                                                                    }
                                                                                                                                                                    umXb = (OnlineTableColumnVO)RLXb;
                                                                                                                                                                    if (OnlineTableColumnVO.mf(umXb.canEqual(wmXb) ? 1 : 0)) {
                                                                                                                                                                        return RC[1];
                                                                                                                                                                    }
                                                                                                                                                                    if (OnlineTableColumnVO.Nf(wmXb.isColumnPk() ? 1 : 0, umXb.isColumnPk() ? 1 : 0)) {
                                                                                                                                                                        return RC[1];
                                                                                                                                                                    }
                                                                                                                                                                    if (OnlineTableColumnVO.Nf(wmXb.isColumnNull() ? 1 : 0, umXb.isColumnNull() ? 1 : 0)) {
                                                                                                                                                                        return RC[1];
                                                                                                                                                                    }
                                                                                                                                                                    if (OnlineTableColumnVO.Nf(wmXb.isFormItem() ? 1 : 0, umXb.isFormItem() ? 1 : 0)) {
                                                                                                                                                                        return RC[1];
                                                                                                                                                                    }
                                                                                                                                                                    if (OnlineTableColumnVO.Nf(wmXb.isFormRequired() ? 1 : 0, umXb.isFormRequired() ? 1 : 0)) {
                                                                                                                                                                        return RC[1];
                                                                                                                                                                    }
                                                                                                                                                                    if (OnlineTableColumnVO.Nf(wmXb.isGridItem() ? 1 : 0, umXb.isGridItem() ? 1 : 0)) {
                                                                                                                                                                        return RC[1];
                                                                                                                                                                    }
                                                                                                                                                                    if (OnlineTableColumnVO.Nf(wmXb.isGridSort() ? 1 : 0, umXb.isGridSort() ? 1 : 0)) {
                                                                                                                                                                        return RC[1];
                                                                                                                                                                    }
                                                                                                                                                                    if (OnlineTableColumnVO.Nf(wmXb.isQueryItem() ? 1 : 0, umXb.isQueryItem() ? 1 : 0)) {
                                                                                                                                                                        return RC[1];
                                                                                                                                                                    }
                                                                                                                                                                    TmXb = wmXb.getId();
                                                                                                                                                                    smXb = umXb.getId();
                                                                                                                                                                    if (!OnlineTableColumnVO.of(TmXb)) break block75;
                                                                                                                                                                    if (!OnlineTableColumnVO.Pf(smXb)) break block76;
                                                                                                                                                                    "".length();
                                                                                                                                                                    if ((37 + 126 - 66 + 38 ^ 101 + 53 - 105 + 82) == -" ".length()) {
                                                                                                                                                                        return ((144 + 110 - 220 + 119 ^ 85 + 151 - 190 + 131) & (0x34 ^ 0x57 ^ (0x16 ^ 0x5D) ^ -" ".length())) != 0;
                                                                                                                                                                    }
                                                                                                                                                                    break block77;
                                                                                                                                                                }
                                                                                                                                                                if (!OnlineTableColumnVO.mf(((Object)TmXb).equals(smXb) ? 1 : 0)) break block76;
                                                                                                                                                            }
                                                                                                                                                            return RC[1];
                                                                                                                                                        }
                                                                                                                                                        RmXb = wmXb.getLength();
                                                                                                                                                        qmXb = umXb.getLength();
                                                                                                                                                        if (!OnlineTableColumnVO.of(RmXb)) break block78;
                                                                                                                                                        if (!OnlineTableColumnVO.Pf(qmXb)) break block79;
                                                                                                                                                        "".length();
                                                                                                                                                        if ("   ".length() <= 0) {
                                                                                                                                                            return ((0x27 ^ 0x34) & ~(0xE ^ 0x1D)) != 0;
                                                                                                                                                        }
                                                                                                                                                        break block80;
                                                                                                                                                    }
                                                                                                                                                    if (!OnlineTableColumnVO.mf(((Object)RmXb).equals(qmXb) ? 1 : 0)) break block79;
                                                                                                                                                }
                                                                                                                                                return RC[1];
                                                                                                                                            }
                                                                                                                                            PmXb = wmXb.getPointLength();
                                                                                                                                            omXb = umXb.getPointLength();
                                                                                                                                            if (!OnlineTableColumnVO.of(PmXb)) break block81;
                                                                                                                                            if (!OnlineTableColumnVO.Pf(omXb)) break block82;
                                                                                                                                            "".length();
                                                                                                                                            if (null != null) {
                                                                                                                                                return ((73 + 34 - -40 + 15 ^ 56 + 13 - -64 + 47) & (0xE ^ 0x1C ^ (0x87 ^ 0x83) ^ -" ".length())) != 0;
                                                                                                                                            }
                                                                                                                                            break block83;
                                                                                                                                        }
                                                                                                                                        if (!OnlineTableColumnVO.mf(((Object)PmXb).equals(omXb) ? 1 : 0)) break block82;
                                                                                                                                    }
                                                                                                                                    return RC[1];
                                                                                                                                }
                                                                                                                                NmXb = wmXb.getSort();
                                                                                                                                mmXb = umXb.getSort();
                                                                                                                                if (!OnlineTableColumnVO.of(NmXb)) break block84;
                                                                                                                                if (!OnlineTableColumnVO.Pf(mmXb)) break block85;
                                                                                                                                "".length();
                                                                                                                                if (((0x55 ^ 0xD) & ~(0x39 ^ 0x61)) != 0) {
                                                                                                                                    return ((0xBD ^ 0xA0) & ~(0x2A ^ 0x37)) != 0;
                                                                                                                                }
                                                                                                                                break block86;
                                                                                                                            }
                                                                                                                            if (!OnlineTableColumnVO.mf(((Object)NmXb).equals(mmXb) ? 1 : 0)) break block85;
                                                                                                                        }
                                                                                                                        return RC[1];
                                                                                                                    }
                                                                                                                    LmXb = wmXb.getName();
                                                                                                                    kmXb = umXb.getName();
                                                                                                                    if (!OnlineTableColumnVO.of(LmXb)) break block87;
                                                                                                                    if (!OnlineTableColumnVO.Pf(kmXb)) break block88;
                                                                                                                    "".length();
                                                                                                                    if (((0x70 ^ 0x7B) & ~(9 ^ 2)) != ((0x72 ^ 0x7E) & ~(0x6D ^ 0x61))) {
                                                                                                                        return ((0x38 ^ 0x77) & ~(0xE3 ^ 0xAC)) != 0;
                                                                                                                    }
                                                                                                                    break block89;
                                                                                                                }
                                                                                                                if (!OnlineTableColumnVO.mf(LmXb.equals(kmXb) ? 1 : 0)) break block88;
                                                                                                            }
                                                                                                            return RC[1];
                                                                                                        }
                                                                                                        JmXb = wmXb.getComments();
                                                                                                        hmXb = umXb.getComments();
                                                                                                        if (!OnlineTableColumnVO.of(JmXb)) break block90;
                                                                                                        if (!OnlineTableColumnVO.Pf(hmXb)) break block91;
                                                                                                        "".length();
                                                                                                        if (-"   ".length() > 0) {
                                                                                                            return ((0xBC ^ 0xB2) & ~(0x92 ^ 0x9C)) != 0;
                                                                                                        }
                                                                                                        break block92;
                                                                                                    }
                                                                                                    if (!OnlineTableColumnVO.mf(JmXb.equals(hmXb) ? 1 : 0)) break block91;
                                                                                                }
                                                                                                return RC[1];
                                                                                            }
                                                                                            GmXb = wmXb.getDefaultValue();
                                                                                            fmXb = umXb.getDefaultValue();
                                                                                            if (!OnlineTableColumnVO.of(GmXb)) break block93;
                                                                                            if (!OnlineTableColumnVO.Pf(fmXb)) break block94;
                                                                                            "".length();
                                                                                            if ("  ".length() < 0) {
                                                                                                return ((0x1B ^ 0xD) & ~(0xA1 ^ 0xB7)) != 0;
                                                                                            }
                                                                                            break block95;
                                                                                        }
                                                                                        if (!OnlineTableColumnVO.mf(GmXb.equals(fmXb) ? 1 : 0)) break block94;
                                                                                    }
                                                                                    return RC[1];
                                                                                }
                                                                                EmXb = wmXb.getColumnType();
                                                                                dmXb = umXb.getColumnType();
                                                                                if (!OnlineTableColumnVO.of(EmXb)) break block96;
                                                                                if (!OnlineTableColumnVO.Pf(dmXb)) break block97;
                                                                                "".length();
                                                                                if (null != null) {
                                                                                    return ((127 + 33 - 74 + 162 ^ 89 + 144 - 179 + 110) & (87 + 106 - 182 + 189 ^ 33 + 121 - 107 + 101 ^ -" ".length())) != 0;
                                                                                }
                                                                                break block98;
                                                                            }
                                                                            if (!OnlineTableColumnVO.mf(EmXb.equals(dmXb) ? 1 : 0)) break block97;
                                                                        }
                                                                        return RC[1];
                                                                    }
                                                                    CmXb = wmXb.getFormInput();
                                                                    bmXb = umXb.getFormInput();
                                                                    if (!OnlineTableColumnVO.of(CmXb)) break block99;
                                                                    if (!OnlineTableColumnVO.Pf(bmXb)) break block100;
                                                                    "".length();
                                                                    if ((0x9A ^ 0x9E) <= " ".length()) {
                                                                        return ((0x2A ^ 0x63) & ~(0x24 ^ 0x6D)) != 0;
                                                                    }
                                                                    break block101;
                                                                }
                                                                if (!OnlineTableColumnVO.mf(CmXb.equals(bmXb) ? 1 : 0)) break block100;
                                                            }
                                                            return RC[1];
                                                        }
                                                        AmXb = wmXb.getFormDefault();
                                                        ZLXb = umXb.getFormDefault();
                                                        if (!OnlineTableColumnVO.of(AmXb)) break block102;
                                                        if (!OnlineTableColumnVO.Pf(ZLXb)) break block103;
                                                        "".length();
                                                        if ((0x54 ^ 0x50) != (4 ^ 0)) {
                                                            return ((0xE0 ^ 0xA5) & ~(0x61 ^ 0x24)) != 0;
                                                        }
                                                        break block104;
                                                    }
                                                    if (!OnlineTableColumnVO.mf(AmXb.equals(ZLXb) ? 1 : 0)) break block103;
                                                }
                                                return RC[1];
                                            }
                                            yLXb = wmXb.getFormDict();
                                            XLXb = umXb.getFormDict();
                                            if (!OnlineTableColumnVO.of(yLXb)) break block105;
                                            if (!OnlineTableColumnVO.Pf(XLXb)) break block106;
                                            "".length();
                                            if (((0x3D ^ 0x2E) & ~(4 ^ 0x17)) != ((9 ^ 0x3E) & ~(0x72 ^ 0x45))) {
                                                return ((0 ^ 0x4E) & ~(0x2E ^ 0x60)) != 0;
                                            }
                                            break block107;
                                        }
                                        if (!OnlineTableColumnVO.mf(yLXb.equals(XLXb) ? 1 : 0)) break block106;
                                    }
                                    return RC[1];
                                }
                                wLXb = wmXb.getQueryType();
                                VLXb = umXb.getQueryType();
                                if (!OnlineTableColumnVO.of(wLXb)) break block108;
                                if (!OnlineTableColumnVO.Pf(VLXb)) break block109;
                                "".length();
                                if (-" ".length() > -" ".length()) {
                                    return ((98 + 169 - 78 + 51 ^ 124 + 117 - 179 + 99) & (111 + 177 - 228 + 182 ^ 138 + 68 - 198 + 155 ^ -" ".length())) != 0;
                                }
                                break block110;
                            }
                            if (!OnlineTableColumnVO.mf(wLXb.equals(VLXb) ? 1 : 0)) break block109;
                        }
                        return RC[1];
                    }
                    uLXb = wmXb.getQueryInput();
                    TLXb = umXb.getQueryInput();
                    if (!OnlineTableColumnVO.of(uLXb)) break block111;
                    if (!OnlineTableColumnVO.Pf(TLXb)) break block112;
                    "".length();
                    if (((122 + 189 - 272 + 192 ^ 151 + 156 - 209 + 93) & (0x9A ^ 0xAD ^ (0x5D ^ 0x32) ^ -" ".length())) != 0) {
                        return ((32 + 142 - 91 + 68 ^ 131 + 43 - 160 + 174) & (2 + 132 - 61 + 72 ^ 93 + 113 - 203 + 183 ^ -" ".length())) != 0;
                    }
                    break block113;
                }
                if (!OnlineTableColumnVO.mf(uLXb.equals(TLXb) ? 1 : 0)) break block112;
            }
            return RC[1];
        }
        return RC[0];
    }

    public Integer getLength() {
        OnlineTableColumnVO RVXb;
        return RVXb.length;
    }

    public void setColumnType(String VRXb) {
        wRXb.columnType = VRXb;
    }

    public void setQueryItem(boolean APXb) {
        ZoXb.queryItem = APXb;
    }

    public void setFormRequired(boolean sqXb) {
        RqXb.formRequired = sqXb;
    }

    public void setFormDefault(String dqXb) {
        CqXb.formDefault = dqXb;
    }

    public void setName(String dTXb) {
        ETXb.name = dTXb;
    }

    public Integer getSort() {
        OnlineTableColumnVO sTXb;
        return sTXb.sort;
    }

    public String getQueryType() {
        OnlineTableColumnVO ZTXb;
        return ZTXb.queryType;
    }

    public void setId(Long NTXb) {
        oTXb.id = NTXb;
    }

    public String getQueryInput() {
        OnlineTableColumnVO VTXb;
        return VTXb.queryInput;
    }

    public void setColumnPk(boolean mRXb) {
        NRXb.columnPk = mRXb;
    }

    public void setComments(String ysXb) {
        XsXb.comments = ysXb;
    }

    public String getFormDefault() {
        OnlineTableColumnVO ouXb;
        return ouXb.formDefault;
    }

    public boolean isColumnPk() {
        OnlineTableColumnVO EVXb;
        return EVXb.columnPk;
    }

    private static boolean Nf(int n, int n2) {
        return n != n2;
    }

    private static boolean of(Object object) {
        return object == null;
    }

    protected boolean canEqual(Object LkXb) {
        return LkXb instanceof OnlineTableColumnVO;
    }

    public void setDefaultValue(String CsXb) {
        bsXb.defaultValue = CsXb;
    }

    public void setFormDict(String uPXb) {
        XPXb.formDict = uPXb;
    }

    public void setQueryInput(String moXb) {
        LoXb.queryInput = moXb;
    }
}

