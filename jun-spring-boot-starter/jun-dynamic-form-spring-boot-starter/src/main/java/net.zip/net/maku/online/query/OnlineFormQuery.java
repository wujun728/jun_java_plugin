/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.swagger.v3.oas.annotations.media.Schema
 *  jakarta.validation.constraints.Min
 *  jakarta.validation.constraints.NotNull
 *  org.hibernate.validator.constraints.Range
 */
package net.maku.online.query;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import java.util.LinkedHashMap;
import org.hibernate.validator.constraints.Range;

@Schema(description="Online\u8868\u5355\u67e5\u8be2")
public class OnlineFormQuery {
    private static /* synthetic */ int[] Zd;
    @NotNull(message="\u6bcf\u9875\u6761\u6570\u4e0d\u80fd\u4e3a\u7a7a")
    @Range(min=1L, max=1000L, message="\u6bcf\u9875\u6761\u6570\uff0c\u53d6\u503c\u8303\u56f4 1-1000")
    @Schema(description="\u6bcf\u9875\u6761\u6570", required=true)
    /* synthetic */ @NotNull(message="\u6bcf\u9875\u6761\u6570\u4e0d\u80fd\u4e3a\u7a7a") @Range(min=1L, max=1000L, message="\u6bcf\u9875\u6761\u6570\uff0c\u53d6\u503c\u8303\u56f4 1-1000") Integer limit;
    @Schema(description="\u53c2\u6570")
    /* synthetic */ LinkedHashMap<String, Object> params;
    @NotNull(message="\u9875\u7801\u4e0d\u80fd\u4e3a\u7a7a")
    @Min(value=1L, message="\u9875\u7801\u6700\u5c0f\u503c\u4e3a 1")
    @Schema(description="\u5f53\u524d\u9875\u7801", required=true)
    /* synthetic */ @NotNull(message="\u9875\u7801\u4e0d\u80fd\u4e3a\u7a7a") @Min(value=1L, message="\u9875\u7801\u6700\u5c0f\u503c\u4e3a 1") Integer page;

    public LinkedHashMap<String, Object> getParams() {
        OnlineFormQuery RAub;
        return RAub.params;
    }

    private static void bk() {
        Zd = new int[4];
        OnlineFormQuery.Zd[0] = " ".length();
        OnlineFormQuery.Zd[1] = (0x27 ^ 0x14 ^ (0xB8 ^ 0xAB)) & (90 + 24 - 48 + 103 ^ 116 + 123 - 154 + 52 ^ -" ".length());
        OnlineFormQuery.Zd[2] = 5 ^ 0x3E;
        OnlineFormQuery.Zd[3] = 117 + 119 - 82 + 79 ^ 65 + 66 - -2 + 61;
    }

    public Integer getLimit() {
        OnlineFormQuery VAub;
        return VAub.limit;
    }

    private static boolean fk(Object object) {
        return object != null;
    }

    public OnlineFormQuery() {
        OnlineFormQuery bbub;
    }

    public int hashCode() {
        int n;
        int n2;
        int n3;
        OnlineFormQuery ZXTb;
        int EyTb = Zd[2];
        int dyTb = Zd[0];
        Integer CyTb = ZXTb.getPage();
        int n4 = dyTb * Zd[2];
        if (OnlineFormQuery.Ek(CyTb)) {
            n3 = Zd[3];
            "".length();
            if (" ".length() == 0) {
                return (0x85 ^ 0xC4) & ~(0x46 ^ 7);
            }
        } else {
            n3 = ((Object)CyTb).hashCode();
        }
        dyTb = n4 + n3;
        Integer byTb = ZXTb.getLimit();
        int n5 = dyTb * Zd[2];
        if (OnlineFormQuery.Ek(byTb)) {
            n2 = Zd[3];
            "".length();
            if (" ".length() > "   ".length()) {
                return (0xC1 ^ 0x85) & ~(0x54 ^ 0x10);
            }
        } else {
            n2 = ((Object)byTb).hashCode();
        }
        dyTb = n5 + n2;
        LinkedHashMap<String, Object> AyTb = ZXTb.getParams();
        int n6 = dyTb * Zd[2];
        if (OnlineFormQuery.Ek(AyTb)) {
            n = Zd[3];
            "".length();
            if (-" ".length() > (0x7E ^ 0x7A)) {
                return (7 ^ 0x45) & ~(0xC8 ^ 0x8A);
            }
        } else {
            n = ((Object)AyTb).hashCode();
        }
        dyTb = n6 + n;
        return dyTb;
    }

    public void setParams(LinkedHashMap<String, Object> VZTb) {
        yZTb.params = VZTb;
    }

    public void setPage(Integer mAub) {
        LAub.page = mAub;
    }

    public boolean equals(Object JZTb) {
        block25: {
            block26: {
                LinkedHashMap<String, Object> bZTb;
                LinkedHashMap<String, Object> CZTb;
                block24: {
                    OnlineFormQuery hZTb;
                    OnlineFormQuery AZTb;
                    block22: {
                        block23: {
                            Integer dZTb;
                            Integer EZTb;
                            block21: {
                                block19: {
                                    block20: {
                                        Integer fZTb;
                                        Integer GZTb;
                                        block18: {
                                            if (OnlineFormQuery.Ck(JZTb, AZTb)) {
                                                return Zd[0];
                                            }
                                            if (OnlineFormQuery.dk(JZTb instanceof OnlineFormQuery)) {
                                                return Zd[1];
                                            }
                                            hZTb = (OnlineFormQuery)JZTb;
                                            if (OnlineFormQuery.dk(hZTb.canEqual(AZTb) ? 1 : 0)) {
                                                return Zd[1];
                                            }
                                            GZTb = AZTb.getPage();
                                            fZTb = hZTb.getPage();
                                            if (!OnlineFormQuery.Ek(GZTb)) break block18;
                                            if (!OnlineFormQuery.fk(fZTb)) break block19;
                                            "".length();
                                            if (-"   ".length() > 0) {
                                                return ((0x56 ^ 0xC ^ (0xF5 ^ 0x88)) & (146 + 78 - 206 + 136 ^ 78 + 114 - 155 + 152 ^ -" ".length())) != 0;
                                            }
                                            break block20;
                                        }
                                        if (!OnlineFormQuery.dk(((Object)GZTb).equals(fZTb) ? 1 : 0)) break block19;
                                    }
                                    return Zd[1];
                                }
                                EZTb = AZTb.getLimit();
                                dZTb = hZTb.getLimit();
                                if (!OnlineFormQuery.Ek(EZTb)) break block21;
                                if (!OnlineFormQuery.fk(dZTb)) break block22;
                                "".length();
                                if (" ".length() != " ".length()) {
                                    return ((71 + 56 - 18 + 141 ^ 153 + 179 - 151 + 17) & (25 + 33 - 46 + 116 ^ 161 + 66 - 226 + 187 ^ -" ".length())) != 0;
                                }
                                break block23;
                            }
                            if (!OnlineFormQuery.dk(((Object)EZTb).equals(dZTb) ? 1 : 0)) break block22;
                        }
                        return Zd[1];
                    }
                    CZTb = AZTb.getParams();
                    bZTb = hZTb.getParams();
                    if (!OnlineFormQuery.Ek(CZTb)) break block24;
                    if (!OnlineFormQuery.fk(bZTb)) break block25;
                    "".length();
                    if (" ".length() <= 0) {
                        return ((0x45 ^ 0xD ^ (0x50 ^ 0x44)) & (155 + 44 - -1 + 8 ^ 108 + 40 - 127 + 119 ^ -" ".length())) != 0;
                    }
                    break block26;
                }
                if (!OnlineFormQuery.dk(((Object)CZTb).equals(bZTb) ? 1 : 0)) break block25;
            }
            return Zd[1];
        }
        return Zd[0];
    }

    public void setLimit(Integer CAub) {
        dAub.limit = CAub;
    }

    protected boolean canEqual(Object oyTb) {
        return oyTb instanceof OnlineFormQuery;
    }

    private static boolean Ck(Object object, Object object2) {
        return object == object2;
    }

    static {
        OnlineFormQuery.bk();
    }

    private static boolean dk(int n) {
        return n == 0;
    }

    public String toString() {
        OnlineFormQuery sXTb;
        return "OnlineFormQuery(page=" + sXTb.getPage() + ", limit=" + sXTb.getLimit() + ", params=" + sXTb.getParams() + ")";
    }

    private static boolean Ek(Object object) {
        return object == null;
    }

    public Integer getPage() {
        OnlineFormQuery yAub;
        return yAub.page;
    }
}

