/*
 * Decompiled with CFR 0.152.
 */
package net.maku.online.vo.form;

public class WidgetFormConfigVO {
    private /* synthetic */ String size;
    private /* synthetic */ String labelPosition;
    private /* synthetic */ Integer labelWidth;
    private static /* synthetic */ int[] NC;
    private /* synthetic */ String style;

    private static boolean df(int n) {
        return n == 0;
    }

    public int hashCode() {
        int n;
        int n2;
        int n3;
        int n4;
        WidgetFormConfigVO ZwXb;
        int fXXb = NC[2];
        int EXXb = NC[0];
        Integer dXXb = ZwXb.getLabelWidth();
        int n5 = EXXb * NC[2];
        if (WidgetFormConfigVO.Ef(dXXb)) {
            n4 = NC[3];
            "".length();
            if (" ".length() > (0x45 ^ 0x41)) {
                return (0 ^ 0x1D) & ~(0xDC ^ 0xC1) & ~((0x87 ^ 0x81) & ~(0xA7 ^ 0xA1));
            }
        } else {
            n4 = ((Object)dXXb).hashCode();
        }
        EXXb = n5 + n4;
        String CXXb = ZwXb.getSize();
        int n6 = EXXb * NC[2];
        if (WidgetFormConfigVO.Ef(CXXb)) {
            n3 = NC[3];
            "".length();
            if (((8 ^ 0x2B) & ~(0x29 ^ 0xA)) != 0) {
                return (0x22 ^ 0x7E) & ~(0xCC ^ 0x90);
            }
        } else {
            n3 = CXXb.hashCode();
        }
        EXXb = n6 + n3;
        String bXXb = ZwXb.getLabelPosition();
        int n7 = EXXb * NC[2];
        if (WidgetFormConfigVO.Ef(bXXb)) {
            n2 = NC[3];
            "".length();
            if ((0xDC ^ 0xC4 ^ (0xA0 ^ 0xBC)) < 0) {
                return (181 + 71 - 105 + 65 ^ 29 + 36 - -52 + 15) & (0x76 ^ 0x17 ^ (0xBA ^ 0x8B) ^ -" ".length());
            }
        } else {
            n2 = bXXb.hashCode();
        }
        EXXb = n7 + n2;
        String AXXb = ZwXb.getStyle();
        int n8 = EXXb * NC[2];
        if (WidgetFormConfigVO.Ef(AXXb)) {
            n = NC[3];
            "".length();
            if ((0xA0 ^ 0xA4) < (0x56 ^ 0x52)) {
                return (0x38 ^ 0x7E) & ~(0xE3 ^ 0xA5);
            }
        } else {
            n = AXXb.hashCode();
        }
        EXXb = n8 + n;
        return EXXb;
    }

    private static boolean Ef(Object object) {
        return object == null;
    }

    public String getLabelPosition() {
        WidgetFormConfigVO kAyb;
        return kAyb.labelPosition;
    }

    protected boolean canEqual(Object qXXb) {
        return qXXb instanceof WidgetFormConfigVO;
    }

    public void setLabelWidth(Integer uZXb) {
        VZXb.labelWidth = uZXb;
    }

    public void setSize(String ZZXb) {
        CAyb.size = ZZXb;
    }

    public String toString() {
        WidgetFormConfigVO qwXb;
        return "WidgetFormConfigVO(size=" + qwXb.getSize() + ", labelWidth=" + qwXb.getLabelWidth() + ", labelPosition=" + qwXb.getLabelPosition() + ", style=" + qwXb.getStyle() + ")";
    }

    private static boolean ff(Object object) {
        return object != null;
    }

    public String getSize() {
        WidgetFormConfigVO RAyb;
        return RAyb.size;
    }

    public String getStyle() {
        WidgetFormConfigVO GAyb;
        return GAyb.style;
    }

    public void setLabelPosition(String NZXb) {
        oZXb.labelPosition = NZXb;
    }

    public Integer getLabelWidth() {
        WidgetFormConfigVO oAyb;
        return oAyb.labelWidth;
    }

    public WidgetFormConfigVO() {
        WidgetFormConfigVO TAyb;
    }

    public boolean equals(Object dyXb) {
        block33: {
            block34: {
                String fyXb;
                String GyXb;
                block32: {
                    WidgetFormConfigVO oyXb;
                    WidgetFormConfigVO EyXb;
                    block30: {
                        block31: {
                            String hyXb;
                            String JyXb;
                            block29: {
                                block27: {
                                    block28: {
                                        String kyXb;
                                        String LyXb;
                                        block26: {
                                            block24: {
                                                block25: {
                                                    Integer myXb;
                                                    Integer NyXb;
                                                    block23: {
                                                        if (WidgetFormConfigVO.Cf(dyXb, EyXb)) {
                                                            return NC[0];
                                                        }
                                                        if (WidgetFormConfigVO.df(dyXb instanceof WidgetFormConfigVO)) {
                                                            return NC[1];
                                                        }
                                                        oyXb = (WidgetFormConfigVO)dyXb;
                                                        if (WidgetFormConfigVO.df(oyXb.canEqual(EyXb) ? 1 : 0)) {
                                                            return NC[1];
                                                        }
                                                        NyXb = EyXb.getLabelWidth();
                                                        myXb = oyXb.getLabelWidth();
                                                        if (!WidgetFormConfigVO.Ef(NyXb)) break block23;
                                                        if (!WidgetFormConfigVO.ff(myXb)) break block24;
                                                        "".length();
                                                        if ((0x11 ^ 0x15) < " ".length()) {
                                                            return ((0x3D ^ 0x16) & ~(0x68 ^ 0x43)) != 0;
                                                        }
                                                        break block25;
                                                    }
                                                    if (!WidgetFormConfigVO.df(((Object)NyXb).equals(myXb) ? 1 : 0)) break block24;
                                                }
                                                return NC[1];
                                            }
                                            LyXb = EyXb.getSize();
                                            kyXb = oyXb.getSize();
                                            if (!WidgetFormConfigVO.Ef(LyXb)) break block26;
                                            if (!WidgetFormConfigVO.ff(kyXb)) break block27;
                                            "".length();
                                            if ("  ".length() == 0) {
                                                return ((0xCA ^ 0xBA ^ (1 ^ 0x30)) & (0xA6 ^ 0xB6 ^ (0xE7 ^ 0xB6) ^ -" ".length())) != 0;
                                            }
                                            break block28;
                                        }
                                        if (!WidgetFormConfigVO.df(LyXb.equals(kyXb) ? 1 : 0)) break block27;
                                    }
                                    return NC[1];
                                }
                                JyXb = EyXb.getLabelPosition();
                                hyXb = oyXb.getLabelPosition();
                                if (!WidgetFormConfigVO.Ef(JyXb)) break block29;
                                if (!WidgetFormConfigVO.ff(hyXb)) break block30;
                                "".length();
                                if (-(0xD6 ^ 0xB4 ^ (0xA3 ^ 0xC4)) >= 0) {
                                    return ((15 + 74 - 47 + 104 ^ 87 + 91 - 99 + 69) & (0x77 ^ 0x5C ^ (0xE9 ^ 0xC4) ^ -" ".length())) != 0;
                                }
                                break block31;
                            }
                            if (!WidgetFormConfigVO.df(JyXb.equals(hyXb) ? 1 : 0)) break block30;
                        }
                        return NC[1];
                    }
                    GyXb = EyXb.getStyle();
                    fyXb = oyXb.getStyle();
                    if (!WidgetFormConfigVO.Ef(GyXb)) break block32;
                    if (!WidgetFormConfigVO.ff(fyXb)) break block33;
                    "".length();
                    if (((0x7F ^ 0x51) & ~(0x7A ^ 0x54)) < -" ".length()) {
                        return ((0xF2 ^ 0xC7) & ~(0x95 ^ 0xA0)) != 0;
                    }
                    break block34;
                }
                if (!WidgetFormConfigVO.df(GyXb.equals(fyXb) ? 1 : 0)) break block33;
            }
            return NC[1];
        }
        return NC[0];
    }

    private static void Af() {
        NC = new int[4];
        WidgetFormConfigVO.NC[0] = " ".length();
        WidgetFormConfigVO.NC[1] = (0xA9 ^ 0xAE) & ~(0xBE ^ 0xB9) & ~((0xDC ^ 0x90) & ~(0x13 ^ 0x5F));
        WidgetFormConfigVO.NC[2] = 0x86 ^ 0xBD;
        WidgetFormConfigVO.NC[3] = 0xA7 ^ 0x8C;
    }

    private static boolean Cf(Object object, Object object2) {
        return object == object2;
    }

    static {
        WidgetFormConfigVO.Af();
    }

    public void setStyle(String fZXb) {
        EZXb.style = fZXb;
    }
}

