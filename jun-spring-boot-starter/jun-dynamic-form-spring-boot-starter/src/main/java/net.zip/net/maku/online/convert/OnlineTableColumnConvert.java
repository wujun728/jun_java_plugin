/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.mapstruct.Mapper
 *  org.mapstruct.factory.Mappers
 */
package net.maku.online.convert;

import java.util.List;
import net.maku.online.entity.OnlineTableColumnEntity;
import net.maku.online.vo.OnlineTableColumnVO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface OnlineTableColumnConvert {
    public static final /* synthetic */ OnlineTableColumnConvert INSTANCE;

    public List<OnlineTableColumnEntity> convertList2(List<OnlineTableColumnVO> var1);

    public List<OnlineTableColumnVO> convertList(List<OnlineTableColumnEntity> var1);

    public OnlineTableColumnEntity convert(OnlineTableColumnVO var1);

    static {
        INSTANCE = (OnlineTableColumnConvert)Mappers.getMapper(OnlineTableColumnConvert.class);
    }

    public OnlineTableColumnVO convert(OnlineTableColumnEntity var1);
}

