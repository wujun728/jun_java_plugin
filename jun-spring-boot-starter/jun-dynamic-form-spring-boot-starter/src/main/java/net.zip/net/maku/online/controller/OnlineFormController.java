/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.swagger.v3.oas.annotations.tags.Tag
 *  jakarta.validation.Valid
 *  net.maku.framework.common.utils.PageResult
 *  net.maku.framework.common.utils.Result
 *  org.springframework.web.bind.annotation.DeleteMapping
 *  org.springframework.web.bind.annotation.GetMapping
 *  org.springframework.web.bind.annotation.PathVariable
 *  org.springframework.web.bind.annotation.PostMapping
 *  org.springframework.web.bind.annotation.PutMapping
 *  org.springframework.web.bind.annotation.RequestBody
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.RestController
 */
package net.maku.online.controller;

import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import java.util.List;
import java.util.Map;
import net.maku.framework.common.utils.PageResult;
import net.maku.framework.common.utils.Result;
import net.maku.online.query.OnlineFormQuery;
import net.maku.online.service.OnlineFormService;
import net.maku.online.vo.form.OnlineFormVO;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping(value={"sys/online/form/{tableId}"})
@RestController
@Tag(name="Online\u8868\u5355")
public class OnlineFormController {
    private final /* synthetic */ OnlineFormService onlineFormService;

    @GetMapping(value={"{id}"})
    public Result<Map<String, Object>> get(@PathVariable(value="tableId") String hVTb, @PathVariable(value="id") Long LVTb) {
        OnlineFormController NVTb;
        Map<String, Object> kVTb = NVTb.onlineFormService.get(hVTb, LVTb);
        return Result.ok(kVTb);
    }

    @PostMapping
    public Result<String> save(@PathVariable(value="tableId") String VuTb, @RequestBody Map<String, String> XuTb) {
        OnlineFormController wuTb;
        wuTb.onlineFormService.save(VuTb, XuTb);
        return Result.ok();
    }

    @PostMapping(value={"page"})
    public Result<PageResult<Map<String, Object>>> page(@PathVariable(value="tableId") String wVTb, @RequestBody @Valid OnlineFormQuery VVTb) {
        OnlineFormController XVTb;
        PageResult<Map<String, Object>> yVTb = XVTb.onlineFormService.page(wVTb, VVTb);
        return Result.ok(yVTb);
    }

    @GetMapping
    public Result<OnlineFormVO> json(@PathVariable(value="tableId") String kwTb) {
        OnlineFormController owTb;
        OnlineFormVO mwTb = owTb.onlineFormService.getJSON(kwTb);
        return Result.ok((Object)mwTb);
    }

    public OnlineFormController(OnlineFormService qTTb) {
        OnlineFormController TTTb;
        TTTb.onlineFormService = qTTb;
    }

    @PutMapping
    public Result<String> update(@PathVariable(value="tableId") String kuTb, @RequestBody Map<String, String> muTb) {
        OnlineFormController ouTb;
        ouTb.onlineFormService.update(kuTb, muTb);
        return Result.ok();
    }

    @DeleteMapping
    public Result<String> delete(@PathVariable(value="tableId") String yTTb, @RequestBody List<Long> XTTb) {
        OnlineFormController ZTTb;
        ZTTb.onlineFormService.delete(yTTb, XTTb);
        return Result.ok();
    }
}

