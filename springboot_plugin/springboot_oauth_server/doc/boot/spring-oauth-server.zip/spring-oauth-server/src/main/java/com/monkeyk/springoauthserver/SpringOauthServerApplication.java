package com.monkeyk.springoauthserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringOauthServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringOauthServerApplication.class, args);
	}
}
