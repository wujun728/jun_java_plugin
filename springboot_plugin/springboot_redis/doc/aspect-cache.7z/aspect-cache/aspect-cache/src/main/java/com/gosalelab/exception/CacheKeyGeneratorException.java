package com.gosalelab.exception;

public class CacheKeyGeneratorException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public CacheKeyGeneratorException(String msg) {
        super(msg);
    }
}
