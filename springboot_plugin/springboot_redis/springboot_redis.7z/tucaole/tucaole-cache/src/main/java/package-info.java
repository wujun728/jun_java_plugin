/**
 * @author Wujun
 * @Project tucaole
 * @Description: 缓存层，比如redis
 */