/**
 * @author Wujun
 * @Project tucaole
 * @Description: Java操作Elasticsearch工具类
 */