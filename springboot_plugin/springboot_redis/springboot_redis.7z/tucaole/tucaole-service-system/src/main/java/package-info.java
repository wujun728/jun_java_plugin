/**
 * @author Wujun
 * @Project tucaole
 * @Description: 系统模块的接口具体实现层，比如系统日志，用户反馈等
 */