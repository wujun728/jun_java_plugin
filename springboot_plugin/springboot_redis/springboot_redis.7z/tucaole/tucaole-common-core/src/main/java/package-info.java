/**
 * @author Wujun
 * @Project tucaole
 * @Description: 核心公用包
 */