/**
 * @author Wujun
 * @Project tucaole
 * @Description: 爬虫，直接实现DocumentAnalyzer即可
 */