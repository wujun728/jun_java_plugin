package com.chentongwei.spider.service;

import java.util.List;

/**
 * @author Wujun
 * @Project tucaole
 * @Description: 百度百科
 */
public interface BaiDuBaiKeService {

    List forWeekly(Integer stage) throws Exception;
}
