/**
 * @author Wujun
 * @Project tucaole
 * @Description: 统一邮件发送
 */