/**
 * @author Wujun
 * @Project tucaole
 * @Description: 通用配置
 */