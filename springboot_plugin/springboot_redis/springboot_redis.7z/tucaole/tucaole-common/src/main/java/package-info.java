/**
 * @author Wujun
 * @Project tucaole
 * @Description: 常用类
 */