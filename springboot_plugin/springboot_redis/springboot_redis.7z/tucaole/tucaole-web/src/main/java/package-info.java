/**
 * @author Wujun
 * @Project tucaole
 * @Description: 控制层，与页面打交道
 */