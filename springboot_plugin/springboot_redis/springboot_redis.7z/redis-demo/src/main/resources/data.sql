

insert  into `sys_user`(`id`,`login_name`,`email`,`delete_enum`,`create_date`,`lock_version`) values ('374933329427959808','admin','judas.n@qq.com','0','2016-06-20 11:49:53',3);
insert  into `sys_user`(`id`,`login_name`,`email`,`delete_enum`,`create_date`,`lock_version`) values ('374933329427959809','judasn','363379444@qq.com','0','2017-01-05 14:59:05',2);
