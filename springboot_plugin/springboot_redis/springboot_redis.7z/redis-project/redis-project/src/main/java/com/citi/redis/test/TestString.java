package com.citi.redis.test;

public class TestString {

    public static void main(String[] args) {
        String a="c";
        System.out.println(a.charAt(a.length()-1));
    }
}
