package com.icloud.cache.constants;

public enum CacheScope {
    user, application
}
