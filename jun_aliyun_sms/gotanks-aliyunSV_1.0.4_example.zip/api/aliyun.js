import aliRequest from '@/common/ali-request.js'
export default {
  getRtcAuthInfo(data){
    return aliRequest.request({
      url: '/api/rtc/auth/token',
      data
    })
  },
  getPlayInfo(videoId){
    return aliRequest.request({
      url: '/api/vod/play/info',
      data: {
        videoId
      }
    })
  },
  getVodImageUploadAuth(data){
    return aliRequest.request({
      url: '/api/vod/auth/getImageUploadAuth',
      data
    })
  },
  getVodVideoUploadAuth(data){
    return aliRequest.request({
      url: '/api/vod/auth/getVideoUploadAuth',
      data
    })
  },
}
