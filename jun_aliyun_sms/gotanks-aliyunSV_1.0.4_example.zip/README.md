# 阿里云短视频录制插件接口说明
###传入参数：
| 参数名 | 例子 | 说明 |
| ------ | ------ | ------ |
| title | video231235512 |  |
| fileName | video231235512.mp4 |  |
| imageType | cover | 固定为cover |
| imageUploadAuth |  | 封面上传认证信息 |
| videoUploadAuth |  | 视频上传认证信息 |

###返回值
| 参数名 | 说明 |
| ------ | ------ |
| videoId | 阿里云返回的视频id | 
| videoDesc | 录制视频描述 | 
| visibility | 录制视频可见性 |
 
#### 1. 插件对象

```
const aliSV = uni.requireNativePlugin('gotanks-aliyunSV');
```

#### 2. 视频录制

```
aliSv.openRecordVcr({
  title: "video231235512",//视频名称
  fileName: "video231235512.mp4",//视频文件名
  imageType: "cover",//封面：固定为cover
  imageUploadAuth: {},//封面上传认证信息，需调用server端获取
  videoUploadAuth: {},//视频上传认证信息，需调用server端获取
}, result=>{
  console.log(result.videoId)//阿里云返回的videoId
  console.log(result.videoDesc)//录制视频描述
  console.log(result.visibility)//录制视频可见性
});
```



