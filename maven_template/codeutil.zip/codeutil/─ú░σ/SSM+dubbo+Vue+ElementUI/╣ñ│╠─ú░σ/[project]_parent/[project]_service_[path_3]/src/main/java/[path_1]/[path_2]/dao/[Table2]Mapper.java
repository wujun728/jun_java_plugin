package [path_1].[path_2].dao;

import [path_1].[path_2].pojo.[path_3].[Table2];
import tk.mybatis.mapper.common.Mapper;

public interface [Table2]Mapper extends Mapper<[Table2]> {

}
