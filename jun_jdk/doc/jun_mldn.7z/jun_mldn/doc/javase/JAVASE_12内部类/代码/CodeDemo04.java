public class CodeDemo04{
	static{
		System.out.println("Hello World!!!") ;
		System.exit(1) ;
	}
};