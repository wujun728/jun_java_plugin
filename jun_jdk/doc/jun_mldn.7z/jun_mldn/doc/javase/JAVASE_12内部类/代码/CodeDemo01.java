public class CodeDemo01{
	public static void main(String args[]){
		{	// ��ͨ�����
			int x = 10 ;
			System.out.println("x = " + x) ;
		}
		int x = 100 ;
		System.out.println("x = " + x) ;
	}
};