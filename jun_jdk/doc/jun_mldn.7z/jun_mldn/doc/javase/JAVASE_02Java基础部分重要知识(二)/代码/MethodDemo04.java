public class MethodDemo04{
	public static void main(String args[]){
		System.out.println(1) ;
		System.out.println("hello") ;
		System.out.println(1.1) ;
		System.out.println('c') ;
	}
};