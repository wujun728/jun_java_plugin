public class MethodArrayDemo05{
	public static void main(String args[]){
 		int t1[] = {1,2,3,4,5,6,7,8,9} ;
		for(int x:t1){
			System.out.print(x + "��") ;
		}
	}
};