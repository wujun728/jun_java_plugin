public class StaticDemo05{
	public static void main(String args[]){
		new StaticDemo05().fun() ;
	}
	public void fun(){
		System.out.println("Hello World!!!") ;
	}
};