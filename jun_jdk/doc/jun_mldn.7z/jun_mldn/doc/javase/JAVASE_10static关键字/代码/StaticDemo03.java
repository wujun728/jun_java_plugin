class Person{
	private String name ;
	private int age;
	private static String city = "A��" ;
	public static void setCity(String c){
		city = c ;
	}
	public Person(String name,int age){
		this.name = name ;
		this.age = age ;
	}
	public String getInfo(){
		return "������" + this.name + "�����䣺" + this.age + "�����У�" + city ;
	}
};
public class StaticDemo03{
	public static void main(String args[]){
		Person per1 = new Person("����",30) ;
		Person per2 = new Person("����",31) ;
		Person per3 = new Person("����",30) ;
		System.out.println("============= ��Ϣ�޸�֮ǰ ================") ;
		System.out.println(per1.getInfo()) ;
		System.out.println(per2.getInfo()) ;
		System.out.println(per3.getInfo()) ;
		System.out.println("============= ��Ϣ�޸�֮�� ================") ;
		Person.setCity("B��") ;
		System.out.println(per1.getInfo()) ;
		System.out.println(per2.getInfo()) ;
		System.out.println(per3.getInfo()) ;
	}
};