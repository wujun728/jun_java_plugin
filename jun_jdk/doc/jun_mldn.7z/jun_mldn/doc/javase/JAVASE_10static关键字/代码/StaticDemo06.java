public class StaticDemo06{
	public static void main(String args[]){
		for(int x=0;x<args.length;x++){
			System.out.println(args[x] + "��") ;
		}
	}
};