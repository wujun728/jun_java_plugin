class A{
	public final String NAME = "MLDN" ;
	public void fun(){
		NAME = "sss" ;
	}
};