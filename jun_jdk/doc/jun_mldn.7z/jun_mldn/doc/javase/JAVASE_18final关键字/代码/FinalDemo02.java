class A{
	public final void fun(){}
};
class B extends A{
	public void fun(){}
};