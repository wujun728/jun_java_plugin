final class A{
};
class B extends A{
};