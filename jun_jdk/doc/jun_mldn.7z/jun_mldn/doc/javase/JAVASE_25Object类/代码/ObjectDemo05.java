class Person{
	public String toString(){	// ��д��toString()����
 		return "Hello" ;
	}
};
public class ObjectDemo05{
	public static void main(String arg[]){
		System.out.println(new Person()) ;
	}
};