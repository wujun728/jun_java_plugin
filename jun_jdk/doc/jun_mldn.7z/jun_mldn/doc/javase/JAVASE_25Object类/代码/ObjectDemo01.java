class Person extends Object{
};