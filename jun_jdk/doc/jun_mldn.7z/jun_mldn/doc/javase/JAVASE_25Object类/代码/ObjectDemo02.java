class Person extends Object{
};
public class ObjectDemo02{
	public static void main(String arg[]){
		Object obj1 = new Person() ;
		Object obj2 = "hello" ;
	}
};