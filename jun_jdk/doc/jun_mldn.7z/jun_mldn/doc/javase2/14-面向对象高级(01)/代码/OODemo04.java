class A
{
};
class B extends A
{
};
class C extends B
{
};