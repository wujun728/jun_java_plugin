class A
{
};
class B
{
};
class C extends A,B
{
};