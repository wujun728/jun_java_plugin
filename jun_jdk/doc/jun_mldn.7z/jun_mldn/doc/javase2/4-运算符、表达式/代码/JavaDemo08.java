public class JavaDemo08
{
	public static void main(String args[])
	{
		// long ll = 1000 ;
		// int i = (int)ll ;
		int i = 1000 ;
		long ll = i ;
	}
};
