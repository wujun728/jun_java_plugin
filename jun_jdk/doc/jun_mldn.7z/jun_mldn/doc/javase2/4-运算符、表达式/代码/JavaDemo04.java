public class JavaDemo04
{
	public static void main(String args[])
	{
		int i = 10 ;
		int j = 11 ;
		System.out.println(i!=j) ;
	}
};
