public class JavaDemo01
{
	public static void main(String args[])
	{
		int i = 10 ;
		int j = 20 ;
		// float k = (float)i / j ;	// 0.5
		int k = i % j ;
		System.out.println(k) ;
	}
};
