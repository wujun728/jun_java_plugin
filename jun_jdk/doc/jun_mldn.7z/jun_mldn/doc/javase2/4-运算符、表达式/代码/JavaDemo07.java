public class JavaDemo07
{
	public static void main(String args[])
	{
		int i = 10 ;
		System.out.println(i>10&&i/0==0) ;
	}
};
