public class JavaDemo09
{
	public static void main(String args[])
	{
		int i = 10 ;
		// i = i + 10 ;
		i += 10 ;
		System.out.println(i) ;
	}
};
