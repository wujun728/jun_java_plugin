// ����һ��������
abstract class A
{
	public void fun2()
	{
		System.out.println("Hello World!!!") ;
	}
	public abstract void fun() ;
};
abstract class B extends A
{
};
public class OODemo06
{
	public static void main(String args[])
	{
	}
};