final abstract class A
{
};
class B extends A
{
};