public class JavaDemo10
{
	public static void main(String args[])
	{
		System.out.println(Short.MAX_VALUE) ;
		System.out.println(Double.MAX_VALUE) ;
		System.out.println(Byte.MAX_VALUE) ;
		System.out.println(Byte.MIN_VALUE) ;
	}
};