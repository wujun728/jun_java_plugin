public class JavaDemo05
{
	public static void main(String args[])
	{
		// System.out.println(Integer.MAX_VALUE+1) ;
		// System.out.println(Integer.MIN_VALUE-1) ;
		System.out.println(Float.MAX_VALUE) ;
		System.out.println(Float.MIN_VALUE) ;
	}
};