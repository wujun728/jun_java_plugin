import java.io.* ;

public class IODemo03
{
	public static void main(String args[])
	{
		File f = new File("f:\\mldn.txt") ;
		f.delete() ;
	}
};