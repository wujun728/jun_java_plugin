public class OODemo14
{
	public static void main(String args[])
	{
		{
			// �ڴ˴�����֮��
			int i = 0 ;
		}
		int i = 10 ;
		System.out.println("i = "+i) ;
	}
};