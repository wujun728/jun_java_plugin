public class Demo01
{
	public static void main(String args[])
	{
		int x = 0 ;
		{
			x = 100 ;
		}
		System.out.println("x = "+x) ;
	}
};