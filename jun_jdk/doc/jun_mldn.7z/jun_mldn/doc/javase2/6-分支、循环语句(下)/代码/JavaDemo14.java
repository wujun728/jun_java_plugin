public class JavaDemo14
{
	public static void main(String args[])
	{
		for (int i=1;i<=100;i++)
		{
			if(i<50)
			{
				if(i%2==0)
				{
					System.out.print(i+"\t") ;
				}
			}
		}
	}
};