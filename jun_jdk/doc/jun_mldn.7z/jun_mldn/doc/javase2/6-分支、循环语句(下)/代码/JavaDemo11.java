public class JavaDemo11
{
	public static void main(String args[])
	{
		int i = 0 ;
		for (;i<100 ;)
		{
			System.out.print("*") ;
			i++ ;
		}
	}
};