public class JavaDemo04
{
	public static void main(String args[])
	{
		int i[] = {1,2,3,4,5,6,7,8,23,41,421,513245,13,23,13,143,24} ;
		System.out.println("�����С��"+i.length) ;
		for (int x=0;x<i.length;x++)
		{
			System.out.println(i[x]) ;
		}
	}
};