public class IODemo21
{
	public static void main(String args[])
	{
		String str = "123a" ;
		int i = Integer.parseInt(str) ;
		i++ ;
		System.out.println(i) ;
	}
};