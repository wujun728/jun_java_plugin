public class JavaDemo02
{
	public static void main(String args[])
	{
		float score = 59 ;
		if(score>=60)
		{
			System.out.println("�ɼ��ϸ�") ;
		}
		else
		{
			System.out.println("�ɼ����ϸ�") ;
		}
	}
};