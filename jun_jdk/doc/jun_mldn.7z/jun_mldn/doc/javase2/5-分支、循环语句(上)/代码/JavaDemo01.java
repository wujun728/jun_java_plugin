public class JavaDemo01
{
	public static void main(String args[])
	{
		int i = 10 ;
		i = 20 ;
		i += 30 ;
		System.out.println("i = "+i) ;
	}
};