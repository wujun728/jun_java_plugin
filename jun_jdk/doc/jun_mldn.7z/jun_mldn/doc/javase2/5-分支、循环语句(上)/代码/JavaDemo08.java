public class JavaDemo08
{
	public static void main(String args[])
	{
		// ��ӡ1~100
		for(int i=1;i<=100;i++)
		{
			System.out.print(i+"\t") ;
		}
	}
};