package org.lxh.demo02 ;
import org.lxh.demo01.* ;
public class DemoD extends DemoC
{
	public DemoD()
	{
		System.out.println("** INFO = "+super.info) ;
	}
};