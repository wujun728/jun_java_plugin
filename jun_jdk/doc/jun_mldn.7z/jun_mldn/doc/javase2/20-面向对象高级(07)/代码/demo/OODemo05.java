package org.lxh.demo03 ;
import org.lxh.demo01.* ;

public class OODemo05
{
	public static void main(String args[])
	{
		// new DemoD() ;
		DemoC dc = new DemoC() ;
		System.out.println(dc.info) ;
	}
};