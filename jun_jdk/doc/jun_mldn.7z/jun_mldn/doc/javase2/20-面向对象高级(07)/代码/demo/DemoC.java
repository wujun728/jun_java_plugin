package org.lxh.demo01 ;

public class DemoC
{
	protected String info = "LXH --> MLDN" ;
};