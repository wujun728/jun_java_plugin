public class OODemo10
{
	public static void main(String args[])
	{
		String str1 = "ħ��" ;
		fun(str1) ;
		System.out.println(str1) ;
	}
	public static void fun(String str2)
	{
		str2 += "���˻�" ;
	}
};