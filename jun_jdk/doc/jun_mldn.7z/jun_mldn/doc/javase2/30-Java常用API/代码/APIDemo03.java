public class APIDemo03
{
	public static void main(String args[])
	{
		String str = "123" ;
		// int i = Integer.parseInt(str) ;
		// System.out.println(i * 2) ;
		float f = Float.parseFloat(str) ;
		System.out.println(f * 2) ;
	}
};