import java.util.* ;
public class APIDemo06
{
	public static void main(String args[]) throws Exception
	{
		System.out.println(new Date()) ;
	}
};