public class APIDemo01
{
	public static void main(String args[])
	{
		String str = "" ;
		for(int i=0;i<20;i++)
		{
			str += i ;
		}
		System.out.println(str) ;
	}
};