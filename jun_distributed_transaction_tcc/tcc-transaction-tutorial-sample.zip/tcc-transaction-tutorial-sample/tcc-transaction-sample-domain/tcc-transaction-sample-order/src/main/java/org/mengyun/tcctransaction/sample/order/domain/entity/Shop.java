package org.mengyun.tcctransaction.sample.order.domain.entity;

/**
 * Created by changming.xie on 4/1/16.
 */
public class Shop {

    private long id;

    private long ownerUserId;

    public long getOwnerUserId() {
        return ownerUserId;
    }

    public long getId() {
        return id;
    }
}
