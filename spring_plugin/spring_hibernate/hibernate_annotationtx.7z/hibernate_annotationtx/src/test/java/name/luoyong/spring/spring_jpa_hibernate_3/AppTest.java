package name.luoyong.spring.spring_jpa_hibernate_3;

import name.luoyong.spring.jpa.App;

import org.junit.Test;



public class AppTest {

	@Test
	public void app() throws Exception {
		App.main(null);
	}
}
