interface Window {
  webkitURL?: typeof URL
  mozURL?:  typeof URL
  ActiveXObject?: any
}
