package com.wang.model;

import com.wang.model.entity.Role;
import javax.persistence.Table;

/**
 *
 * @author dolyw.com
 * @date 2018/8/30 10:47
 */
@Table(name = "role")
public class RoleDto extends Role {

}