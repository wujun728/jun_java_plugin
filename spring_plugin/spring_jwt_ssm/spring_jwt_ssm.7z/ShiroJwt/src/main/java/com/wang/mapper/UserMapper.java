package com.wang.mapper;

import com.wang.model.UserDto;
import tk.mybatis.mapper.common.Mapper;

/**
 * UserMapper
 * @author dolyw.com
 * @date 2018/8/31 14:43
 */
public interface UserMapper extends Mapper<UserDto> {
}