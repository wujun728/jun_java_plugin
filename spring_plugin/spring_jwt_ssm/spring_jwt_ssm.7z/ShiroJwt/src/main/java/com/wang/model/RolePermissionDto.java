package com.wang.model;

import com.wang.model.entity.RolePermission;
import javax.persistence.Table;

/**
 *
 * @author dolyw.com
 * @date 2018/8/30 10:49
 */
@Table(name = "role_permission")
public class RolePermissionDto extends RolePermission {

}