package com.wang.mapper;

import com.wang.model.RolePermissionDto;
import tk.mybatis.mapper.common.Mapper;

/**
 * RolePermissionMapper
 * @author dolyw.com
 * @date 2018/8/31 14:43
 */
public interface RolePermissionMapper extends Mapper<RolePermissionDto> {
}