package com.wang.model;

import com.wang.model.entity.UserRole;
import javax.persistence.Table;

/**
 *
 * @author dolyw.com
 * @date 2018/8/30 10:49
 */
@Table(name = "user_role")
public class UserRoleDto extends UserRole {

}