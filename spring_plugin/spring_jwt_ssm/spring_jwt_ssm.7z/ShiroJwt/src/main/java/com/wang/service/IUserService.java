package com.wang.service;

import com.wang.model.UserDto;

/**
 *
 * @author dolyw.com
 * @date 2018/8/9 15:44
 */
public interface IUserService extends IBaseService<UserDto> {
}
