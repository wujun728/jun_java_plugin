package com.wang.mapper;

import com.wang.model.UserRoleDto;
import tk.mybatis.mapper.common.Mapper;

/**
 * UserRoleMapper
 * @author dolyw.com
 * @date 2018/8/31 14:43
 */
public interface UserRoleMapper extends Mapper<UserRoleDto> {
}