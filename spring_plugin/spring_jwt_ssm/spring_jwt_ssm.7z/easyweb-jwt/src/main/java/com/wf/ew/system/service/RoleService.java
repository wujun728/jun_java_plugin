package com.wf.ew.system.service;

import com.baomidou.mybatisplus.service.IService;
import com.wf.ew.system.model.Role;

public interface RoleService extends IService<Role> {

}
