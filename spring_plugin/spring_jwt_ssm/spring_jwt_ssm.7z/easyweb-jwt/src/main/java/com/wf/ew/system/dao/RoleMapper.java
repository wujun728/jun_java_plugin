package com.wf.ew.system.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.wf.ew.system.model.Role;

public interface RoleMapper extends BaseMapper<Role> {
}
