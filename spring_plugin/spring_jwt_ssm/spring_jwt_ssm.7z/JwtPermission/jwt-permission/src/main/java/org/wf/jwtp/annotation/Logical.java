package org.wf.jwtp.annotation;

/**
 * 处理逻辑, 多个权限使用AND还是OR
 * Created by wangfan on 2018-2-1 上午10:49:38
 */
public enum Logical {
    AND, OR
}
