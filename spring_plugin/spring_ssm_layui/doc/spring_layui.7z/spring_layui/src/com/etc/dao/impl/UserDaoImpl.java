package com.etc.dao.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.etc.dao.UserDao;
import com.etc.entity.User;
import com.etc.entity.UserRowMapper;
import com.etc.util.PageData;

@Repository(value="userDao")
public class UserDaoImpl implements UserDao {

	@Resource
	private JdbcTemplate jdbcTemplate;

	/**
	 * 根据名字查询用户
	 */
	@Override
	public User findUserByName(String name) {
		// TODO Auto-generated method stub
		String sql = "select * from User where username=?";

		return jdbcTemplate.queryForObject(sql, new Object[] { name }, new UserRowMapper());

	}

	/**
	 * 查询所有普通用户
	 */
	@Override
	public List<User> findAllUser() {
		String sql = "select * from user where status=0";
		
		return jdbcTemplate.query(sql, new UserRowMapper()) ;
	}

	/**
	 * 根据id删除用户
	 */
	@Override
	public boolean deleteUser(int id) {
		String sql = "delete from user where userid=?";

		return jdbcTemplate.update(sql, id) > 0;
	}

	/**
	 * 根据id查找用户 查询单个记录
	 */
	@Override
	public User findUserById(int id) {
		// 查询单个记录
		String sql = "select * from user where userid=?";

		return jdbcTemplate.queryForObject(sql, new Object[] { id }, new UserRowMapper());

	}

	/**
	 * 增加用户
	 */
	@Override
	public boolean addUser(User user) {

		// TODO Auto-generated method stub
		String sql = "INSERT INTO user(username, userpwd, sex, age, address, phone, status)  VALUES(?,?, ?,?, ?,?,?)";
		return jdbcTemplate.update(sql, user.getUsername(), user.getUserpwd(), user.getSex(), user.getAge(),
				user.getAddress(), user.getPhone(), 0) > 0;
	}

	/**
	 * 查询所有管理员
	 */
	@Override
	public List<User> findAllManager() {
		String sql = "select * from user where status=1";
		
		return jdbcTemplate.query(sql, new UserRowMapper());
	}

	/**
	 * 修改用户信息
	 */
	@Override
	public boolean updateUser(User user) {
		// TODO Auto-generated method stub
		String sql = "update user set username=?,sex=?,age=?,address=?,phone=? where userid=?";

		return jdbcTemplate.update(sql, user.getUsername(), user.getSex(), user.getAge(), user.getAddress(),
				user.getPhone(), user.getUserid()) > 0;
	}

	/**
	 * 查询的具体实现
	 */
	@Override
	public PageData<User> getUsersByPage(int page, int pageSize, String content) {
		// TODO Auto-generated method stub
		String sql = "select * from user where userName like ?";
		// 其他内容
		// 统计记录数量
		String selSql = "select count(1) from (" + sql + ") t";
		// 调用getFirst 得到记录数
		Integer count = jdbcTemplate.queryForObject(selSql, Integer.class, "%" + content + "%");
		// 得到起始位置
		int start = (page - 1) * pageSize;

		selSql = sql + " limit " + start + "," + pageSize;
		// 查询需要返回的核心数据[指定页码]
		List<User> data = jdbcTemplate.query(selSql, new Object[] { "%" + content + "%" }, new UserRowMapper());

		PageData<User> pd = new PageData<>(data, count, pageSize, page);

		return pd;
	}

}
