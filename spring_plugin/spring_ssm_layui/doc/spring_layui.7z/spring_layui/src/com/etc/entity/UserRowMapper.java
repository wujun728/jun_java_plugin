package com.etc.entity;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

/**
 * 映射[实体类和数据库直接的关联]
 * @author zengd
 *
 */
public class UserRowMapper implements RowMapper<User> {

	
	@Override
	public User mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		User user  = new User() ;
		user.setUserid(rs.getInt("userid"));
		user.setUsername(rs.getString("username"));
		user.setSex(rs.getString("sex"));
		user.setAge(rs.getInt("age"));
		user.setAddress(rs.getString("address"));
		user.setPhone(rs.getString("phone"));
		user.setStatus(rs.getInt("status"));
		return user;
	}

}
