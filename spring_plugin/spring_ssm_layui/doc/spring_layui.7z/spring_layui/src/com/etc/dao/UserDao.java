package com.etc.dao;

import java.util.List;

import com.etc.entity.User;
import com.etc.util.PageData;
/**
 * 
 * @author wu
 *
 */
public interface UserDao {
   /**
    * 通过名字查询用户
    */
	public User findUserByName(String name);
	/**
	 * 查找所有用户
	 */
	public List<User> findAllUser();
	/**
	 * 查找所有管理员
	 */
	public List<User> findAllManager();
	
	
	/**
	 * 根据userid删除用户
	 */
   public boolean  deleteUser(int id);
   
   /**
    * 根据userid查找用户
    */
   public User  findUserById(int id);
  /**
   * 增加用户
   */
   public boolean addUser(User user);
   /**
    * 后台修改用户信息
    */
   public boolean updateUser(User user) ;
   /**
	 * 分页和模糊查询的方法
	 * @param page  页码
	 * @param pageSize 每页记录数
	 * @param content  模糊查询的关键字
	 * @return   分页的数据集合[list total totalPage ...]
	 */
	public PageData<User> getUsersByPage(int page, int pageSize, String content);
}
