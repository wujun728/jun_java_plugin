package com.etc.entity;

import org.springframework.stereotype.Component;

/**
 * 用户的实体类
 * @author zeng
 *
 */
@Component(value="user")
public class User {

	//用户编号
	private int userid ;
	//用户名
	private String username ;
	//用户密码
	private String userpwd ;
	//用户性别
	private String sex ;
	//用户年龄
	private int age ;
	//用户等级
	private int status ;
     private String address;
     private String phone;
     
     
     
	@Override
	public String toString() {
		return "User [userid=" + userid + ", username=" + username + ", userpwd=" + userpwd + ", sex=" + sex + ", age="
				+ age + ", status=" + status + ", address=" + address + ", phone=" + phone + "]";
	}



	public User(int userid, String username, String userpwd, String sex, int age, int status, String address,
			String phone) {
		super();
		this.userid = userid;
		this.username = username;
		this.userpwd = userpwd;
		this.sex = sex;
		this.age = age;
		this.status = status;
		this.address = address;
		this.phone = phone;
	}
	public User( String username, String userpwd, String sex, int age, int status, String address,
			String phone) {
		
		this.username = username;
		this.userpwd = userpwd;
		this.sex = sex;
		this.age = age;
		this.status = status;
		this.address = address;
		this.phone = phone;
	}

public User(int userid,String username,  String sex, int age, String address,String phone) {
		
		this.userid = userid;
		this.username = username;
		this.sex = sex;
		this.age = age;
		this.address = address;
		this.phone = phone;
	}
	
	
	
	public int getUserid() {
		return userid;
	}



	public void setUserid(int userid) {
		this.userid = userid;
	}



	public String getUsername() {
		return username;
	}



	public void setUsername(String username) {
		this.username = username;
	}



	public String getUserpwd() {
		return userpwd;
	}



	public void setUserpwd(String userpwd) {
		this.userpwd = userpwd;
	}



	public String getSex() {
		return sex;
	}



	public void setSex(String sex) {
		this.sex = sex;
	}



	public int getAge() {
		return age;
	}



	public void setAge(int age) {
		this.age = age;
	}



	public int getStatus() {
		return status;
	}



	public void setStatus(int status) {
		this.status = status;
	}



	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}



	public String getPhone() {
		return phone;
	}



	public void setPhone(String phone) {
		this.phone = phone;
	}



	public User() {
		// TODO Auto-generated constructor stub
	}

}
