package com.etc.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.etc.dao.UserDao;
import com.etc.dao.impl.UserDaoImpl;
import com.etc.entity.User;
import com.etc.service.UserService;
import com.etc.util.AjaxLogicBean;
import com.etc.util.MD5Util;
import com.etc.util.PageData;

@Service(value="userService")
public class UserServiceImpl implements UserService {
	@Resource(name="userDao")
	UserDao ud;

	@Override
	public User findUserByName(String name) {

		return ud.findUserByName(name);
	}

	/**
	 * 查询所有用户
	 */
	@Override
	public AjaxLogicBean<User> findAllUser() {
		// TODO Auto-generated method stub
		List<User> list = ud.findAllUser();
		AjaxLogicBean<User> lab = new AjaxLogicBean<>();
		lab.setData(list);
		return lab;
	}

	/**
	 * 根据id删除用户
	 */
	@Override
	public boolean deleteUser(int id) {
		// TODO Auto-generated method stub
		return ud.deleteUser(id);
	}

	@Override
	public User findUserById(int id) {
		// TODO Auto-generated method stub
		return ud.findUserById(id);
	}

	/**
	 * 增加用户
	 */
	@Override
	public boolean addUser(User user) {
		// TODO Auto-generated method stub
		if (user == null) {
			return false;
		} else {
			user.setUserpwd(MD5Util.getEncodeByMd5(user.getUserpwd()));

			return ud.addUser(user);
		}

	}

	@Override
	public AjaxLogicBean<User> findAllManager() {
		List<User> list = ud.findAllManager();
		AjaxLogicBean<User> lab = new AjaxLogicBean<>();
		lab.setData(list);
		return lab;
	}

	/**
	 * 修改用户信息
	 */
	@Override
	public boolean updateUser(User user) {
		// TODO Auto-generated method stub

		return ud.updateUser(user);
	}

	@Override
	public PageData<User> getUserByPage(int page, int pageSize, String content) {
		// TODO Auto-generated method stub
		return ud.getUsersByPage(page, pageSize, content);
	}

}
