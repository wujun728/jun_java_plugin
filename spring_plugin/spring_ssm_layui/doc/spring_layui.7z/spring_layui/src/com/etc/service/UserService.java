package com.etc.service;





import com.etc.entity.User;
import com.etc.util.AjaxLogicBean;
import com.etc.util.PageData;

public interface UserService {
	   /**
	    * 通过名字查询用户
	    */
		public User findUserByName(String name);   
		/**
		 * 查询所有用户
		 * @return
		 */
		public AjaxLogicBean<User> findAllUser();
		/**
		 * 查找所有管理员
		 */
		public AjaxLogicBean<User> findAllManager();
		
		/**
		 * 根据userid删除用户
		 */
	   public boolean  deleteUser(int id);
	   /**
	    * 根据userid查找用户
	    */
	   public User  findUserById(int id);
	   /**
	    * 增加用户
	    */
	   public boolean addUser(User user);
	   //修改用户
	   public boolean updateUser(User user) ;
	 //分页+模糊查询
		public PageData<User> getUserByPage(int page, int pageSize, String content);
}
