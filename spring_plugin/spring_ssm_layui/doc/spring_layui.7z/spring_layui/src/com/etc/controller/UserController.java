package com.etc.controller;

import java.io.IOException;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.etc.entity.CommenMassage;
import com.etc.entity.User;
import com.etc.service.UserService;
import com.etc.util.PageData;

@Controller
public class UserController {

	@Resource(name="userService")//注入UserService
	private UserService us ;
	
	@RequestMapping(value="userlist",method=RequestMethod.GET)
	@ResponseBody
	public PageData<User> listUser(Integer page,Integer limit,String content){
		if(content ==null) {
			content="" ;
		}
		PageData<User> pd = us.getUserByPage(page, limit, content) ;
		pd.setCode(0);
		pd.setMsg("请求成功");
		
		return pd ;
	}
	/*@RequestMapping(value="index")
	public String test() {
		return "layuitable2";
	}*/
	/**
	 * get请求做删除
	 * @param id
	 * @return
	 */
	@RequestMapping(value="userdelete",method=RequestMethod.GET)
	@ResponseBody
	public CommenMassage removeUser(Integer id) {
		System.out.println(id);
		boolean flag =  us.deleteUser(id) ;
		CommenMassage cmg = new CommenMassage() ;
		String str = "删除用户失败" ;
		if(flag) {
			str = "删除用户成功" ;
		}
		cmg.setMsg(str);
		return cmg ;
	}
	/**
	 * delete 请求 做删除
	 * @param id
	 * @return
	 */
	@RequestMapping(value="userdelete2/{id}",method=RequestMethod.DELETE)
	@ResponseBody
	public CommenMassage removeUser2(@PathVariable(value="id")Integer id) {
		System.out.println(id);
		boolean flag =  us.deleteUser(id) ;
		CommenMassage cmg = new CommenMassage() ;
		String str = "删除用户失败" ;
		if(flag) {
			str = "删除用户成功" ;
		}
		cmg.setMsg(str);
		return cmg ;
	}
	
	@RequestMapping(value="useradd",method=RequestMethod.POST)
	@ResponseBody
	public void addUser(HttpServletResponse response,User user) throws IOException {
		boolean flag = us.addUser(user) ;
		
		if(flag) {
			response.sendRedirect("layuitable2.jsp") ;
		}else {
		response.sendRedirect("addUser.jsp") ;
		}
	}
	
	@RequestMapping(value="userupdate",method=RequestMethod.PUT)
	@ResponseBody
	public CommenMassage updateUser(User user)  {
		boolean flag = us.updateUser(user) ;
		CommenMassage cmg = new CommenMassage() ;
		String str = "修改用户失败" ;
		if(flag) {
			str = "修改用户成功" ;
		}
		cmg.setMsg(str);
		return cmg ;
		
	}
	
}
