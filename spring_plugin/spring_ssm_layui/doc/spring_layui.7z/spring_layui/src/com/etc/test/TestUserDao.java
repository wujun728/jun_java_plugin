package com.etc.test;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.etc.dao.UserDao;
import com.etc.dao.impl.UserDaoImpl;
import com.etc.entity.User;


public class TestUserDao {

	
	
	ApplicationContext context ;
	@Before
	public void Before() {
		context = new ClassPathXmlApplicationContext("applicationContext.xml") ;
	}
	
	@Test
	public void test1() {
		UserDao us = context.getBean(UserDaoImpl.class) ;
		List<User> list  =us.findAllUser() ;
		User u = us.findUserById(2) ;
		System.out.println(list);
		System.out.println(u);
	}
	
}
