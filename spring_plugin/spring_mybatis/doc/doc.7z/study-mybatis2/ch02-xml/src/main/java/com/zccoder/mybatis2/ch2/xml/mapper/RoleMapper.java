package com.zccoder.mybatis2.ch2.xml.mapper;

/**
 * 标题：角色表 Mapper<br>
 * 描述：角色表 Mapper<br>
 * 时间：2018/05/30<br>
 *
 * @author zc
 **/
public interface RoleMapper {
    
}
