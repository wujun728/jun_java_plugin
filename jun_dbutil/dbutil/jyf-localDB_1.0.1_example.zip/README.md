## 背景介绍 ##
对于一些变化性不强的数据（如一些列表、文章信息等），如果每次都进行网络请求，不仅减慢了速度，也加重了服务器负担；这时往往需要通过 `setStorage` 和 `getStorage` 进行本地缓存，但也存在一些问题，一个是 `storage` 只能通过 `key-value` 的形式进行管理，无法进行更复杂的数据库操作，另外每次都从本地 `storage` 中读写效率不高  
本插件对本地 `storage` 进行封装和集中管理，可以实现一个简易的本地数据库  

## 示例 ##
```javascript
const localDB = require('@/js_sdk/jyf-localDB/jyf-localDB.js')
const _ = localDB.command
localDB.init() // 初始化
var articles = localDB.collection('articles')
if(!articles)
  articles = localDB.createCollection('articles') // 不存在则先创建
// 按文章 id 查找
var doc = articles.doc('xxx')
if(doc) {
  var data = doc.get() // 取得数据
} else {
  // 网络请求获取 data
  data._timeout = Date.now() + 15 * 24 * 3600000 // 设置过期时间为 15 天
  articles.add(data) // 添加到本地数据库
}
// 按类型查找
var data = articles.where({
  type: 'xxx'
}).get()
// 正则查找
var data = articles.where({
  title: /xxx/ // 标题中含有 xxx 的
}).get()
// 分页查找
var page2 = articles.skip(10).limit(10).get()
// 按时间查找
var data = articles.where({
  date: _.gte('20200501').and(_.lte('20200510')) // 大于等于 20200501 小于等于 20200510
}).get()
// 结果排序
var data = articles.orderBy('date', 'desc').get() // 按日期降序排序
// 清理过期数据
articles.where({
  _timeout: _.lt(Date.now()) // 过期时间早于当前的
}).remove()
```

## 注意事项 ##
1. `api` 的设置上参考了 [云数据库](https://developers.weixin.qq.com/miniprogram/dev/wxcloud/reference-sdk-api/Cloud.database.html)，具体用法可以直接参考该文档（支持的 `api` 列表参考 [Github](https://github.com/jin-yufeng/MpLocalDB)）  
2. 数据库存储在本地 `storage` 中，账号、设备之间存在隔离；最大大小为 `10MB`；**请勿覆盖或删除** `key` 为 `localDB` 的 `storage`，否则可能造成数据丢失  
3. 使用前 **必须调用** `db.init` 方法（从 `storage` 中读取保存的数据，数据量较大的时候，需要选择一个合适的时机进行载入）  
4. 所有数据都在内存中，存取都较快，因此所有方法 **均为同步方法**，直接返回结果  
5. 所有操作 **不可撤销和恢复**，尤其是 `remove` 方法需谨慎调用  
6. 集合名和一个集合内的 `_id`（可自动生成）**不可重复**，否则将无法创建  