<template>
	<view>
	</view>
</template>

<script>
	const localDB = require('@/js_sdk/jyf-localDB/jyf-localDB.js')
	const _ = localDB.command
	export default {
		onLoad() {
			localDB.init()
			var collection = localDB.collection('test')
			if (!collection) {
				collection = localDB.createCollection('test')
				console.log('创建一张名为 test 的表', collection)
				// 增加
				for (var i = 0; i < 100; i++) {
					collection.add({
						xxx: i,
						yyy: [i],
						zzz: i % 2 ? 'aa' : 'bb'
					})
				}
				console.log('插入 100 条随机数据', collection.get())
			}
			// 查询
			console.log('查询 xxx 在 10-20 之间的数据', collection.where({
				xxx: _.gte(10).and(_.lte(20))
			}).get())
			console.log('正则查询 zzz: /a+/', collection.where({
				zzz: /a+/
			}).get())
			console.log('结果降序排序', collection.orderBy('xxx', 'desc').get())
			// 修改
			collection.update({
				yyy: _.push(100)
			})
			console.log('更新数据 yyy 增加一个 100', collection.get())
			// 删除
			collection.where({
				xxx: _.gte(50)
			}).remove()
			console.log('删除 xxx 大于 50 的记录', collection.get())
		}
	}
</script>

<style>
</style>
