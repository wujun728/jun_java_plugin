package com.xiaoleilu.hutool.db;

/**
 * 动态实体类<br>
 * TODO 提供了针对自身实体的增删改查方法
 * @author Looly
 *
 */
public class ActiveEntity extends Entity{
	private static final long serialVersionUID = 6112321379601134750L;
}
