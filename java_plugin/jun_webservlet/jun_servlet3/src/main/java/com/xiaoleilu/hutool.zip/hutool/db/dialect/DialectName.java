package com.xiaoleilu.hutool.db.dialect;

/**
 * 方言名
 * @author Looly
 *
 */
public enum DialectName {
	ANSI, MYSQL, ORACLE, POSTGREESQL, SQLITE3
}
