package com.java1234.webservice.impl;

import java.util.ArrayList;
import java.util.List;

import javax.jws.WebService;

import com.java1234.entity.Role;
import com.java1234.entity.User;
import com.java1234.webservice.HelloWorld;

@WebService
public class HelloWorldImpl implements HelloWorld{

	public String say(String str) {
		return "Hello:"+str;
	}

	public List<Role> getRoleByUser(User user) {
		List<Role> roleList=new ArrayList<Role>();
		// ģ��  ֱ��д��
		if(user!=null){
			if(user.getUserName().equals("java1234") && user.getPassword().equals("123456")){
				roleList.add(new Role(1,"�����ܼ�"));
				roleList.add(new Role(2,"�ܹ�ʦ"));
			}else if(user.getUserName().equals("jack") && user.getPassword().equals("123456")){
				roleList.add(new Role(3,"����Ա"));
			}
			return roleList;
		}else{
			return null;
		}
	}

}
