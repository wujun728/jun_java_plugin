package com.java1234.webservice;

import java.util.List;

import javax.jws.WebService;

import com.java1234.entity.Role;
import com.java1234.entity.User;

@WebService
public interface HelloWorld {

	public String say(String str);
	
	public List<Role> getRoleByUser(User user);
}
