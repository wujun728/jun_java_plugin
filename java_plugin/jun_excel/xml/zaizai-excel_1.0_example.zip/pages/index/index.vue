<template>
	<view class="content">
		<text class="title">将json数据导出为excel文件</text>
		<download-excel :data="json_data" name="excel.xls" title="excel名字" worksheet="工作表名字"> 下载文件 </download-excel>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				json_data: [
					{
						'姓名': '仔仔',
						'地区': '重庆',
						'插件': '仔仔-导出excel',
						'时间': '2019-06-02',
						'qq': '806606688'
					},
					{
						'姓名': '仔仔1',
						'地区': '重庆市',
						'插件': '仔仔-导出excel-1',
						'时间': '2019-06-01',
						'qq': '806606688'
					}
				]
			}
		},
		onLoad() {

		},
		methods: {

		}
	}
</script>

<style>
	.content {
		text-align: center;
		height: 400upx;
	}
	.title {
		font-size: 36upx;
		color: #8f8f94;
	}
</style>
