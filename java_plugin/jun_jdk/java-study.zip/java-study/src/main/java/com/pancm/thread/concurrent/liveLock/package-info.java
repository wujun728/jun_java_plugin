/**
 * 
 */
/**
 * Title: package-info
 * Description: 
 * 活锁测试
 * 一个线程常常处于响应另一个线程的动作，如果其他线程也常常处于该线程的动作,那么就可能出现活锁。
 * Version:1.0.0  
 * @author pancm
 * @date 2018年3月8日
 */
package com.pancm.thread.concurrent.liveLock;