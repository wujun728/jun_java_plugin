/**
 * 
 */
/**
 * Title: package-info
 * Description: 单例模式测试
 * Version:1.0.0  
 * @author pancm
 * @date 2017年11月7日
 */
package com.pancm.design.singleton;