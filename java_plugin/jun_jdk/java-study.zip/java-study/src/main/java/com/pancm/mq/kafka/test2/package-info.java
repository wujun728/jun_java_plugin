/**
 * 
 */
/**
 * Title: package-info
 * Description: 
 * kafka消费者
 * Version:1.0.0  
 * @author pancm
 * @date 2018年2月9日
 */
package com.pancm.mq.kafka.test2;