/**
* @Title: package-info
* @Description: 消息中间件的一些类
* @Version:1.0.0  
* @author pancm
* @date 2018年9月20日
*/
package com.pancm.mq;