/**
 * 
 */
/**
 * Title: package-info
 * Description: 工厂测试
 * Version:1.0.0  
 * @author pancm
 * @date 2017年10月13日
 */
package com.pancm.design.factory;