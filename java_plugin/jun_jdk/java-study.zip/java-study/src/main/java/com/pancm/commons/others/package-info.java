/**
* @Title: package-info
* @Description: 其它的工具包测试
* @Version:1.0.0  
* @author pancm
* @date 2018年9月21日
*/
package com.pancm.commons.others;