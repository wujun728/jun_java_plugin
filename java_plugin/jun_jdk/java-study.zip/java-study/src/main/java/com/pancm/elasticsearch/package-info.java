/**
* @Title: package-info
* @Description: es 相关测试类
* @Version:1.0.0  
* @author pancm
* @date 2019年2月28日
*/
package com.pancm.elasticsearch;