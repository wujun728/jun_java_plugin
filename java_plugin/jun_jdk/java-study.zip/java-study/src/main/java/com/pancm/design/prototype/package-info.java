
/**
* @Title: package-info
* @Description: 
* 原型模式
* @Version:1.0.0  
* @author pancm
* @date 2018年8月7日
*/
package com.pancm.design.prototype;