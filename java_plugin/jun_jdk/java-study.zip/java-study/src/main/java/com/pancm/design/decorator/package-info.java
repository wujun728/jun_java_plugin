/**
* @Title: package-info
* @Description: 装饰器模式
* @Version:1.0.0  
* @author pancm
* @date 2018年8月8日
*/ 
package com.pancm.design.decorator;