/**
 * 
 */
/**
 * Title: package-info
 * Description: rabbitMq 消息队列测试
 * Version:1.0.0  
 * @author pancm
 * @date 2017年11月7日
 */
package com.pancm.mq.rabbitmq;