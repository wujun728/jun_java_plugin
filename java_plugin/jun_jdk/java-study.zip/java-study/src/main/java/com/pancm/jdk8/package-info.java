/**
 * 
 */
/**
* @Title: package-info
* @Description: 
* jdk1.8测试用例
* @Version:1.0.0  
* @author pancm
* @date 2018年5月14日
*/
package com.pancm.jdk8;