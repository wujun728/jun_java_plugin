package com.zccoder.java.book2.ch3.basic;

/**
 * <br>
 * 标题: 一个简单的Java应用程序<br>
 * 描述: 3-1<br>
 * 时间: 2018/10/17<br>
 *
 * @author zc
 */
public class FirstSample {

    public static void main(String[] args) {
        // 单行注释
        System.out.println("We will not use 'Hello, World!'");
    }

}
