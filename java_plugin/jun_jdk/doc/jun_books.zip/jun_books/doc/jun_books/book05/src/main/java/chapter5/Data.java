package chapter5;

/**
 * Created by 13 on 2017/5/8.
 */
public interface Data {
    public String getResult();

}
