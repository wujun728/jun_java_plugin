package com.zccoder.java.book1.ch2.safety;

/**
 * 标题：测试<br>
 * 描述：测试<br>
 * 时间：2018/10/24<br>
 *
 * @author zc
 **/
public class WidgetMain {

    public static void main(String[] args) {
        LoggingWidget loggingWidget = new LoggingWidget();
        loggingWidget.doSomething();
    }

}
