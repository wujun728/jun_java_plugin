package com.zccoder.java.book1.ch2.safety;

/**
 * 标题：懒加载需使用的外部对象<br>
 * 描述：用于实例化对象，没有其他用途<br>
 * 时间：2018/10/24<br>
 *
 * @author zc
 **/
public class ExpensiveObject {

    public void hello() {
        System.out.println("Hi!");
    }

}
