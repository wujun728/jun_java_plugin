package com.xnx3;

/**
 * 总控制
 * @author 管雷鸣
 */
public class G {
	/**
	 * 当前版本号
	 */
	public final static String VERSION = "2.2";
	
	
}
