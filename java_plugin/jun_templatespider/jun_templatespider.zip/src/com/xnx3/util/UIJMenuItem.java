package com.xnx3.util;

public class UIJMenuItem {
	
	
	
}
