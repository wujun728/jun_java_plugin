本demo参考：Java开发中的Memcache原理及实现.pdf

本示例中的memcache + magent 集群环境下的参数环境配置详见文档说明，
集群环境搭建文档路径：/WebContent/memcache_magent集群环境/Memcache+Magent 集群环境搭建.txt