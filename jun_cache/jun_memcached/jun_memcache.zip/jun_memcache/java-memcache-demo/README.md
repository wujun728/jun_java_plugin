#java-memcache-demo
